package id.annur.jws.widget

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.time.ZonedDateTime

/**
 * Notifikasi tetap dengan hitung mundur. Tampil di lock screen (visibilitas publik)
 * dan tidak berbunyi. Tidak butuh Android 16, cukup Android 8 ke atas.
 */
object NotificationHelper {
    private const val CHANNEL = "jadwal_sholat"
    private const val NOTIF_ID = 1001

    fun hide(ctx: Context) {
        ctx.getSystemService(NotificationManager::class.java).cancel(NOTIF_ID)
    }

    fun show(ctx: Context, s: Settings) {
        val nm = ctx.getSystemService(NotificationManager::class.java)

        val channel = NotificationChannel(CHANNEL, "Jadwal sholat", NotificationManager.IMPORTANCE_LOW).apply {
            description = "Waktu sholat berikutnya dan hitung mundur"
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            setShowBadge(false)
        }
        nm.createNotificationChannel(channel)

        val zone = s.zone()
        val now = ZonedDateTime.now(zone)
        val cfg = s.config()
        val t = PrayerCalc.compute(cfg, now.year, now.monthValue, now.dayOfMonth)
        val next = PrayerCalc.nextPrayer(cfg, zone, now)

        val rows = listOf(
            "Subuh" to t.subuh,
            "Terbit" to t.terbit,
            "Zuhur" to t.zuhur,
            "Asar" to t.asar,
            "Maghrib" to t.maghrib,
            "Isya" to t.isya
        )
        fun cell(p: Pair<String, Long>) =
            (if (p.first == next.name) "• " else "") + "${p.first} ${fmtHm(p.second)}"

        val line1 = rows.take(3).joinToString("    ") { cell(it) }
        val line2 = rows.drop(3).joinToString("    ") { cell(it) }

        val nextClock = fmtHm(((next.epochMs - startOfDayMs(zone, next.epochMs)) / 1000L))

        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, ConfigActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )

        val n = Notification.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Menuju ${next.name} $nextClock")
            .setContentText(s.name)
            .setStyle(Notification.BigTextStyle().bigText("$line1\n$line2"))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(Notification.CATEGORY_STATUS)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setShowWhen(true)
            .setWhen(next.epochMs)
            .setUsesChronometer(true)
            .setChronometerCountDown(true)
            .setContentIntent(open)
            .build()

        nm.notify(NOTIF_ID, n)
    }

    private fun startOfDayMs(zone: java.time.ZoneId, epochMs: Long): Long =
        java.time.Instant.ofEpochMilli(epochMs).atZone(zone).toLocalDate()
            .atStartOfDay(zone).toInstant().toEpochMilli()
}
