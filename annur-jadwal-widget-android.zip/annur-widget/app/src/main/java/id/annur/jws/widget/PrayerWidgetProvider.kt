package id.annur.jws.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.SystemClock
import android.widget.RemoteViews
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * Widget jadwal sholat untuk layar utama.
 *
 * Hitung mundur memakai Chronometer di sisi launcher, jadi tetap berjalan
 * tanpa aplikasi terbuka. Pembaruan dan alarm diatur oleh [Scheduler].
 */
class PrayerWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        Scheduler.refresh(ctx)
    }

    override fun onDeleted(ctx: Context, ids: IntArray) {
        Scheduler.refresh(ctx)
    }

    override fun onDisabled(ctx: Context) {
        Scheduler.refresh(ctx)
    }

    companion object {
        private val DATE_FMT = DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", Locale.forLanguageTag("id-ID"))
        private val ROW = listOf("Subuh", "Terbit", "Zuhur", "Asar", "Maghrib", "Isya")
        private val NAME_IDS = intArrayOf(R.id.n0, R.id.n1, R.id.n2, R.id.n3, R.id.n4, R.id.n5)
        private val TIME_IDS = intArrayOf(R.id.t0, R.id.t1, R.id.t2, R.id.t3, R.id.t4, R.id.t5)

        private val GOLD = Color.parseColor("#F2B84B")
        private val TEXT = Color.parseColor("#E8F5F6")
        private val MUTED = Color.parseColor("#8DA9B9")

        /** Menggambar ulang semua widget. Mengembalikan true bila ada widget terpasang. */
        fun renderAll(ctx: Context, s: Settings): Boolean {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, PrayerWidgetProvider::class.java))
            if (ids.isEmpty()) return false

            val zone = s.zone()
            val now = ZonedDateTime.now(zone)
            val cfg = s.config()
            val t = PrayerCalc.compute(cfg, now.year, now.monthValue, now.dayOfMonth)
            val next = PrayerCalc.nextPrayer(cfg, zone, now)
            val times = longArrayOf(t.subuh, t.terbit, t.zuhur, t.asar, t.maghrib, t.isya)
            val remainMs = next.epochMs - System.currentTimeMillis()

            val openApp = PendingIntent.getActivity(
                ctx, 0, Intent(ctx, ConfigActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE
            )

            for (id in ids) {
                val rv = RemoteViews(ctx.packageName, R.layout.widget_prayer)
                rv.setTextViewText(R.id.wName, s.name)
                rv.setTextViewText(R.id.wDate, DATE_FMT.format(now))
                rv.setTextViewText(R.id.wNext, "Menuju ${next.name}")

                rv.setChronometerCountDown(R.id.wCount, true)
                rv.setChronometer(R.id.wCount, SystemClock.elapsedRealtime() + remainMs, null, true)

                for (i in ROW.indices) {
                    val isNext = ROW[i] == next.name
                    rv.setTextViewText(NAME_IDS[i], ROW[i])
                    rv.setTextColor(NAME_IDS[i], if (isNext) GOLD else MUTED)
                    rv.setTextViewText(TIME_IDS[i], fmtHm(times[i]))
                    rv.setTextColor(TIME_IDS[i], if (isNext) GOLD else TEXT)
                }

                rv.setOnClickPendingIntent(R.id.wRoot, openApp)
                mgr.updateAppWidget(id, rv)
            }
            return true
        }
    }
}
