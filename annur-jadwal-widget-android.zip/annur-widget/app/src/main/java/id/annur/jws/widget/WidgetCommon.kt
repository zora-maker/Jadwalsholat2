package id.annur.jws.widget

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.time.Instant
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

val ROW_NAMES = listOf("Subuh", "Terbit", "Zuhur", "Asar", "Maghrib", "Isya")

/** Data yang dibutuhkan semua jenis widget, dihitung sekali per render. */
class WidgetData(
    val now: ZonedDateTime,
    val times: LongArray, // detik sejak tengah malam, urutan sama dengan ROW_NAMES
    val next: NextPrayer,
    val nextIdx: Int,
    val remainMs: Long
)

object WidgetCommon {
    val DATE_FMT: DateTimeFormatter = DateTimeFormatter.ofPattern("EEE, d MMM", Locale.forLanguageTag("id-ID"))
    private val HM: DateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm")

    fun data(s: Settings): WidgetData {
        val zone = s.zone()
        val now = ZonedDateTime.now(zone)
        val cfg = s.config()
        val t = PrayerCalc.compute(cfg, now.year, now.monthValue, now.dayOfMonth)
        val next = PrayerCalc.nextPrayer(cfg, zone, now)
        val times = longArrayOf(t.subuh, t.terbit, t.zuhur, t.asar, t.maghrib, t.isya)
        return WidgetData(
            now = now,
            times = times,
            next = next,
            nextIdx = ROW_NAMES.indexOf(next.name),
            remainMs = next.epochMs - System.currentTimeMillis()
        )
    }

    /** Jam "HH:mm" dari waktu epoch, di zona waktu masjid. Benar juga untuk Subuh besok. */
    fun hhmmAt(epochMs: Long, zone: ZoneId): String =
        Instant.ofEpochMilli(epochMs).atZone(zone).format(HM)

    fun openApp(ctx: Context): PendingIntent =
        PendingIntent.getActivity(
            ctx, 0, Intent(ctx, ConfigActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
}
