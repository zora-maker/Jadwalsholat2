package id.annur.jws.widget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.graphics.Color
import android.os.SystemClock
import android.widget.RemoteViews

/** Widget ringkas: sholat berikutnya, jamnya besar, dan hitung mundur. Cocok untuk ukuran kecil. */
class PrayerCompactWidget : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        Scheduler.refresh(ctx)
    }

    override fun onDeleted(ctx: Context, ids: IntArray) {
        Scheduler.refresh(ctx)
    }

    override fun onDisabled(ctx: Context) {
        Scheduler.refresh(ctx)
    }

    companion object {
        private val GOLD = Color.parseColor("#F2B84B")
        private val MUTED = Color.parseColor("#9FB8C8")

        fun renderAll(ctx: Context, s: Settings): Boolean {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, PrayerCompactWidget::class.java))
            if (ids.isEmpty()) return false

            val d = WidgetCommon.data(s)
            val zone = s.zone()
            val open = WidgetCommon.openApp(ctx)

            for (id in ids) {
                val rv = RemoteViews(ctx.packageName, R.layout.widget_compact)
                rv.setTextViewText(R.id.cName, s.name)
                rv.setTextViewText(R.id.cNext, "Menuju ${d.next.name}")
                rv.setTextViewText(R.id.cTime, WidgetCommon.hhmmAt(d.next.epochMs, zone))
                rv.setTextColor(R.id.cNext, MUTED)
                rv.setTextColor(R.id.cTime, GOLD)
                rv.setChronometerCountDown(R.id.cCount, true)
                rv.setChronometer(R.id.cCount, SystemClock.elapsedRealtime() + d.remainMs, null, true)
                rv.setOnClickPendingIntent(R.id.cRoot, open)
                mgr.updateAppWidget(id, rv)
            }
            return true
        }
    }
}
