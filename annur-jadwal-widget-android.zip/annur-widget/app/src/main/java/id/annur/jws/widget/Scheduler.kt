package id.annur.jws.widget

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.time.ZonedDateTime

/** Format detik sejak tengah malam menjadi "HH:mm". */
fun fmtHm(sec: Long): String {
    val m = ((sec / 60) % 1440 + 1440) % 1440
    return "%02d:%02d".format(m / 60, m % 60)
}

/**
 * Satu pintu untuk memperbarui widget, notifikasi, dan wallpaper layar kunci,
 * lalu menjadwalkan alarm berikutnya (waktu sholat berikutnya, atau tengah malam bila lebih dulu).
 *
 * [withWallpaper] hanya true saat waktu sholat tiba, tengah malam, atau pengaturan disimpan,
 * supaya wallpaper tidak ikut diganti setiap 30 menit saat widget diperbarui.
 */
object Scheduler {
    const val ACTION_TICK = "id.annur.jws.widget.TICK"

    fun refresh(ctx: Context, withWallpaper: Boolean = false) {
        val s = AppPrefs.load(ctx)
        val hasWidget = PrayerWidgetProvider.renderAll(ctx, s)
        if (s.notif) NotificationHelper.show(ctx, s) else NotificationHelper.hide(ctx)
        if (withWallpaper && s.lockWp) runCatching { LockWallpaper.apply(ctx, s) }
        if (hasWidget || s.notif || s.lockWp) scheduleNext(ctx, s) else cancel(ctx)
    }

    private fun pending(ctx: Context): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, 0,
            Intent(ctx, RefreshReceiver::class.java).setAction(ACTION_TICK),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    private fun scheduleNext(ctx: Context, s: Settings) {
        val zone = s.zone()
        val now = ZonedDateTime.now(zone)
        val next = PrayerCalc.nextPrayer(s.config(), zone, now)
        val midnight = now.toLocalDate().plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli()
        val at = minOf(next.epochMs, midnight) + 1000L
        // Tanpa izin alarm presisi; telat beberapa menit tidak masalah
        ctx.getSystemService(AlarmManager::class.java)
            .setAndAllowWhileIdle(AlarmManager.RTC, at, pending(ctx))
    }

    private fun cancel(ctx: Context) {
        ctx.getSystemService(AlarmManager::class.java).cancel(pending(ctx))
    }
}

/** Menerima alarm, boot selesai, aplikasi diperbarui, dan perubahan jam atau zona waktu. */
class RefreshReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        Scheduler.refresh(ctx, withWallpaper = true)
    }
}
