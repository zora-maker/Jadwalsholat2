package id.annur.jws.widget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.graphics.Color
import android.os.SystemClock
import android.view.View
import android.widget.RemoteViews

/** Widget daftar: enam waktu sholat ditumpuk ke bawah, waktu berikutnya disorot. */
class PrayerListWidget : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        Scheduler.refresh(ctx)
    }

    override fun onDeleted(ctx: Context, ids: IntArray) {
        Scheduler.refresh(ctx)
    }

    override fun onDisabled(ctx: Context) {
        Scheduler.refresh(ctx)
    }

    companion object {
        private val NAME_IDS = intArrayOf(R.id.ln0, R.id.ln1, R.id.ln2, R.id.ln3, R.id.ln4, R.id.ln5)
        private val TIME_IDS = intArrayOf(R.id.lt0, R.id.lt1, R.id.lt2, R.id.lt3, R.id.lt4, R.id.lt5)
        private val HL_IDS = intArrayOf(R.id.lh0, R.id.lh1, R.id.lh2, R.id.lh3, R.id.lh4, R.id.lh5)

        private val GOLD = Color.parseColor("#F2B84B")
        private val WHITE = Color.WHITE
        private val MUTED = Color.parseColor("#9FB8C8")

        fun renderAll(ctx: Context, s: Settings): Boolean {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, PrayerListWidget::class.java))
            if (ids.isEmpty()) return false

            val d = WidgetCommon.data(s)
            val open = WidgetCommon.openApp(ctx)

            for (id in ids) {
                val rv = RemoteViews(ctx.packageName, R.layout.widget_list)
                rv.setTextViewText(R.id.lName, s.name)
                rv.setTextViewText(R.id.lDate, WidgetCommon.DATE_FMT.format(d.now))
                rv.setTextViewText(R.id.lNext, "Menuju ${d.next.name}")
                rv.setChronometerCountDown(R.id.lCount, true)
                rv.setChronometer(R.id.lCount, SystemClock.elapsedRealtime() + d.remainMs, null, true)

                for (i in ROW_NAMES.indices) {
                    val isNext = i == d.nextIdx
                    rv.setTextViewText(NAME_IDS[i], ROW_NAMES[i])
                    rv.setTextColor(NAME_IDS[i], if (isNext) GOLD else MUTED)
                    rv.setTextViewText(TIME_IDS[i], fmtHm(d.times[i]))
                    rv.setTextColor(TIME_IDS[i], if (isNext) GOLD else WHITE)
                    rv.setViewVisibility(HL_IDS[i], if (isNext) View.VISIBLE else View.GONE)
                }

                rv.setOnClickPendingIntent(R.id.lRoot, open)
                mgr.updateAppWidget(id, rv)
            }
            return true
        }
    }
}
