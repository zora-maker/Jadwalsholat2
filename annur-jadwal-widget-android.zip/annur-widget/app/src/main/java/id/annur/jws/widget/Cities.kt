package id.annur.jws.widget

data class City(val name: String, val lat: Double, val lon: Double, val tz: Double)

/** Daftar kota dari versi web, dengan zona waktu WIB/WITA/WIT. */
object Cities {
    val all: List<City> = listOf(
        City("Cikarang Pusat", -6.2615, 107.1523, 7.0),
        City("Cibitung", -6.2636, 107.0503, 7.0),
        City("Tambun", -6.2570, 107.0080, 7.0),
        City("Bekasi Kota", -6.2383, 106.9756, 7.0),
        City("Karawang Kota", -6.3015, 107.3020, 7.0),
        City("Telukjambe", -6.3390, 107.1990, 7.0),
        City("Cikampek", -6.4128, 107.4538, 7.0),
        City("Rengasdengklok", -6.1677, 107.3017, 7.0),
        City("Banda Aceh", 5.5483, 95.3238, 7.0),
        City("Medan", 3.5952, 98.6722, 7.0),
        City("Padang", -0.9471, 100.4172, 7.0),
        City("Pekanbaru", 0.5071, 101.4478, 7.0),
        City("Batam", 1.0456, 104.0305, 7.0),
        City("Jambi", -1.6101, 103.6131, 7.0),
        City("Palembang", -2.9761, 104.7754, 7.0),
        City("Bengkulu", -3.8004, 102.2655, 7.0),
        City("Bandar Lampung", -5.45, 105.2667, 7.0),
        City("Serang", -6.12, 106.1503, 7.0),
        City("Jakarta", -6.2088, 106.8456, 7.0),
        City("Bogor", -6.595, 106.8166, 7.0),
        City("Bandung", -6.9175, 107.6191, 7.0),
        City("Cirebon", -6.732, 108.5523, 7.0),
        City("Tasikmalaya", -7.3274, 108.2207, 7.0),
        City("Semarang", -6.9667, 110.4167, 7.0),
        City("Yogyakarta", -7.7956, 110.3695, 7.0),
        City("Surabaya", -7.2575, 112.7521, 7.0),
        City("Malang", -7.9666, 112.6326, 7.0),
        City("Pontianak", -0.0263, 109.3425, 7.0),
        City("Banjarmasin", -3.3186, 114.5944, 8.0),
        City("Balikpapan", -1.2379, 116.8529, 8.0),
        City("Samarinda", -0.5022, 117.1536, 8.0),
        City("Denpasar", -8.6705, 115.2126, 8.0),
        City("Mataram", -8.5833, 116.1167, 8.0),
        City("Kupang", -10.1772, 123.607, 8.0),
        City("Makassar", -5.1477, 119.4327, 8.0),
        City("Palu", -0.8917, 119.8707, 8.0),
        City("Kendari", -3.9985, 122.513, 8.0),
        City("Manado", 1.4748, 124.8421, 8.0),
        City("Gorontalo", 0.5435, 123.0568, 8.0),
        City("Ternate", 0.7833, 127.3667, 9.0),
        City("Ambon", -3.6954, 128.1814, 9.0),
        City("Sorong", -0.8762, 131.2558, 9.0),
        City("Jayapura", -2.5337, 140.7181, 9.0)
    )
}
