package id.annur.jws.widget

import android.Manifest
import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings as AndroidSettings
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import kotlin.math.abs

private val METHOD_LABELS = listOf(
    "Kemenag RI (Subuh 20°, Isya 18°)",
    "Muhammadiyah (Subuh 18°, Isya 18°)",
    "Liga Muslim Dunia (Subuh 18°, Isya 17°)",
    "ISNA (Subuh 15°, Isya 15°)"
)

private const val REQ_NOTIF = 77

/** Pengaturan masjid. Dibuka dari ikon aplikasi, dari ketuk widget atau notifikasi, atau saat widget ditambahkan. */
class ConfigActivity : Activity() {

    private lateinit var etName: EditText
    private lateinit var etLat: EditText
    private lateinit var etLon: EditText
    private lateinit var etTz: EditText
    private lateinit var spCity: Spinner
    private lateinit var spMethod: Spinner
    private lateinit var spAsr: Spinner
    private lateinit var cbNotif: CheckBox

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_config)

        etName = findViewById(R.id.etName)
        etLat = findViewById(R.id.etLat)
        etLon = findViewById(R.id.etLon)
        etTz = findViewById(R.id.etTz)
        spCity = findViewById(R.id.spCity)
        spMethod = findViewById(R.id.spMethod)
        spAsr = findViewById(R.id.spAsr)
        cbNotif = findViewById(R.id.cbNotif)

        val s = AppPrefs.load(this)
        etName.setText(s.name)
        etLat.setText(s.lat.toString())
        etLon.setText(s.lon.toString())
        etTz.setText(s.tz.toString())
        cbNotif.isChecked = s.notif

        val methodKeys = METHODS.keys.toList()
        spMethod.adapter = adapterOf(METHOD_LABELS)
        spMethod.setSelection(methodKeys.indexOf(s.method).coerceAtLeast(0))

        spAsr.adapter = adapterOf(listOf("Syafi'i, Maliki, Hanbali", "Hanafi"))
        spAsr.setSelection(if (s.asr == 2) 1 else 0)

        val cityNames = Cities.all.map { it.name } + "Kustom"
        spCity.adapter = adapterOf(cityNames)
        val idx = Cities.all.indexOfFirst { sameSpot(it, s.lat, s.lon) }
        spCity.setSelection(if (idx >= 0) idx else cityNames.lastIndex)
        spCity.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (pos >= Cities.all.size) return // "Kustom": biarkan isian apa adanya
                val c = Cities.all[pos]
                etLat.setText(c.lat.toString())
                etLon.setText(c.lon.toString())
                etTz.setText(c.tz.toString())
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        findViewById<Button>(R.id.btnSave).setOnClickListener { save() }

        // Di HP Xiaomi/Redmi dan sejenisnya, sistem bisa mematikan aplikasi di latar belakang
        findViewById<Button>(R.id.btnBattery).setOnClickListener {
            startActivity(
                Intent(AndroidSettings.ACTION_APPLICATION_DETAILS_SETTINGS)
                    .setData(Uri.fromParts("package", packageName, null))
            )
        }
    }

    private fun adapterOf(items: List<String>) =
        ArrayAdapter(this, android.R.layout.simple_spinner_item, items).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }

    private fun sameSpot(c: City, lat: Double, lon: Double) =
        abs(c.lat - lat) < 1e-4 && abs(c.lon - lon) < 1e-4

    private fun save() {
        val lat = etLat.text.toString().toDoubleOrNull()
        val lon = etLon.text.toString().toDoubleOrNull()
        val tz = etTz.text.toString().toDoubleOrNull()
        if (lat == null || lon == null || tz == null ||
            lat !in -90.0..90.0 || lon !in -180.0..180.0 || tz !in -12.0..14.0
        ) {
            Toast.makeText(this, "Periksa lintang, bujur, dan UTC", Toast.LENGTH_LONG).show()
            return
        }

        val method = METHODS.keys.toList()[spMethod.selectedItemPosition]
        AppPrefs.save(
            this,
            Settings(
                name = etName.text.toString().trim().ifEmpty { "Masjid An-Nur" }.take(40),
                lat = lat,
                lon = lon,
                tz = tz,
                method = method,
                asr = if (spAsr.selectedItemPosition == 1) 2 else 1,
                notif = cbNotif.isChecked
            )
        )

        // Jika dibuka sebagai layar konfigurasi widget, kembalikan id-nya agar widget ditambahkan
        val wid = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
        if (wid != AppWidgetManager.INVALID_APPWIDGET_ID) {
            setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, wid))
        }

        Scheduler.refresh(this)

        // Android 13 ke atas: notifikasi butuh izin dari pengguna
        if (cbNotif.isChecked && Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
            return
        }

        Toast.makeText(this, "Pengaturan disimpan", Toast.LENGTH_SHORT).show()
        finish()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (code != REQ_NOTIF) return
        val ok = results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED
        if (ok) Scheduler.refresh(this)
        Toast.makeText(
            this,
            if (ok) "Pengaturan disimpan" else "Izin notifikasi ditolak, notifikasi tidak akan tampil",
            Toast.LENGTH_LONG
        ).show()
        finish()
    }
}
