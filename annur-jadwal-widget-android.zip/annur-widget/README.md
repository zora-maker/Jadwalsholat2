# Jadwal Sholat An-Nur: widget dan notifikasi lock screen (Android)

Widget layar utama dan notifikasi tetap dengan hitung mundur ke waktu sholat
berikutnya. Perhitungan waktu dilakukan di perangkat (algoritma yang sama dengan
versi web), tanpa internet.

## Cara membangun

1. Buka folder ini di Android Studio (Hedgehog 2023.1.1 atau lebih baru).
2. Biarkan Gradle sync selesai. Android Studio akan membuat Gradle wrapper sendiri.
3. Jalankan ke perangkat Android 8.0 (API 26) ke atas, atau buat APK lewat
   Build > Build Bundle(s) / APK(s) > Build APK(s).

## Cara memakai

1. Buka aplikasi "Jadwal Sholat An-Nur", isi nama masjid dan kota.
2. Biarkan "Tampilkan notifikasi tetap di lock screen" tercentang, lalu Simpan.
   Di Android 13 ke atas, izinkan notifikasi saat diminta.
3. Widget (opsional): tekan lama layar utama, pilih Widget, lalu "Jadwal Sholat An-Nur".
4. Ketuk widget atau notifikasi kapan saja untuk membuka pengaturan.

## Agar notifikasi muncul di lock screen

- Pengaturan > Notifikasi: pastikan "Jadwal sholat" aktif dan tampilkan di layar kunci
  (lock screen) dengan isi lengkap, bukan "sembunyikan konten sensitif".

## Redmi / Xiaomi (HyperOS), dan HP lain yang agresif mematikan aplikasi

Tanpa langkah ini, sistem bisa menghentikan aplikasi sehingga notifikasi tidak diperbarui.
Tombol "Pengaturan aplikasi" di dalam aplikasi membuka halaman info aplikasi. Lalu:
1. Aktifkan Mulai otomatis (Autostart).
2. Hemat baterai > pilih "Tanpa batasan" (No restrictions).
3. Di layar aplikasi terbaru, kunci aplikasi (tahan lama kartunya, pilih kunci).

## Catatan

- Hitung mundur di widget dan notifikasi memakai Chronometer milik sistem, jadi tetap
  berjalan meski aplikasi ditutup. Alarm hanya memperbarui isi saat waktu sholat tiba
  dan saat tengah malam.
- Notifikasi bisa digeser hilang di Android 14 ke atas. Ia muncul lagi pada pembaruan
  berikutnya, atau tekan Simpan di aplikasi.
- Widget langsung di lock screen hanya ada di Android 16 ke atas pada HP yang mendukung.
- Waktu Dhuha tidak ditampilkan agar muat. Belum ada suara adzan.
