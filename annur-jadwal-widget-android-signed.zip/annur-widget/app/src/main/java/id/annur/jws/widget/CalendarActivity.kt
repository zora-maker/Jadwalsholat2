package id.annur.jws.widget

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import java.time.LocalDate
import java.time.LocalTime
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * Kalender Masehi dan Hijriyah untuk mencatat kegiatan.
 * Tiap kotak menampilkan tanggal utama dan tanggal kalender lainnya. Kegiatan bisa diberi jam dan pengingat.
 */
class CalendarActivity : Activity() {
    private lateinit var s: Settings
    private var hijriMode = false
    private var ym: YearMonth = YearMonth.now()
    private var hy = 1448
    private var hm = 1
    private var selected: LocalDate = LocalDate.now()

    private lateinit var titleView: TextView
    private lateinit var subView: TextView
    private lateinit var segM: TextView
    private lateinit var segH: TextView
    private lateinit var gridBox: LinearLayout
    private lateinit var detailBox: LinearLayout

    private val dayFmt = DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", Locale.forLanguageTag("id-ID"))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        s = AppPrefs.load(this)
        hijriMode = getSharedPreferences("annur_state", MODE_PRIVATE).getBoolean("cal_hijri", false)
        selected = LocalDate.now(s.zone())
        syncFromSelected()
        buildUi()
        render()
    }

    private fun today(): LocalDate = LocalDate.now(s.zone())

    private fun syncFromSelected() {
        ym = YearMonth.from(selected)
        val h = runCatching { Hijri.of(selected, s.hijriOffset) }.getOrNull()
        if (h != null) {
            hy = h.y
            hm = h.m
        }
    }

    private fun buildUi() {
        val root = vbox()
        root.setBackgroundColor(C.BG)
        root.addView(topBar("Kalender dan kegiatan") { finish() })

        val scroll = ScrollView(this)
        val col = vbox(16)

        // Pilihan jenis kalender dan tombol hari ini
        val seg = hbox()
        segM = pill("Masehi", !hijriMode).apply { setOnClickListener { setMode(false) } }
        segH = pill("Hijriyah", hijriMode).apply { setOnClickListener { setMode(true) } }
        seg.addView(segM)
        seg.addView(segH, LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = dp(8) })
        seg.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        seg.addView(pill("Hari ini", false).apply {
            setOnClickListener {
                selected = today()
                syncFromSelected()
                render()
            }
        })
        col.put(seg)

        // Kartu bulan
        val card = card()
        val nav = hbox()
        nav.addView(label("‹", 30f, C.TEXT).apply {
            setPadding(dp(8), 0, dp(16), dp(4))
            setOnClickListener { shift(-1) }
        })
        val tbox = vbox().apply { gravity = Gravity.CENTER_HORIZONTAL }
        titleView = label("", 19f, C.TEXT, true).apply { gravity = Gravity.CENTER }
        subView = label("", 12f, C.GOLD).apply { gravity = Gravity.CENTER }
        tbox.addView(titleView)
        tbox.addView(subView)
        nav.addView(tbox, LinearLayout.LayoutParams(0, WRAP, 1f))
        nav.addView(label("›", 30f, C.TEXT).apply {
            setPadding(dp(16), 0, dp(8), dp(4))
            setOnClickListener { shift(1) }
        })
        card.addView(nav)

        val names = listOf("Sen", "Sel", "Rab", "Kam", "Jum", "Sab", "Min")
        val head = hbox()
        for ((i, n) in names.withIndex()) {
            head.addView(
                label(n, 11f, if (i == 4) C.GOLD else C.MUTED).apply { gravity = Gravity.CENTER },
                LinearLayout.LayoutParams(0, WRAP, 1f)
            )
        }
        card.put(head, 12)
        gridBox = vbox()
        card.put(gridBox, 4)
        col.put(card, 12)

        detailBox = vbox()
        col.put(detailBox, 12)

        scroll.addView(col)
        root.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))
        setContentView(root)
    }

    private fun setMode(h: Boolean) {
        hijriMode = h
        getSharedPreferences("annur_state", MODE_PRIVATE).edit().putBoolean("cal_hijri", h).apply()
        syncFromSelected()
        segM.styleAsPill(!h)
        segH.styleAsPill(h)
        render()
    }

    private fun shift(delta: Int) {
        if (!hijriMode) {
            ym = ym.plusMonths(delta.toLong())
            selected = if (YearMonth.from(today()) == ym) today() else ym.atDay(1)
        } else {
            hm += delta
            if (hm > 12) { hm = 1; hy++ } else if (hm < 1) { hm = 12; hy-- }
            hy = hy.coerceIn(1400, 1600)
            val f = runCatching { Hijri.firstOfMonth(hy, hm, s.hijriOffset) }.getOrNull()
            if (f != null) selected = f
            val t = today()
            val ht = runCatching { Hijri.of(t, s.hijriOffset) }.getOrNull()
            if (ht != null && ht.y == hy && ht.m == hm) selected = t
        }
        render()
    }

    private fun render() {
        val off = s.hijriOffset
        val first: LocalDate
        val last: LocalDate
        if (!hijriMode) {
            first = ym.atDay(1)
            last = ym.atEndOfMonth()
        } else {
            first = runCatching { Hijri.firstOfMonth(hy, hm, off) }.getOrDefault(LocalDate.now())
            last = first.plusDays((runCatching { Hijri.lengthOfMonth(hy, hm) }.getOrDefault(30) - 1).toLong())
        }

        // Judul bulan
        val h1 = runCatching { Hijri.of(first, off) }.getOrNull()
        val h2 = runCatching { Hijri.of(last, off) }.getOrNull()
        if (!hijriMode) {
            titleView.text = "${Hijri.MONTHS_ID[ym.monthValue - 1]} ${ym.year}"
            subView.text = if (h1 != null && h2 != null) {
                if (h1.m == h2.m && h1.y == h2.y) "${h1.monthName} ${h1.y} H"
                else "${h1.monthName} ${h1.y} – ${h2.monthName} ${h2.y} H"
            } else ""
        } else {
            titleView.text = "${Hijri.MONTHS[hm - 1]} $hy H"
            subView.text = if (first.monthValue == last.monthValue && first.year == last.year)
                "${Hijri.MONTHS_ID[first.monthValue - 1]} ${first.year}"
            else "${Hijri.MON_SHORT[first.monthValue - 1]} – ${Hijri.MON_SHORT[last.monthValue - 1]} ${last.year}"
        }

        val counts = EventStore.countByDate(this)
        val todayDate = today()
        val start = first.minusDays((first.dayOfWeek.value - 1).toLong())

        gridBox.removeAllViews()
        for (r in 0 until 6) {
            val rowStart = start.plusDays((r * 7).toLong())
            if (rowStart.isAfter(last)) break
            val row = hbox()
            for (cc in 0 until 7) {
                val date = rowStart.plusDays(cc.toLong())
                val hd = runCatching { Hijri.of(date, off) }.getOrNull()
                val inMonth = if (!hijriMode) YearMonth.from(date) == ym
                else hd != null && hd.y == hy && hd.m == hm
                val cell = DayCellView(this)
                if (!hijriMode) {
                    cell.main = date.dayOfMonth.toString()
                    cell.sub = if (hd == null) "" else if (hd.d == 1) "1 ${hd.monthName.take(3)}" else hd.d.toString()
                } else {
                    cell.main = hd?.d?.toString() ?: ""
                    cell.sub = if (date.dayOfMonth == 1) "1 ${Hijri.MON_SHORT[date.monthValue - 1]}" else date.dayOfMonth.toString()
                }
                cell.inMonth = inMonth
                cell.isToday = date == todayDate
                cell.isSelected2 = date == selected
                cell.eventCount = counts[date] ?: 0
                cell.friday = cc == 4
                cell.major = hd != null && Hijri.special(hd, date.dayOfWeek).any { it.major }
                cell.setOnClickListener {
                    selected = date
                    if (!inMonth) syncFromSelected()
                    render()
                }
                row.addView(cell, LinearLayout.LayoutParams(0, dp(56), 1f))
            }
            gridBox.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
        }
        renderDetail()
    }

    private fun renderDetail() {
        detailBox.removeAllViews()
        val off = s.hijriOffset
        val hd = runCatching { Hijri.of(selected, off) }.getOrNull()

        val head = card()
        head.addView(label(dayFmt.format(selected), 17f, C.TEXT, true))
        if (hd != null) head.put(label(hd.toString(), 14f, C.GOLD), 2)
        val sp = if (hd != null) Hijri.special(hd, selected.dayOfWeek) else emptyList()
        if (sp.isNotEmpty()) {
            val chips = vbox()
            for (x in sp) {
                chips.put(label("• ${x.label}", 13f, if (x.major) C.GOLD else C.TEAL), 4)
            }
            head.put(chips, 6)
        }
        detailBox.put(head)

        val evs = EventStore.forDate(this, selected)
        val list = card()
        list.addView(label("Kegiatan", 16f, C.GOLD, true))
        if (evs.isEmpty()) {
            list.put(label("Belum ada kegiatan pada tanggal ini.", 13f, C.MUTED), 8)
        }
        for (e in evs) {
            val row = hbox().apply {
                setPadding(dp(12), dp(10), dp(12), dp(10))
                background = roundBg(C.CARD2, 14)
                isClickable = true
                setOnClickListener { editor(e) }
            }
            row.addView(label(e.timeLabel(), 13f, C.TEAL, true).apply { minWidth = dp(64) })
            val tb = vbox()
            tb.addView(label(e.title, 15f, C.TEXT, true))
            if (e.note.isNotBlank()) tb.put(label(e.note, 12f, C.MUTED), 2)
            if (e.time != null && e.remindMin >= 0) {
                tb.put(label(if (e.remindMin == 0) "Pengingat saat waktunya" else "Pengingat ${e.remindMin} menit sebelumnya", 11f, C.MUTED), 2)
            }
            row.addView(tb, LinearLayout.LayoutParams(0, WRAP, 1f))
            list.put(row, 8)
        }
        detailBox.put(list, 12)

        val add = label("＋  Tambah kegiatan", 15f, android.graphics.Color.parseColor("#1A1405"), true).apply {
            gravity = Gravity.CENTER
            background = roundBg(C.GOLD, 26)
            setPadding(dp(16), dp(14), dp(16), dp(14))
            isClickable = true
            setOnClickListener { editor(null) }
        }
        detailBox.put(add, 12)
        detailBox.put(View(this), 0, MATCH, dp(24))
    }

    /** Dialog tambah atau ubah kegiatan. */
    private fun editor(existing: Ev?) {
        var date = existing?.date ?: selected
        var time: LocalTime? = existing?.time

        val box = vbox(20)
        val etTitle = field("Judul kegiatan", existing?.title ?: "")
        val etNote = field("Catatan (opsional)", existing?.note ?: "").apply { minLines = 2 }
        box.addView(etTitle)
        box.put(etNote, 10)

        val btnDate = pill("", false, 14f)
        val btnTime = pill("", false, 14f)
        fun refreshButtons() {
            btnDate.text = "Tanggal: " + Hijri.both(date, s.hijriOffset)
            btnTime.text = if (time == null) "Jam: tanpa jam (seharian)" else "Jam: " + "%02d:%02d".format(time!!.hour, time!!.minute)
        }
        refreshButtons()
        btnDate.setOnClickListener {
            DatePickerDialog(this, { _, y, m, d ->
                date = LocalDate.of(y, m + 1, d)
                refreshButtons()
            }, date.year, date.monthValue - 1, date.dayOfMonth).show()
        }
        btnTime.setOnClickListener {
            val t0 = time ?: LocalTime.of(8, 0)
            TimePickerDialog(this, { _, h, mi ->
                time = LocalTime.of(h, mi)
                refreshButtons()
            }, t0.hour, t0.minute, true).show()
        }
        box.put(btnDate, 12)
        box.put(btnTime, 8)
        box.put(label("Hapus jam", 12f, C.MUTED).apply {
            setPadding(dp(4), dp(8), dp(4), dp(4))
            setOnClickListener {
                time = null
                refreshButtons()
            }
        }, 0)

        val remindLabels = listOf("Tanpa pengingat", "Saat waktunya", "10 menit sebelum", "30 menit sebelum", "1 jam sebelum")
        val remindValues = listOf(-1, 0, 10, 30, 60)
        val spRemind = Spinner(this)
        spRemind.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, remindLabels).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        spRemind.setSelection(remindValues.indexOf(existing?.remindMin ?: -1).coerceAtLeast(0))
        box.put(label("Pengingat (butuh jam)", 12f, C.MUTED), 8)
        box.put(spRemind, 0)

        val builder = AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
            .setTitle(if (existing == null) "Kegiatan baru" else "Ubah kegiatan")
            .setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("Simpan", null)
            .setNegativeButton("Batal", null)
        if (existing != null) builder.setNeutralButton("Hapus", null)
        val dlg = builder.create()
        dlg.setOnShowListener {
            dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val title = etTitle.text.toString().trim()
                if (title.isEmpty()) {
                    Toast.makeText(this, "Isi judul kegiatan", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                val remind = if (time == null) -1 else remindValues[spRemind.selectedItemPosition]
                EventStore.upsert(
                    this,
                    Ev(existing?.id ?: System.currentTimeMillis(), date, time, title.take(80), etNote.text.toString().trim().take(300), remind)
                )
                afterChange(remind >= 0)
                selected = date
                syncFromSelected()
                render()
                dlg.dismiss()
            }
            if (existing != null) {
                dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                    EventStore.delete(this, existing.id)
                    afterChange(false)
                    render()
                    dlg.dismiss()
                }
            }
        }
        dlg.show()
    }

    private fun afterChange(needsNotif: Boolean) {
        EventReminder.scheduleNext(this)
        Scheduler.refresh(this)
        if (needsNotif && Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 78)
        }
    }
}
