package id.annur.jws.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.SystemClock
import android.text.Spannable
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import android.view.View
import android.widget.RemoteViews
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Dasar untuk semua widget tambahan. Penggambaran dilakukan terpusat oleh [ArtWidgets]. */
abstract class ArtProvider : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) = Scheduler.refresh(ctx)
    override fun onDeleted(ctx: Context, ids: IntArray) {
        WidgetThemes.remove(ctx, ids)
        Scheduler.refresh(ctx)
    }
    override fun onDisabled(ctx: Context) = Scheduler.refresh(ctx)
    override fun onAppWidgetOptionsChanged(ctx: Context, mgr: AppWidgetManager, id: Int, opts: Bundle) =
        Scheduler.refresh(ctx)
}

class SceneSenjaWidget : ArtProvider()
class SceneMalamWidget : ArtProvider()
class SceneFajarWidget : ArtProvider()
class SceneEmasWidget : ArtProvider()
class StripWidget : ArtProvider()
class RoundWidget : ArtProvider()
class ThemeSquareWidget : ArtProvider()
class ThemeWideWidget : ArtProvider()
class ThemeSlimWidget : ArtProvider()

/**
 * Enam widget tambahan: empat bertema masjid (Senja, Malam, Fajar, Emas), kartu ringkas, dan bulat.
 * Jam memakai TextClock dan hitung mundur memakai Chronometer, jadi hidup sendiri di sisi launcher.
 * Latar digambar sesuai ukuran widget saat ini.
 */
object ArtWidgets {
    private val CLASSES: List<Class<*>> = listOf(
        SceneSenjaWidget::class.java, SceneMalamWidget::class.java,
        SceneFajarWidget::class.java, SceneEmasWidget::class.java,
        StripWidget::class.java, RoundWidget::class.java,
        ThemeSquareWidget::class.java, ThemeWideWidget::class.java, ThemeSlimWidget::class.java
    )

    val NAMES = listOf("Subuh", "Terbit", "Zuhur", "Asar", "Maghrib", "Isya")

    /** Lima baris yang ditampilkan: Terbit tidak ikut. Nilai adalah indeks ke enam waktu. */
    val SHOWN = intArrayOf(0, 2, 3, 4, 5)

    private val S_NAME = intArrayOf(R.id.sn0, R.id.sn1, R.id.sn2, R.id.sn3, R.id.sn4)
    private val S_TIME = intArrayOf(R.id.st0, R.id.st1, R.id.st2, R.id.st3, R.id.st4)
    private val S_HL = intArrayOf(R.id.sh0, R.id.sh1, R.id.sh2, R.id.sh3, R.id.sh4)
    private val G_NAME = intArrayOf(R.id.gn0, R.id.gn1, R.id.gn2, R.id.gn3, R.id.gn4)
    private val G_TIME = intArrayOf(R.id.gt0, R.id.gt1, R.id.gt2, R.id.gt3, R.id.gt4)

    private val DATE_FMT = DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", Locale.forLanguageTag("id-ID"))

    class Data(
        val times: LongArray,
        val passed: BooleanArray,
        val markIdx: Int,
        val nextName: String,
        val remainMs: Long,
        val focus: FocusInfo?
    )

    /** Menggambar ulang semua widget tambahan. Mengembalikan true bila ada yang terpasang. */
    fun renderAll(ctx: Context, s: Settings): Boolean {
        val mgr = AppWidgetManager.getInstance(ctx)
        val groups = CLASSES.map { mgr.getAppWidgetIds(ComponentName(ctx, it)) }
        if (groups.all { it.isEmpty() }) return false

        val zone = s.zone()
        val now = ZonedDateTime.now(zone)
        val cfg = s.config()
        val focus = Focus.current(s, now)
        val today = PrayerCalc.compute(cfg, now.year, now.monthValue, now.dayOfMonth)
        var times = longArrayOf(today.subuh, today.terbit, today.zuhur, today.asar, today.maghrib, today.isya)
        val nowSec = now.toLocalTime().toSecondOfDay().toLong()
        var passed = BooleanArray(6) { times[it] <= nowSec }
        if (focus == null && passed.all { it }) {
            val tom = now.toLocalDate().plusDays(1)
            val tt = PrayerCalc.compute(cfg, tom.year, tom.monthValue, tom.dayOfMonth)
            times = longArrayOf(tt.subuh, tt.terbit, tt.zuhur, tt.asar, tt.maghrib, tt.isya)
            passed = BooleanArray(6)
        }
        val next = PrayerCalc.nextPrayer(cfg, zone, now)
        val d = Data(
            times, passed,
            focus?.idx ?: NAMES.indexOf(next.name),
            next.name,
            next.epochMs - System.currentTimeMillis(),
            focus
        )

        val hijri = Hijri.today(s, now).toString()
        val place = if (s.autoLoc && s.placeName.isNotEmpty()) s.placeName else ""
        val marq = Marquee.build(ctx, s, now)
        val openApp = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )

        for ((k, ids) in groups.withIndex()) {
            for (id in ids) {
                val rv = when {
                    k <= 3 -> scene(ctx, mgr, id, k, s, now, d, hijri, place, marq)
                    k == 4 -> strip(ctx, s, d, hijri)
                    k == 5 -> round(ctx, mgr, id, s, d)
                    else -> ThemeWidgets.render(ctx, mgr, id, k - 6, s, now, d, place)
                }
                rv.setOnClickPendingIntent(
                    when {
                        k <= 3 -> R.id.sRoot
                        k == 4 -> R.id.gRoot
                        k == 5 -> R.id.rRoot
                        k == 6 -> R.id.qRoot
                        k == 7 -> R.id.lRoot
                        else -> R.id.tRoot
                    },
                    openApp
                )
                mgr.updateAppWidget(id, rv)
            }
        }
        return true
    }

    /** Ukuran widget dalam piksel dari opsi launcher. Dibatasi supaya aman dikirim lewat RemoteViews. */
    fun sizePx(ctx: Context, mgr: AppWidgetManager, id: Int, defW: Int, defH: Int): IntArray {
        val o = mgr.getAppWidgetOptions(id)
        val dens = ctx.resources.displayMetrics.density
        var w = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0).let { if (it > 0) it else defW } * dens
        var h = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0).let { if (it > 0) it else defH } * dens
        val maxPx = 1.2e6f // sekitar 4,8 MB untuk ARGB_8888
        val area = w * h
        if (area > maxPx) {
            val f = Math.sqrt((maxPx / area).toDouble()).toFloat()
            w *= f
            h *= f
        }
        return intArrayOf(w.toInt().coerceAtLeast(120), h.toInt().coerceAtLeast(120))
    }

    private fun scene(
        ctx: Context, mgr: AppWidgetManager, id: Int, k: Int, s: Settings, now: ZonedDateTime,
        d: Data, hijri: String, place: String, marq: String
    ): RemoteViews {
        val pal = SceneArt.pals[k]
        val rv = RemoteViews(ctx.packageName, R.layout.widget_scene)
        val dens = ctx.resources.displayMetrics.density
        val sz = sizePx(ctx, mgr, id, 300, 180)
        rv.setImageViewBitmap(R.id.sBg, SceneArt.scene(k, sz[0], sz[1], dens))

        // Nama masjid: kata terakhir berwarna aksen
        val name = SpannableString(s.name)
        val cut = s.name.trim().lastIndexOf(' ')
        if (cut > 0) {
            name.setSpan(ForegroundColorSpan(pal.accent), cut + 1, name.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        rv.setTextViewText(R.id.sName, name)
        if (place.isEmpty()) {
            rv.setViewVisibility(R.id.sPlace, View.GONE)
        } else {
            rv.setViewVisibility(R.id.sPlace, View.VISIBLE)
            rv.setTextViewText(R.id.sPlace, place)
        }
        rv.setTextViewText(R.id.sDate, DATE_FMT.format(now))
        rv.setTextViewText(R.id.sHijri, hijri)

        // Pil hitung mundur, atau hitung maju saat waktu sholat baru tiba
        rv.setTextColor(R.id.sCount, pal.accent)
        countdown(rv, R.id.sCount, d)

        for (i in 0..4) {
            val idx = SHOWN[i]
            val mark = idx == d.markIdx
            rv.setTextViewText(S_NAME[i], NAMES[idx])
            rv.setTextViewText(S_TIME[i], fmtHm(d.times[idx]))
            rv.setViewVisibility(S_HL[i], if (mark) View.VISIBLE else View.GONE)
            rv.setInt(S_HL[i], "setColorFilter", pal.accent)
            val dim = d.passed[idx] && !mark
            rv.setTextColor(S_NAME[i], if (mark) DARK_ON_ACCENT else if (dim) 0x99FFFFFF.toInt() else 0xFFFFFFFF.toInt())
            rv.setTextColor(S_TIME[i], if (mark) DARK_ON_ACCENT else if (dim) 0x99FFFFFF.toInt() else 0xFFFFFFFF.toInt())
        }

        if (marq.isEmpty()) {
            rv.setViewVisibility(R.id.sMarq, View.GONE)
        } else {
            rv.setViewVisibility(R.id.sMarq, View.VISIBLE)
            rv.setTextViewText(R.id.sMarq, marq)
        }
        return rv
    }

    private val DARK_ON_ACCENT = 0xFF2B1B00.toInt()

    /** Mengatur Chronometer: hitung mundur menuju sholat berikutnya, atau hitung maju sejak waktu tiba. */
    fun countdown(rv: RemoteViews, viewId: Int, d: Data) {
        val f = d.focus
        if (f != null) {
            val elapsed = System.currentTimeMillis() - f.startMs
            rv.setChronometerCountDown(viewId, false)
            rv.setChronometer(viewId, SystemClock.elapsedRealtime() - elapsed, "${f.name} tiba  %s", true)
        } else {
            rv.setChronometerCountDown(viewId, true)
            rv.setChronometer(viewId, SystemClock.elapsedRealtime() + d.remainMs, "${d.nextName}  %s", true)
        }
    }

    private fun strip(ctx: Context, s: Settings, d: Data, hijri: String): RemoteViews {
        val th = Themes.get(s.theme)
        val rv = RemoteViews(ctx.packageName, R.layout.widget_strip)
        if (th.bgRes == 0) rv.setInt(R.id.gRoot, "setBackgroundColor", 0)
        else rv.setInt(R.id.gRoot, "setBackgroundResource", th.bgRes)
        rv.setTextColor(R.id.gHm, th.clock)
        rv.setTextColor(R.id.gCount, th.accent)
        countdown(rv, R.id.gCount, d)
        for (i in 0..4) {
            val idx = SHOWN[i]
            val mark = idx == d.markIdx
            rv.setTextViewText(G_NAME[i], NAMES[idx])
            rv.setTextViewText(G_TIME[i], fmtHm(d.times[idx]))
            rv.setTextColor(G_NAME[i], if (mark) th.accent else th.muted)
            rv.setTextColor(G_TIME[i], if (mark) th.accent else if (d.passed[idx]) th.muted else th.text)
        }
        return rv
    }

    private fun round(ctx: Context, mgr: AppWidgetManager, id: Int, s: Settings, d: Data): RemoteViews {
        val th = Themes.get(s.theme)
        val rv = RemoteViews(ctx.packageName, R.layout.widget_round)
        val sz = sizePx(ctx, mgr, id, 120, 120)
        val side = minOf(sz[0], sz[1])
        rv.setImageViewBitmap(R.id.rRing, SceneArt.ring(th, d.times, d.markIdx, d.passed, side))
        rv.setTextViewText(R.id.rNext, if (d.focus != null) d.focus.name else d.nextName)
        rv.setTextColor(R.id.rNext, th.accent)
        rv.setTextColor(R.id.rHm, th.clock)
        rv.setTextColor(R.id.rCount, th.muted)
        val f = d.focus
        if (f != null) {
            val elapsed = System.currentTimeMillis() - f.startMs
            rv.setChronometerCountDown(R.id.rCount, false)
            rv.setChronometer(R.id.rCount, SystemClock.elapsedRealtime() - elapsed, "tiba +%s", true)
        } else {
            rv.setChronometerCountDown(R.id.rCount, true)
            rv.setChronometer(R.id.rCount, SystemClock.elapsedRealtime() + d.remainMs, "%s lagi", true)
        }
        return rv
    }
}
