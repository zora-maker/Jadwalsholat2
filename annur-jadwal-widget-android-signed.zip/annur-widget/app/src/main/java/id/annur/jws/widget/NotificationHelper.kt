package id.annur.jws.widget

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.time.Instant
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

/**
 * Notifikasi tetap dengan hitung mundur. Tampil di lock screen (visibilitas publik)
 * dan tidak berbunyi. Saat waktu sholat tiba, isinya berganti jadi "Waktu ... telah tiba"
 * dengan hitung maju selama jendela fokus.
 */
object NotificationHelper {
    private const val CHANNEL = "jadwal_sholat"
    private const val NOTIF_ID = 1001
    private val HM: DateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm")

    fun hide(ctx: Context) {
        ctx.getSystemService(NotificationManager::class.java).cancel(NOTIF_ID)
    }

    fun show(ctx: Context, s: Settings) {
        val nm = ctx.getSystemService(NotificationManager::class.java)

        val channel = NotificationChannel(CHANNEL, "Jadwal sholat", NotificationManager.IMPORTANCE_LOW).apply {
            description = "Waktu sholat berikutnya dan hitung mundur"
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            setShowBadge(false)
        }
        nm.createNotificationChannel(channel)

        val zone = s.zone()
        val now = ZonedDateTime.now(zone)
        val cfg = s.config()
        val t = PrayerCalc.compute(cfg, now.year, now.monthValue, now.dayOfMonth)
        val next = PrayerCalc.nextPrayer(cfg, zone, now)
        val focus = Focus.current(s, now)
        val markName = focus?.name ?: next.name

        val rows = listOf(
            "Subuh" to t.subuh,
            "Terbit" to t.terbit,
            "Zuhur" to t.zuhur,
            "Asar" to t.asar,
            "Maghrib" to t.maghrib,
            "Isya" to t.isya
        )
        fun cell(p: Pair<String, Long>) =
            (if (p.first == markName) "• " else "") + "${p.first} ${fmtHm(p.second)}"

        val line1 = rows.take(3).joinToString("    ") { cell(it) }
        val line2 = rows.drop(3).joinToString("    ") { cell(it) }

        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, ConfigActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )

        val b = Notification.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentText(s.name)
            .setStyle(Notification.BigTextStyle().bigText("$line1\n$line2"))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(Notification.CATEGORY_STATUS)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setShowWhen(true)
            .setUsesChronometer(true)
            .setContentIntent(open)

        if (focus != null) {
            b.setContentTitle("Waktu ${focus.name} telah tiba")
                .setWhen(focus.startMs)
                .setChronometerCountDown(false)
        } else {
            val nextClock = Instant.ofEpochMilli(next.epochMs).atZone(zone).format(HM)
            b.setContentTitle("Menuju ${next.name} $nextClock")
                .setWhen(next.epochMs)
                .setChronometerCountDown(true)
        }

        nm.notify(NOTIF_ID, b.build())
    }
}
