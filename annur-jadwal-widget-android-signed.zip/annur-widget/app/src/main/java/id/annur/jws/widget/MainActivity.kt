package id.annur.jws.widget

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Halaman utama: tanggal Masehi dan Hijriyah, hitung mundur, jadwal, kegiatan, dan teks berjalan. */
class MainActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private var countdown: TextView? = null
    private var nextMs = 0L

    private val tick = object : Runnable {
        override fun run() {
            val rem = nextMs - System.currentTimeMillis()
            if (rem <= 0L) {
                build()
                return
            }
            countdown?.text = fmtCount(rem / 1000L)
            handler.postDelayed(this, 1000L)
        }
    }

    private fun fmtCount(sec: Long): String =
        "%02d:%02d:%02d".format(sec / 3600, (sec / 60) % 60, sec % 60)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 79)
        }
    }

    override fun onResume() {
        super.onResume()
        Scheduler.refresh(this)
        build()
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
    }

    private fun build() {
        handler.removeCallbacks(tick)
        val s = AppPrefs.load(this)
        val now = ZonedDateTime.now(s.zone())
        val t = TodayCalc.load(s, now)
        val hj = Hijri.today(s, now)
        nextMs = t.nextMs

        val col = vbox(16)

        // Judul dan tombol pengaturan
        val top = hbox()
        val titleBox = vbox()
        titleBox.addView(label("Jadwal Sholat", 22f, C.TEXT, true))
        titleBox.addView(label(s.name, 13f, C.MUTED))
        top.addView(titleBox, LinearLayout.LayoutParams(0, WRAP, 1f))
        top.addView(pill("Pengaturan", false).apply {
            setOnClickListener { startActivity(Intent(this@MainActivity, ConfigActivity::class.java)) }
        })
        col.put(top)

        // Kartu utama
        val hero = vbox(20).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xFF1D4A5F.toInt(), 0xFF0E2D40.toInt(), 0xFF0B1F2D.toInt())
            ).apply {
                cornerRadius = dp(28).toFloat()
                setStroke(dp(1), C.LINE)
            }
        }
        hero.addView(label(DATE.format(now), 13f, C.MUTED))
        hero.put(label(hj.toString(), 26f, C.GOLD, true), 2)
        val specials = Hijri.special(hj, now.dayOfWeek)
        if (specials.isNotEmpty()) {
            hero.put(label(specials.joinToString(" • ") { it.label }, 12f, C.TEAL), 4)
        }
        hero.put(label(
            if (t.tomorrow) "Menuju Subuh besok" else "Menuju ${t.nextName}  ${t.times[t.nextIdx]}",
            14f, C.MUTED
        ), 18)
        val cd = label(fmtCount(((t.nextMs - System.currentTimeMillis()) / 1000L).coerceAtLeast(0)), 46f, C.TEXT).apply {
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        }
        countdown = cd
        hero.put(cd, 0)
        col.put(hero, 16)

        // Jadwal hari ini
        val sched = card()
        sched.addView(label(if (t.tomorrow) "Jadwal besok" else "Jadwal hari ini", 16f, C.GOLD, true))
        for (i in 0..5) {
            val row = hbox().apply {
                setPadding(dp(12), dp(10), dp(12), dp(10))
                if (i == t.nextIdx) background = roundBg(C.alpha(C.GOLD, 0.16f), 14)
            }
            val nameCol = if (i == t.nextIdx) C.GOLD else if (t.passed[i]) C.alpha(C.MUTED, 0.6f) else C.MUTED
            val timeCol = if (i == t.nextIdx) C.GOLD else if (t.passed[i]) C.alpha(C.TEXT, 0.55f) else C.TEXT
            row.addView(label(TodayCalc.NAMES[i], 15f, nameCol), LinearLayout.LayoutParams(0, WRAP, 1f))
            row.addView(label(t.times[i], 18f, timeCol, true))
            sched.put(row, if (i == 0) 8 else 2)
        }
        col.put(sched, 14)

        // Kegiatan hari ini
        val agenda = card().apply {
            isClickable = true
            setOnClickListener { startActivity(Intent(this@MainActivity, CalendarActivity::class.java)) }
        }
        val ah = hbox()
        ah.addView(label("Kegiatan hari ini", 16f, C.GOLD, true), LinearLayout.LayoutParams(0, WRAP, 1f))
        ah.addView(label("Kalender ›", 13f, C.MUTED))
        agenda.addView(ah)
        val evs = EventStore.forDate(this, now.toLocalDate())
        if (evs.isEmpty()) {
            agenda.put(label("Belum ada kegiatan. Ketuk untuk menambah di kalender.", 13f, C.MUTED), 8)
        } else {
            for (e in evs.take(4)) {
                val r = hbox()
                r.addView(label(e.timeLabel(), 13f, C.TEAL, true).apply { minWidth = dp(64) })
                r.addView(label(e.title, 15f, C.TEXT), LinearLayout.LayoutParams(0, WRAP, 1f))
                agenda.put(r, 8)
            }
            if (evs.size > 4) agenda.put(label("+${evs.size - 4} kegiatan lain", 12f, C.MUTED), 6)
        }
        col.put(agenda, 14)

        // Pratinjau teks berjalan
        val mq = Marquee.build(this, s, now)
        val mcard = card().apply {
            isClickable = true
            setOnClickListener { startActivity(Intent(this@MainActivity, ConfigActivity::class.java)) }
        }
        mcard.addView(label("Teks berjalan di widget", 12f, C.MUTED))
        if (mq.isEmpty()) {
            mcard.put(label("Belum diatur. Ketuk untuk mengisi teks di Pengaturan.", 13f, C.MUTED), 6)
        } else {
            val mv = label(mq, 15f, C.TEXT).apply {
                setSingleLine(true)
                ellipsize = TextUtils.TruncateAt.MARQUEE
                marqueeRepeatLimit = -1
                isSelected = true
            }
            mcard.put(mv, 6)
        }
        col.put(mcard, 14)

        // Pintasan
        val tiles = hbox()
        tiles.addView(tile("Kalender dan kegiatan", "Masehi dan Hijriyah") {
            startActivity(Intent(this, CalendarActivity::class.java))
        }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = dp(7) })
        tiles.addView(tile("Pengaturan", "Lokasi, widget, layar kunci") {
            startActivity(Intent(this, ConfigActivity::class.java))
        }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(7) })
        col.put(tiles, 14)

        col.put(label(getString(R.string.credit), 11f, C.MUTED).apply { gravity = Gravity.CENTER }, 18)

        setContentView(ScrollView(this).apply {
            setBackgroundColor(C.BG)
            isFillViewport = true
            addView(col)
        })
        handler.post(tick)
    }

    private fun tile(title: String, sub: String, onClick: () -> Unit): LinearLayout =
        vbox(16).apply {
            background = roundBg(C.CARD2, 20, C.LINE)
            isClickable = true
            setOnClickListener { onClick() }
            addView(label(title, 15f, C.TEXT, true))
            put(label(sub, 12f, C.MUTED), 4)
        }

    companion object {
        private val DATE: DateTimeFormatter =
            DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", Locale.forLanguageTag("id-ID"))
    }
}
