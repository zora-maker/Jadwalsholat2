package id.annur.jws.widget

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.AlertDialog
import android.app.NotificationManager
import android.content.Intent
import android.net.Uri
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings as AndroidSettings
import android.text.TextUtils
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.time.Instant
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Halaman utama: tanggal Masehi dan Hijriyah, hitung mundur, jadwal, kegiatan, dan teks berjalan. */
class MainActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private var countdown: TextView? = null
    private var nextMs = 0L
    private var locMsg = ""
    private var syncing = false

    private val tick = object : Runnable {
        override fun run() {
            val rem = nextMs - System.currentTimeMillis()
            if (rem <= 0L) {
                build()
                return
            }
            countdown?.text = fmtCount(rem / 1000L)
            handler.postDelayed(this, 1000L)
        }
    }

    private fun fmtCount(sec: Long): String =
        "%02d:%02d:%02d".format(sec / 3600, (sec / 60) % 60, sec % 60)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 79)
        }
    }

    override fun onResume() {
        super.onResume()
        Scheduler.refresh(this)
        build()
        autoSync(false)
    }

    /** Memperbarui lokasi otomatis. Bila [force], dijalankan walau lokasi otomatis belum aktif (tombol Perbarui). */
    private fun autoSync(force: Boolean) {
        val s = AppPrefs.load(this)
        if (!s.enabled) return
        if (!s.autoLoc && !force) return
        if (!LocationSync.hasPermission(this)) {
            if (force) requestPermissions(LocationSync.PERMS, 81)
            return
        }
        if (syncing) return
        syncing = true
        if (force) {
            locMsg = "Mencari lokasi..."
            build()
        }
        LocationSync.sync(this, force) { r ->
            syncing = false
            locMsg = when {
                r.error != null -> r.error
                r.changed -> "Lokasi diperbarui ke ${r.place}"
                else -> ""
            }
            if (!isFinishing && (force || r.changed || r.error != null)) build()
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (code == 81 && results.any { it == PackageManager.PERMISSION_GRANTED }) {
            val s = AppPrefs.load(this)
            if (!s.autoLoc) AppPrefs.save(this, s.copy(autoLoc = true))
            autoSync(true)
        }
    }

    private fun openMaps(s: Settings) {
        val q = "${s.lat},${s.lon}"
        val label = Uri.encode(if (s.placeName.isNotEmpty()) s.placeName else s.name)
        val geo = Intent(Intent.ACTION_VIEW, Uri.parse("geo:$q?q=$q($label)"))
        try {
            startActivity(geo)
        } catch (e: Exception) {
            runCatching {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/?api=1&query=$q")))
            }
        }
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
    }

    private fun build() {
        handler.removeCallbacks(tick)
        val s = AppPrefs.load(this)
        val now = ZonedDateTime.now(s.zone())
        val t = TodayCalc.load(s, now)
        val hj = Hijri.today(s, now)
        nextMs = t.nextMs

        val col = vbox(16)

        // Judul dan tombol pengaturan
        val top = hbox()
        val titleBox = vbox()
        titleBox.addView(label("JWS AN-NUR", 22f, C.TEXT, true))
        titleBox.addView(label(s.name, 13f, C.MUTED))
        top.addView(titleBox, LinearLayout.LayoutParams(0, WRAP, 1f))
        top.addView(pill("Pengaturan", false).apply {
            setOnClickListener { startActivity(Intent(this@MainActivity, ConfigActivity::class.java)) }
        })
        col.put(top)

        // Status aplikasi dan izin
        if (!s.enabled) {
            val off = card().apply { background = roundBg(C.alpha(C.DANGER, 0.14f), 20, C.DANGER) }
            off.addView(label("Aplikasi nonaktif", 16f, C.DANGER, true))
            off.put(label("Alarm, getar, notifikasi, pengingat kegiatan, wallpaper layar kunci, dan lokasi otomatis dihentikan. Widget tetap menampilkan jadwal.", 12f, C.MUTED), 4)
            off.put(pill("Aktifkan kembali", true).apply { setOnClickListener { toggleEnabled(true) } }, 10, WRAP)
            col.put(off, 14)
        } else {
            val missing = missingPerms(s)
            if (missing.isNotEmpty()) {
                val pc = card()
                pc.addView(label("Perlu diatur agar alarm andal", 16f, C.GOLD, true))
                for (m in missing) {
                    val r = hbox()
                    val tb = vbox()
                    tb.addView(label(m.title, 14f, C.TEXT, true))
                    tb.put(label(m.desc, 11f, C.MUTED), 2)
                    r.addView(tb, LinearLayout.LayoutParams(0, WRAP, 1f))
                    r.addView(pill("Atur", true).apply { setOnClickListener { m.fix() } })
                    pc.put(r, 12)
                }
                col.put(pc, 14)
            }
        }

        // Kartu utama
        val hero = vbox(20).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xFF1D4A5F.toInt(), 0xFF0E2D40.toInt(), 0xFF0B1F2D.toInt())
            ).apply {
                cornerRadius = dp(28).toFloat()
                setStroke(dp(1), C.LINE)
            }
        }
        hero.addView(label(DATE.format(now), 13f, C.MUTED))
        hero.put(label(hj.toString(), 26f, C.GOLD, true), 2)
        val specials = Hijri.special(hj, now.dayOfWeek)
        if (specials.isNotEmpty()) {
            hero.put(label(specials.joinToString(" • ") { it.label }, 12f, C.TEAL), 4)
        }
        hero.put(label(
            if (t.tomorrow) "Menuju Subuh besok" else "Menuju ${t.nextName}  ${t.times[t.nextIdx]}",
            14f, C.MUTED
        ), 18)
        val cd = label(fmtCount(((t.nextMs - System.currentTimeMillis()) / 1000L).coerceAtLeast(0)), 46f, C.TEXT).apply {
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        }
        countdown = cd
        hero.put(cd, 0)
        col.put(hero, 16)

        // Lokasi
        val loc = card()
        val lh = hbox()
        lh.addView(label("Lokasi", 16f, C.GOLD, true), LinearLayout.LayoutParams(0, WRAP, 1f))
        lh.addView(label(if (s.autoLoc) "Otomatis" else "Manual", 12f, if (s.autoLoc) C.TEAL else C.MUTED))
        loc.addView(lh)
        val coords = String.format(Locale.US, "%.4f, %.4f  •  UTC%+.1f", s.lat, s.lon, s.tz)
        val where = if (s.autoLoc && s.placeName.isNotEmpty()) s.placeName else s.name
        loc.put(label(where, 17f, C.TEXT, true), 8)
        loc.put(label(coords, 12f, C.MUTED), 2)
        val status = when {
            locMsg.isNotEmpty() -> locMsg
            s.autoLoc && s.locUpdated > 0L ->
                "Diperbarui " + LOC_FMT.format(Instant.ofEpochMilli(s.locUpdated).atZone(s.zone())) + ". Tersimpan, tetap jalan tanpa internet."
            else -> "Ketuk Perbarui lokasi untuk memakai posisi Anda sekarang."
        }
        loc.put(label(status, 12f, if (locMsg.isNotEmpty()) C.GOLD else C.MUTED), 8)
        val lb = hbox()
        lb.addView(pill("Perbarui lokasi", true).apply { setOnClickListener { autoSync(true) } })
        lb.addView(pill("Google Maps", false).apply { setOnClickListener { openMaps(s) } },
            LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = dp(8) })
        loc.put(lb, 12)
        col.put(loc, 14)

        // Jadwal hari ini
        val sched = card()
        sched.addView(label(if (t.tomorrow) "Jadwal besok" else "Jadwal hari ini", 16f, C.GOLD, true))
        for (i in 0..5) {
            val row = hbox().apply {
                setPadding(dp(12), dp(10), dp(12), dp(10))
                if (i == t.nextIdx) background = roundBg(C.alpha(C.GOLD, 0.16f), 14)
            }
            val nameCol = if (i == t.nextIdx) C.GOLD else if (t.passed[i]) C.alpha(C.MUTED, 0.6f) else C.MUTED
            val timeCol = if (i == t.nextIdx) C.GOLD else if (t.passed[i]) C.alpha(C.TEXT, 0.55f) else C.TEXT
            row.addView(label(TodayCalc.NAMES[i], 15f, nameCol), LinearLayout.LayoutParams(0, WRAP, 1f))
            row.addView(label(t.times[i], 18f, timeCol, true))
            sched.put(row, if (i == 0) 8 else 2)
        }
        col.put(sched, 14)

        // Kegiatan hari ini
        val agenda = card().apply {
            isClickable = true
            setOnClickListener { startActivity(Intent(this@MainActivity, CalendarActivity::class.java)) }
        }
        val ah = hbox()
        ah.addView(label("Kegiatan hari ini", 16f, C.GOLD, true), LinearLayout.LayoutParams(0, WRAP, 1f))
        ah.addView(label("Kalender ›", 13f, C.MUTED))
        agenda.addView(ah)
        val evs = EventStore.forDate(this, now.toLocalDate())
        if (evs.isEmpty()) {
            agenda.put(label("Belum ada kegiatan. Ketuk untuk menambah di kalender.", 13f, C.MUTED), 8)
        } else {
            for (e in evs.take(4)) {
                val r = hbox()
                r.addView(label(e.timeLabel(), 13f, C.TEAL, true).apply { minWidth = dp(64) })
                r.addView(label(e.title, 15f, C.TEXT), LinearLayout.LayoutParams(0, WRAP, 1f))
                agenda.put(r, 8)
            }
            if (evs.size > 4) agenda.put(label("+${evs.size - 4} kegiatan lain", 12f, C.MUTED), 6)
        }
        col.put(agenda, 14)

        // Pratinjau teks berjalan
        val mq = Marquee.build(this, s, now)
        val mcard = card().apply {
            isClickable = true
            setOnClickListener { startActivity(Intent(this@MainActivity, ConfigActivity::class.java)) }
        }
        mcard.addView(label("Teks berjalan di widget", 12f, C.MUTED))
        if (mq.isEmpty()) {
            mcard.put(label("Belum diatur. Ketuk untuk mengisi teks di Pengaturan.", 13f, C.MUTED), 6)
        } else {
            val mv = label(mq, 15f, C.TEXT).apply {
                setSingleLine(true)
                ellipsize = TextUtils.TruncateAt.MARQUEE
                marqueeRepeatLimit = -1
                isSelected = true
            }
            mcard.put(mv, 6)
        }
        col.put(mcard, 14)

        // Pintasan
        val tiles = hbox()
        tiles.addView(tile("Kalender dan kegiatan", "Masehi dan Hijriyah") {
            startActivity(Intent(this, CalendarActivity::class.java))
        }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = dp(7) })
        tiles.addView(tile("Pengaturan", "Lokasi, widget, layar kunci") {
            startActivity(Intent(this, ConfigActivity::class.java))
        }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(7) })
        col.put(tiles, 14)

        if (s.enabled) {
            col.put(pill("Nonaktifkan aplikasi", false).apply {
                setOnClickListener { confirmDisable() }
            }, 18, WRAP).also { (it.layoutParams as LinearLayout.LayoutParams).gravity = Gravity.CENTER_HORIZONTAL }
        }

        col.put(label(getString(R.string.credit), 11f, C.MUTED).apply { gravity = Gravity.CENTER }, 18)

        setContentView(ScrollView(this).apply {
            setBackgroundColor(C.BG)
            isFillViewport = true
            addView(col)
        })
        handler.post(tick)
    }

    private class PermItem(val title: String, val desc: String, val fix: () -> Unit)

    /** Izin yang belum diberikan dan memengaruhi alarm, notifikasi, atau lokasi. */
    private fun missingPerms(s: Settings): List<PermItem> {
        val out = mutableListOf<PermItem>()
        val pkg = Uri.fromParts("package", packageName, null)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            out += PermItem("Notifikasi", "Agar jadwal dan pengingat tampil, termasuk di layar kunci.") {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 79)
            }
        }
        if (Build.VERSION.SDK_INT >= 31 && !getSystemService(AlarmManager::class.java).canScheduleExactAlarms()) {
            out += PermItem("Alarm tepat waktu", "Agar getar dan tampilan sholat muncul tepat pada waktunya.") {
                runCatching { startActivity(Intent(AndroidSettings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, pkg)) }
            }
        }
        if (Build.VERSION.SDK_INT >= 34 && !getSystemService(NotificationManager::class.java).canUseFullScreenIntent()) {
            out += PermItem("Pop up di layar kunci", "Agar pop up kegiatan muncul sendiri saat layar mati atau terkunci.") {
                runCatching { startActivity(Intent("android.settings.MANAGE_APP_USE_FULL_SCREEN_INTENT", pkg)) }
            }
        }
        if (!getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)) {
            out += PermItem("Bebas hemat baterai", "Agar alarm tidak ditunda atau dimatikan sistem, terutama di Xiaomi dan Redmi.") {
                try {
                    startActivity(Intent(AndroidSettings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkg))
                } catch (e: Exception) {
                    runCatching {
                        startActivity(Intent(AndroidSettings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg))
                    }
                }
            }
        }
        if (s.autoLoc && !LocationSync.hasPermission(this)) {
            out += PermItem("Lokasi", "Agar lokasi otomatis dapat memperbarui jadwal saat Anda pindah.") {
                requestPermissions(LocationSync.PERMS, 81)
            }
        }
        return out
    }

    private fun toggleEnabled(on: Boolean) {
        val s = AppPrefs.load(this)
        AppPrefs.save(this, s.copy(enabled = on))
        if (!on) EventAlarm.stopAll(this)
        LockWallpaper.invalidate(this)
        Scheduler.refresh(this, withWallpaper = on)
        build()
    }

    private fun confirmDisable() {
        AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
            .setTitle("Nonaktifkan JWS AN-NUR?")
            .setMessage(
                "Alarm, getar, notifikasi, pengingat kegiatan, pembaruan wallpaper layar kunci, dan lokasi otomatis akan dihentikan. " +
                    "Widget tetap menampilkan jadwal. Data kegiatan dan pengaturan tetap tersimpan, dan bisa diaktifkan kembali kapan saja."
            )
            .setPositiveButton("Nonaktifkan") { _, _ -> toggleEnabled(false) }
            .setNeutralButton("Info aplikasi sistem") { _, _ ->
                runCatching {
                    startActivity(
                        Intent(AndroidSettings.ACTION_APPLICATION_DETAILS_SETTINGS)
                            .setData(Uri.fromParts("package", packageName, null))
                    )
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun tile(title: String, sub: String, onClick: () -> Unit): LinearLayout =
        vbox(16).apply {
            background = roundBg(C.CARD2, 20, C.LINE)
            isClickable = true
            setOnClickListener { onClick() }
            addView(label(title, 15f, C.TEXT, true))
            put(label(sub, 12f, C.MUTED), 4)
        }

    companion object {
        private val LOC_FMT: DateTimeFormatter =
            DateTimeFormatter.ofPattern("d MMM HH:mm", Locale.forLanguageTag("id-ID"))
        private val DATE: DateTimeFormatter =
            DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", Locale.forLanguageTag("id-ID"))
    }
}
