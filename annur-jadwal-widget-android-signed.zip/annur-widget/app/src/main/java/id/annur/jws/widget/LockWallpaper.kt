package id.annur.jws.widget

import android.app.WallpaperManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Membuat gambar jadwal sholat hari ini dan memasangnya sebagai wallpaper layar kunci.
 * Dipakai di HP yang tidak punya widget layar kunci (misalnya Android 12).
 * Gambarnya statis: diperbarui tiap waktu sholat dan tengah malam.
 *
 * Ada 8 gaya tata letak ([LockStyles.styleNames]) dan 20 palet warna ([LockStyles.palettes]).
 * Semua digambar dengan Canvas biasa pada kanvas 1080x2400, lalu diskalakan, jadi aman di Android 8 ke atas.
 * Jam sistem Android 12 menempati bagian atas layar, maka isi utama diletakkan di bagian tengah ke bawah.
 */
object LockWallpaper {
    private const val W = 1080
    private const val H = 2400
    private val ROWS = listOf("Subuh", "Terbit", "Zuhur", "Asar", "Maghrib", "Isya")
    private val DATE_FMT = DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", Locale.forLanguageTag("id-ID"))
    private val LEFT = Paint.Align.LEFT
    private val CENTER = Paint.Align.CENTER
    private val RIGHT = Paint.Align.RIGHT

    private class Scene(
        val c: Canvas,
        val p: LockPalette,
        val name: String,
        val date: String,
        val times: List<String>,
        val nextIdx: Int,
        val passed: BooleanArray,
        val nextName: String,
        val nextAt: String
    )

    /** Membuat gambar lalu memasangnya sebagai wallpaper layar kunci. */
    fun apply(ctx: Context, s: Settings) {
        val bmp = render(s, W, H)
        runCatching {
            WallpaperManager.getInstance(ctx).setBitmap(bmp, null, true, WallpaperManager.FLAG_LOCK)
        }
        bmp.recycle()
    }

    /** Menggambar wallpaper pada bitmap berukuran [outW] x [outH]. Dipakai juga untuk pratinjau. */
    fun render(s: Settings, outW: Int, outH: Int): Bitmap {
        val zone = s.zone()
        val now = ZonedDateTime.now(zone)
        val cfg = s.config()
        val next = PrayerCalc.nextPrayer(cfg, zone, now)
        val today = PrayerCalc.compute(cfg, now.year, now.monthValue, now.dayOfMonth)
        var secs = longArrayOf(today.subuh, today.terbit, today.zuhur, today.asar, today.maghrib, today.isya)
        val nowSec = now.toLocalTime().toSecondOfDay().toLong()
        var passed = BooleanArray(6) { secs[it] <= nowSec }

        // Setelah Isya, tampilkan jadwal besok seperti di widget
        if (passed.all { it }) {
            val tom = now.toLocalDate().plusDays(1)
            val tt = PrayerCalc.compute(cfg, tom.year, tom.monthValue, tom.dayOfMonth)
            secs = longArrayOf(tt.subuh, tt.terbit, tt.zuhur, tt.asar, tt.maghrib, tt.isya)
            passed = BooleanArray(6)
        }

        val bmp = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.scale(outW / W.toFloat(), outH / H.toFloat())

        val times = secs.map { fmtHm(it) }
        val idx = ROWS.indexOf(next.name).coerceAtLeast(0)
        val sc = Scene(
            c, LockStyles.palette(s.lockTheme), s.name, DATE_FMT.format(now),
            times, idx, passed, next.name, times[idx]
        )

        drawBg(sc)
        when (s.lockStyle.coerceIn(0, LockStyles.styleNames.size - 1)) {
            0 -> classic(sc)
            1 -> arch(sc)
            2 -> cards(sc)
            3 -> ring(sc)
            4 -> timeline(sc)
            5 -> mosque(sc)
            6 -> waves(sc)
            else -> star(sc)
        }
        return bmp
    }

    // ---------------------------------------------------------------- alat bantu

    private fun al(color: Int, f: Float): Int =
        Color.argb((f * 255f).toInt().coerceIn(0, 255), Color.red(color), Color.green(color), Color.blue(color))

    private fun fill(color: Int) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = color
        style = Paint.Style.FILL
    }

    private fun line(color: Int, w: Float) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = color
        style = Paint.Style.STROKE
        strokeWidth = w
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    private fun txt(
        c: Canvas, str: String, x: Float, y: Float, size: Float, color: Int,
        bold: Boolean = false, align: Paint.Align = Paint.Align.LEFT, maxW: Float = 0f
    ) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            textSize = size
            typeface = Typeface.create(if (bold) "sans-serif-medium" else "sans-serif", Typeface.NORMAL)
            textAlign = align
        }
        if (maxW > 0f) {
            val w = p.measureText(str)
            if (w > maxW) p.textSize = size * maxW / w
        }
        c.drawText(str, x, y, p)
    }

    private fun nameCol(s: Scene, i: Int): Int = when {
        i == s.nextIdx -> s.p.accent
        s.passed[i] -> al(s.p.muted, 0.55f)
        else -> s.p.muted
    }

    private fun timeCol(s: Scene, i: Int): Int = when {
        i == s.nextIdx -> s.p.accent
        s.passed[i] -> al(s.p.text, 0.5f)
        else -> s.p.text
    }

    private fun header(s: Scene, x: Float, y: Float, align: Paint.Align) {
        txt(s.c, s.name, x, y, 60f, s.p.text, true, align, 900f)
        txt(s.c, s.date, x, y + 58f, 36f, s.p.muted, false, align, 900f)
    }

    private fun drawBg(s: Scene) {
        val c = s.c
        val bg = Paint().apply {
            shader = LinearGradient(
                0f, 0f, 0f, H.toFloat(), s.p.bg,
                floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
            )
        }
        c.drawRect(0f, 0f, W.toFloat(), H.toFloat(), bg)
        val glow = Paint().apply {
            shader = RadialGradient(
                W * 0.5f, H * 0.2f, W * 0.95f,
                intArrayOf(al(s.p.accent, 0.20f), Color.TRANSPARENT), null, Shader.TileMode.CLAMP
            )
        }
        c.drawRect(0f, 0f, W.toFloat(), H.toFloat(), glow)
    }

    /** Bintang bersudut delapan. */
    private fun star8Path(cx: Float, cy: Float, r: Float, rot: Float): Path {
        val path = Path()
        val ri = r * 0.7654f
        for (k in 0 until 16) {
            val ang = ((rot + k * 22.5f - 90f) * PI / 180.0).toFloat()
            val rad = if (k % 2 == 0) r else ri
            val x = cx + rad * cos(ang)
            val y = cy + rad * sin(ang)
            if (k == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        return path
    }

    private fun halfDome(cx: Float, cy: Float, r: Float): Path {
        val path = Path()
        path.addArc(RectF(cx - r, cy - r, cx + r, cy + r), 180f, 180f)
        path.close()
        return path
    }

    // ---------------------------------------------------------------- gaya 0: Klasik Daftar

    private fun classic(s: Scene) {
        val c = s.c
        val p = s.p
        header(s, 90f, 1110f, LEFT)
        txt(c, "Menuju ${s.nextName}", 90f, 1290f, 48f, p.muted, true)
        txt(c, s.nextAt, 90f, 1450f, 170f, p.accent, true)
        val hl = fill(al(p.accent, 0.2f))
        for (i in 0..5) {
            val y = 1625f + i * 105f
            if (i == s.nextIdx) c.drawRoundRect(RectF(70f, y - 66f, 1010f, y + 30f), 40f, 40f, hl)
            txt(c, ROWS[i], 120f, y, 46f, nameCol(s, i))
            txt(c, s.times[i], 960f, y, 54f, timeCol(s, i), true, RIGHT)
        }
    }

    // ---------------------------------------------------------------- gaya 1: Lengkung Masjid

    private fun arch(s: Scene) {
        val c = s.c
        val p = s.p
        header(s, 540f, 1110f, CENTER)

        val x0 = 90f
        val x1 = 990f
        val yb = 1800f
        val path = Path().apply {
            moveTo(x0, yb)
            cubicTo(90f, 1412f, 288f, 1300f, 540f, 1250f)
            cubicTo(792f, 1300f, 990f, 1412f, x1, yb)
        }
        c.drawLine(x0, yb, x1, yb, line(al(p.muted, 0.3f), 3f))

        val shader = LinearGradient(
            x0, 0f, x1, 0f, intArrayOf(p.accent2, p.accent, p.accent2), null, Shader.TileMode.CLAMP
        )
        val glow = line(Color.WHITE, 30f).apply {
            this.shader = shader
            alpha = 70
            maskFilter = BlurMaskFilter(16f, BlurMaskFilter.Blur.NORMAL)
        }
        c.drawPath(path, glow)
        c.drawPath(path, line(Color.WHITE, 9f).apply { this.shader = shader })

        // Enam titik di lengkung (posisi sama dengan widget)
        val pts = floatArrayOf(
            90f, 1800f, 138.6f, 1520f, 540f, 1250f,
            748.8f, 1317.5f, 939.6f, 1520f, 990f, 1800f
        )
        for (i in 0..5) {
            val px = pts[i * 2]
            val py = pts[i * 2 + 1]
            when {
                i == s.nextIdx -> {
                    c.drawCircle(px, py, 36f, fill(al(p.accent, 0.3f)))
                    c.drawCircle(px, py, 18f, fill(p.accent))
                }
                s.passed[i] -> c.drawCircle(px, py, 9f, fill(al(p.muted, 0.5f)))
                else -> c.drawCircle(px, py, 13f, fill(p.accent2))
            }
        }

        txt(c, "Menuju ${s.nextName}", 540f, 1510f, 44f, p.muted, true, CENTER)
        txt(c, s.nextAt, 540f, 1680f, 150f, p.accent, true, CENTER)

        // Enam kolom waktu di bawah lengkung
        val hl = fill(al(p.accent, 0.2f))
        for (i in 0..5) {
            val cx = 90f + i * 180f
            if (i == s.nextIdx) c.drawRoundRect(RectF(cx - 80f, 1880f, cx + 80f, 2025f), 40f, 40f, hl)
            txt(c, ROWS[i], cx, 1930f, 32f, nameCol(s, i), false, CENTER, 150f)
            txt(c, s.times[i], cx, 1995f, 42f, timeCol(s, i), true, CENTER)
        }
    }

    // ---------------------------------------------------------------- gaya 2: Kartu Grid

    private fun cards(s: Scene) {
        val c = s.c
        val p = s.p
        header(s, 540f, 1110f, CENTER)

        val big = RectF(70f, 1235f, 1010f, 1535f)
        c.drawRoundRect(big, 60f, 60f, fill(al(p.accent, 0.16f)))
        c.drawRoundRect(big, 60f, 60f, line(al(p.accent, 0.6f), 4f))
        txt(c, "Menuju ${s.nextName}", 120f, 1325f, 44f, p.muted, true)
        txt(c, s.nextAt, 120f, 1485f, 150f, p.accent, true)
        c.drawPath(star8Path(880f, 1385f, 95f, 0f), line(al(p.accent, 0.7f), 5f))
        c.drawPath(star8Path(880f, 1385f, 60f, 22.5f), line(al(p.accent2, 0.6f), 3f))

        for (i in 0..5) {
            val x = 70f + (i % 2) * 490f
            val y = 1585f + (i / 2) * 195f
            val r = RectF(x, y, x + 450f, y + 165f)
            if (i == s.nextIdx) {
                c.drawRoundRect(r, 44f, 44f, fill(al(p.accent, 0.28f)))
                c.drawRoundRect(r, 44f, 44f, line(al(p.accent, 0.8f), 4f))
            } else {
                c.drawRoundRect(r, 44f, 44f, fill(al(p.text, 0.08f)))
                c.drawRoundRect(r, 44f, 44f, line(al(p.text, 0.12f), 2f))
            }
            txt(c, ROWS[i], x + 38f, y + 62f, 38f, nameCol(s, i))
            txt(c, s.times[i], x + 38f, y + 133f, 64f, timeCol(s, i), true)
        }
    }

    // ---------------------------------------------------------------- gaya 3: Cincin

    private fun ring(s: Scene) {
        val c = s.c
        val p = s.p
        header(s, 540f, 1110f, CENTER)

        val cx = 540f
        val cy = 1640f
        val r = 270f
        c.drawCircle(cx, cy, r, line(al(p.muted, 0.22f), 6f))
        val sweep = line(Color.WHITE, 14f).apply {
            shader = SweepGradient(cx, cy, intArrayOf(p.accent2, p.accent, p.accent2), null)
        }
        c.drawCircle(cx, cy, r, sweep)

        for (i in 0..5) {
            val ang = ((-90.0 + i * 60.0) * PI / 180.0).toFloat()
            val dx = cx + r * cos(ang)
            val dy = cy + r * sin(ang)
            when {
                i == s.nextIdx -> {
                    c.drawCircle(dx, dy, 38f, fill(al(p.accent, 0.3f)))
                    c.drawCircle(dx, dy, 20f, fill(p.accent))
                }
                s.passed[i] -> c.drawCircle(dx, dy, 11f, fill(al(p.muted, 0.5f)))
                else -> c.drawCircle(dx, dy, 15f, fill(p.accent2))
            }
            val lx = cx + 395f * cos(ang)
            val ly = cy + 395f * sin(ang)
            txt(c, ROWS[i], lx, ly - 4f, 34f, nameCol(s, i), false, CENTER, 150f)
            txt(c, s.times[i], lx, ly + 44f, 44f, timeCol(s, i), true, CENTER)
        }

        txt(c, "Menuju", cx, 1600f, 40f, p.muted, false, CENTER)
        txt(c, s.nextName, cx, 1660f, 50f, p.text, true, CENTER, 340f)
        txt(c, s.nextAt, cx, 1780f, 110f, p.accent, true, CENTER)
    }

    // ---------------------------------------------------------------- gaya 4: Timeline

    private fun timeline(s: Scene) {
        val c = s.c
        val p = s.p
        header(s, 90f, 1110f, LEFT)

        val lx = 170f
        val ys = FloatArray(6) { 1310f + it * 140f }
        for (i in 0..4) {
            val col = if (s.passed[i + 1]) al(p.muted, 0.3f) else al(p.accent2, 0.8f)
            c.drawLine(lx, ys[i], lx, ys[i + 1], line(col, 6f))
        }
        val hl = fill(al(p.accent, 0.16f))
        for (i in 0..5) {
            val y = ys[i]
            if (i == s.nextIdx) c.drawRoundRect(RectF(120f, y - 62f, 1010f, y + 62f), 40f, 40f, hl)
            when {
                i == s.nextIdx -> {
                    c.drawCircle(lx, y, 30f, fill(al(p.accent, 0.3f)))
                    c.drawCircle(lx, y, 16f, fill(p.accent))
                }
                s.passed[i] -> c.drawCircle(lx, y, 11f, fill(al(p.muted, 0.5f)))
                else -> c.drawCircle(lx, y, 13f, fill(p.accent2))
            }
            txt(c, ROWS[i], 240f, y + 17f, 48f, nameCol(s, i))
            txt(c, s.times[i], 975f, y + 19f, 56f, timeCol(s, i), true, RIGHT)
        }
    }

    // ---------------------------------------------------------------- gaya 5: Kubah dan Menara

    private fun mosque(s: Scene) {
        val c = s.c
        val p = s.p
        header(s, 540f, 1110f, CENTER)
        txt(c, "Menuju ${s.nextName}", 540f, 1290f, 46f, p.muted, true, CENTER)
        txt(c, s.nextAt, 540f, 1450f, 170f, p.accent, true, CENTER)

        val xs = floatArrayOf(190f, 540f, 890f)
        for (i in 0..5) {
            val x = xs[i % 3]
            val y = 1590f + (i / 3) * 150f
            txt(c, ROWS[i], x, y, 36f, nameCol(s, i), false, CENTER)
            txt(c, s.times[i], x, y + 62f, 58f, timeCol(s, i), true, CENTER)
        }
        skyline(c, p)
    }

    private fun skyline(c: Canvas, p: LockPalette) {
        val far = fill(al(p.accent, 0.14f))
        val near = fill(al(p.accent, 0.30f))

        // Bintang kecil
        val st = fill(al(p.text, 0.55f))
        val stars = floatArrayOf(120f, 1880f, 300f, 1950f, 760f, 1900f, 960f, 1960f, 540f, 1870f)
        for (i in stars.indices step 2) c.drawCircle(stars[i], stars[i + 1], 4f, st)

        // Lapisan jauh: dasar dan dua kubah kecil
        c.drawRect(0f, 2290f, W.toFloat(), H.toFloat(), far)
        c.drawPath(halfDome(130f, 2290f, 100f), far)
        c.drawPath(halfDome(950f, 2290f, 100f), far)

        // Dua menara
        for (mx in floatArrayOf(250f, 830f)) {
            c.drawRect(mx - 28f, 2020f, mx + 28f, H.toFloat(), near)
            c.drawRect(mx - 42f, 2090f, mx + 42f, 2108f, near)
            val cap = Path().apply {
                moveTo(mx - 34f, 2020f)
                lineTo(mx, 1930f)
                lineTo(mx + 34f, 2020f)
                close()
            }
            c.drawPath(cap, near)
            c.drawCircle(mx, 1922f, 9f, near)
        }

        // Kubah utama
        c.drawRect(380f, 2200f, 700f, H.toFloat(), near)
        c.drawPath(halfDome(540f, 2200f, 190f), near)
        c.drawLine(540f, 2010f, 540f, 1950f, line(al(p.accent, 0.5f), 6f))
        c.drawCircle(540f, 1938f, 16f, near)

        // Jendela
        val win = fill(al(p.accent, 0.55f))
        for (wx in floatArrayOf(470f, 540f, 610f)) {
            c.drawRoundRect(RectF(wx - 18f, 2270f, wx + 18f, 2345f), 18f, 18f, win)
        }
    }

    // ---------------------------------------------------------------- gaya 6: Gelombang

    private fun waves(s: Scene) {
        val c = s.c
        val p = s.p
        header(s, 540f, 1110f, CENTER)
        txt(c, "Menuju ${s.nextName}", 540f, 1310f, 48f, p.muted, true, CENTER)
        txt(c, s.nextAt, 540f, 1510f, 210f, p.accent, true, CENTER)

        val colW = 980f / 6f
        val hl = fill(al(p.accent, 0.2f))
        for (i in 0..5) {
            val cx = 50f + colW * (i + 0.5f)
            if (i == s.nextIdx) c.drawRoundRect(RectF(cx - 76f, 1650f, cx + 76f, 1790f), 40f, 40f, hl)
            txt(c, ROWS[i], cx, 1708f, 30f, nameCol(s, i), false, CENTER, 140f)
            txt(c, s.times[i], cx, 1762f, 40f, timeCol(s, i), true, CENTER)
        }

        for (k in 0..2) {
            val base = 1930f + k * 140f
            val amp = 36f + k * 14f
            val wl = 560f + k * 220f
            val ph = k * 1.7f
            val path = Path()
            path.moveTo(0f, H.toFloat())
            var x = 0f
            while (x <= W.toFloat()) {
                val y = base + amp * sin((2.0 * PI * x / wl + ph).toFloat())
                path.lineTo(x, y)
                x += 12f
            }
            path.lineTo(W.toFloat(), H.toFloat())
            path.close()
            val col = if (k == 1) p.accent2 else p.accent
            c.drawPath(path, fill(al(col, 0.14f + 0.08f * k)))
        }
    }

    // ---------------------------------------------------------------- gaya 7: Bintang Islami

    private fun star(s: Scene) {
        val c = s.c
        val p = s.p

        // Hiasan bintang samar di bagian atas
        c.drawPath(star8Path(170f, 650f, 80f, 0f), line(al(p.accent, 0.22f), 4f))
        c.drawPath(star8Path(910f, 540f, 110f, 22.5f), line(al(p.accent, 0.18f), 4f))
        c.drawPath(star8Path(760f, 840f, 55f, 0f), line(al(p.accent2, 0.2f), 3f))

        header(s, 540f, 1110f, CENTER)

        c.drawPath(star8Path(540f, 1520f, 300f, 0f), fill(al(p.accent, 0.10f)))
        c.drawPath(star8Path(540f, 1520f, 300f, 0f), line(al(p.accent, 0.85f), 6f))
        c.drawPath(star8Path(540f, 1520f, 250f, 22.5f), line(al(p.accent2, 0.5f), 3f))

        txt(c, "Menuju ${s.nextName}", 540f, 1480f, 42f, p.muted, true, CENTER, 340f)
        txt(c, s.nextAt, 540f, 1610f, 120f, p.accent, true, CENTER)

        for (i in 0..5) {
            val x = 70f + (i % 3) * 320f
            val y = 1890f + (i / 3) * 120f
            val r = RectF(x, y, x + 300f, y + 96f)
            if (i == s.nextIdx) {
                c.drawRoundRect(r, 48f, 48f, fill(al(p.accent, 0.3f)))
                c.drawRoundRect(r, 48f, 48f, line(al(p.accent, 0.8f), 3f))
            } else {
                c.drawRoundRect(r, 48f, 48f, fill(al(p.text, 0.08f)))
            }
            txt(c, ROWS[i], x + 30f, y + 62f, 32f, nameCol(s, i), false, LEFT, 130f)
            txt(c, s.times[i], x + 272f, y + 64f, 40f, timeCol(s, i), true, RIGHT)
        }
    }
}
