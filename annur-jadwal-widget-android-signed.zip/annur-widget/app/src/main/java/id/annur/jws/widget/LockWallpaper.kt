package id.annur.jws.widget

import android.app.WallpaperManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import java.time.Instant
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * Membuat gambar jadwal sholat hari ini dan memasangnya sebagai wallpaper layar kunci.
 * Dipakai di HP yang tidak punya widget layar kunci (misalnya Android 12).
 * Gambarnya statis: diperbarui tiap waktu sholat dan tengah malam.
 */
object LockWallpaper {
    private const val W = 1080
    private const val H = 2400
    private val ROWS = listOf("Subuh", "Terbit", "Zuhur", "Asar", "Maghrib", "Isya")
    private val DATE_FMT = DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", Locale.forLanguageTag("id-ID"))
    private val HM_FMT = DateTimeFormatter.ofPattern("HH:mm")

    private val GOLD = Color.parseColor("#F2B84B")
    private val MUTED = Color.parseColor("#9FB8C8")

    fun apply(ctx: Context, s: Settings) {
        val zone = s.zone()
        val now = ZonedDateTime.now(zone)
        val cfg = s.config()
        val t = PrayerCalc.compute(cfg, now.year, now.monthValue, now.dayOfMonth)
        val next = PrayerCalc.nextPrayer(cfg, zone, now)
        val times = longArrayOf(t.subuh, t.terbit, t.zuhur, t.asar, t.maghrib, t.isya)
        val nextAt = Instant.ofEpochMilli(next.epochMs).atZone(zone).format(HM_FMT)

        val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)

        val bg = Paint().apply {
            shader = LinearGradient(
                0f, 0f, 0f, H.toFloat(),
                intArrayOf(Color.parseColor("#1D4A5F"), Color.parseColor("#0B1F2D"), Color.parseColor("#06121D")),
                floatArrayOf(0f, 0.45f, 1f),
                Shader.TileMode.CLAMP
            )
        }
        c.drawRect(0f, 0f, W.toFloat(), H.toFloat(), bg)

        // Judul dan tanggal
        text(c, s.name, 90f, 260f, 64f, Color.WHITE, bold = true)
        text(c, DATE_FMT.format(now), 90f, 330f, 40f, MUTED)

        // Sholat berikutnya
        text(c, "Menuju ${next.name}", 90f, 900f, 56f, MUTED, bold = true)
        text(c, nextAt, 90f, 1060f, 170f, GOLD, bold = true)

        // Enam waktu sholat, waktu berikutnya disorot
        val paintHl = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#33F2B84B") }
        for (i in ROWS.indices) {
            val y = 1400f + i * 150f
            val isNext = ROWS[i] == next.name
            if (isNext) c.drawRoundRect(RectF(70f, y - 92f, W - 70f, y + 36f), 40f, 40f, paintHl)
            text(c, ROWS[i], 120f, y, 52f, if (isNext) GOLD else MUTED)
            text(
                c, fmtHm(times[i]), W - 120f, y, 60f,
                if (isNext) GOLD else Color.WHITE, bold = true, right = true
            )
        }

        runCatching {
            WallpaperManager.getInstance(ctx).setBitmap(bmp, null, true, WallpaperManager.FLAG_LOCK)
        }
        bmp.recycle()
    }

    private fun text(
        c: Canvas, str: String, x: Float, y: Float, size: Float, color: Int,
        bold: Boolean = false, right: Boolean = false
    ) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            textSize = size
            typeface = Typeface.create(if (bold) "sans-serif-medium" else "sans-serif", Typeface.NORMAL)
            textAlign = if (right) Paint.Align.RIGHT else Paint.Align.LEFT
        }
        c.drawText(str, x, y, p)
    }
}
