package id.annur.jws.widget

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import java.util.Random
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** Warna tema widget Persegi, Lebar, dan Tipis. Latar tiap tema digambar oleh [ThemeArt]. */
class WTheme(
    val name: String,
    val accent: Int,
    /** Latar baris waktu sholat (transparan). */
    val rowBg: Int,
    /** Latar pil hitung mundur (transparan). */
    val pillBg: Int,
    /** Warna teks di atas baris yang menyala. */
    val onAccent: Int
)

/**
 * Lima desain latar yang berbeda bentuknya, bukan hanya warnanya:
 * senja dengan siluet masjid, malam berbintang, pola bintang geometris, lengkung emas, dan gurun saat fajar.
 */
object ThemeArt {
    private fun hc(h: String) = Color.parseColor(h)
    private fun argb(a: Int, hex: String): Int {
        val k = Color.parseColor(hex)
        return Color.argb(a, Color.red(k), Color.green(k), Color.blue(k))
    }

    val themes = listOf(
        WTheme("Senja Masjid", hc("#F6C453"), argb(0x73, "#140A1E"), argb(0x66, "#F6C453"), hc("#2B1B00")),
        WTheme("Malam Berbintang", hc("#FFD166"), argb(0x73, "#0A1230"), argb(0x66, "#FFD166"), hc("#2B1B00")),
        WTheme("Zamrud Geometri", hc("#F2D27A"), argb(0x73, "#03201C"), argb(0x66, "#F2D27A"), hc("#2B2000")),
        WTheme("Marun Lengkung", hc("#E8C170"), argb(0x73, "#200710"), argb(0x66, "#E8C170"), hc("#2B1700")),
        WTheme("Gurun Fajar", hc("#FFE08A"), argb(0x73, "#2A1608"), argb(0x66, "#FFE08A"), hc("#2B1B00"))
    )

    fun theme(i: Int): WTheme = themes[i.coerceIn(0, themes.size - 1)]

    private fun al(color: Int, f: Float): Int =
        Color.argb((f * 255f).toInt().coerceIn(0, 255), Color.red(color), Color.green(color), Color.blue(color))

    private fun fill(color: Int) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = color
        style = Paint.Style.FILL
    }

    private fun line(color: Int, w: Float) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = color
        style = Paint.Style.STROKE
        strokeWidth = w
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    private fun vgrad(h: Float, colors: IntArray, pos: FloatArray?) = Paint().apply {
        shader = LinearGradient(0f, 0f, 0f, h, colors, pos, Shader.TileMode.CLAMP)
    }

    private fun glow(cx: Float, cy: Float, r: Float, color: Int, a: Float) = Paint().apply {
        shader = RadialGradient(cx, cy, r, intArrayOf(al(color, a), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
    }

    private fun halfDome(cx: Float, baseY: Float, r: Float): Path {
        val p = Path()
        p.addArc(RectF(cx - r, baseY - r, cx + r, baseY + r), 180f, 180f)
        p.close()
        return p
    }

    /** Siluet masjid: kubah utama, dua menara, dan dua kubah kecil. Titik tengah [ax], tanah di [gy]. */
    private fun mosque(c: Canvas, ax: Float, gy: Float, s: Float, dark: Int, windows: Int) {
        val d = fill(dark)
        c.drawRect(ax - 169f * s, gy - 30f * s, ax - 101f * s, gy, d)
        c.drawPath(halfDome(ax - 135f * s, gy - 30f * s, 34f * s), d)
        c.drawRect(ax + 101f * s, gy - 26f * s, ax + 161f * s, gy, d)
        c.drawPath(halfDome(ax + 131f * s, gy - 26f * s, 30f * s), d)
        c.drawRect(ax - 70f * s, gy - 100f * s, ax + 70f * s, gy, d)
        c.drawPath(halfDome(ax, gy - 100f * s, 70f * s), d)
        c.drawRect(ax - 1.5f * s, gy - 205f * s, ax + 1.5f * s, gy - 168f * s, d)
        c.drawCircle(ax, gy - 208f * s, 4f * s, d)
        for ((mx, top) in listOf((ax - 95f * s) to 220f, (ax + 100f * s) to 190f)) {
            c.drawRect(mx - 8f * s, gy - top * s, mx + 8f * s, gy, d)
            c.drawRect(mx - 12f * s, gy - (top - 60f) * s, mx + 12f * s, gy - (top - 68f) * s, d)
            val cap = Path().apply {
                moveTo(mx - 10f * s, gy - top * s)
                lineTo(mx, gy - (top + 30f) * s)
                lineTo(mx + 10f * s, gy - top * s)
                close()
            }
            c.drawPath(cap, d)
        }
        val win = fill(windows)
        for (wx in floatArrayOf(-30f, -4f, 22f)) {
            c.drawRoundRect(RectF(ax + wx * s, gy - 70f * s, ax + (wx + 12f) * s, gy - 46f * s), 6f * s, 6f * s, win)
        }
    }

    private fun star8(cx: Float, cy: Float, r: Float, rot: Float): Path {
        val path = Path()
        val ri = r * 0.7654f
        for (k in 0 until 16) {
            val ang = ((rot + k * 22.5f - 90f) * PI / 180.0).toFloat()
            val rad = if (k % 2 == 0) r else ri
            val x = cx + rad * cos(ang)
            val y = cy + rad * sin(ang)
            if (k == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        return path
    }

    /** Latar widget berukuran [w] x [h] piksel dengan sudut membulat. */
    fun draw(idx: Int, w: Int, h: Int, density: Float): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val wf = w.toFloat()
        val hf = h.toFloat()
        val r = 22f * density
        c.clipPath(Path().apply { addRoundRect(RectF(0f, 0f, wf, hf), r, r, Path.Direction.CW) })
        val i = idx.coerceIn(0, themes.size - 1)
        when (i) {
            0 -> senja(c, wf, hf, density)
            1 -> malam(c, wf, hf, density)
            2 -> zamrud(c, wf, hf, density)
            3 -> marun(c, wf, hf, density)
            else -> gurun(c, wf, hf, density)
        }
        // Bayangan bawah agar teks tetap terbaca
        c.drawRect(0f, 0f, wf, hf, vgrad(hf, intArrayOf(Color.TRANSPARENT, Color.TRANSPARENT, Color.argb(95, 0, 0, 0)), floatArrayOf(0f, 0.4f, 1f)))
        c.drawRoundRect(
            RectF(density, density, wf - density, hf - density), r, r,
            line(al(themes[i].accent, 0.55f), 1.5f * density)
        )
        return bmp
    }

    private fun scale(w: Float, h: Float) = min(h / 300f, w / 420f)

    // 0: senja dengan siluet masjid besar
    private fun senja(c: Canvas, w: Float, h: Float, d: Float) {
        c.drawRect(0f, 0f, w, h, vgrad(h, intArrayOf(hc("#2A1747"), hc("#7B3F63"), hc("#F0904F")), floatArrayOf(0f, 0.55f, 1f)))
        c.drawRect(0f, 0f, w, h, glow(w * 0.55f, h * 0.9f, h * 0.95f, hc("#FFB060"), 0.6f))
        val s = scale(w, h)
        mosque(c, w * 0.6f, h * 0.9f, s, hc("#140B1C"), al(hc("#FFB060"), 0.8f))
        val rim = Path().apply {
            moveTo(0f, h * 0.9f)
            quadTo(w * 0.3f, h * 0.84f, w * 0.6f, h * 0.9f)
            quadTo(w * 0.85f, h * 0.95f, w, h * 0.88f)
        }
        val ground = Path(rim).apply {
            lineTo(w, h)
            lineTo(0f, h)
            close()
        }
        c.drawPath(ground, fill(hc("#140B1C")))
        c.drawPath(rim, line(al(hc("#FFB060"), 0.7f), 1.6f * d))
    }

    // 1: malam berbintang dengan bulan sabit
    private fun malam(c: Canvas, w: Float, h: Float, d: Float) {
        c.drawRect(0f, 0f, w, h, vgrad(h, intArrayOf(hc("#020617"), hc("#0B1E4A"), hc("#1B4A82")), floatArrayOf(0f, 0.5f, 1f)))
        val rnd = Random(11)
        val sp = fill(Color.WHITE)
        for (k in 0 until 70) {
            sp.alpha = 80 + rnd.nextInt(170)
            c.drawCircle(rnd.nextFloat() * w, rnd.nextFloat() * h * 0.7f, (0.5f + rnd.nextFloat() * 1.2f) * d.coerceAtLeast(1f) * 0.7f, sp)
        }
        val s = scale(w, h)
        val mx = w * 0.5f
        val my = h * 0.2f
        c.drawRect(0f, 0f, w, h, glow(mx, my, 90f * s, hc("#BFD7FF"), 0.28f))
        val moon = Path().apply { addCircle(mx, my, 16f * s, Path.Direction.CW) }
        moon.op(Path().apply { addCircle(mx + 8f * s, my - 4f * s, 14f * s, Path.Direction.CW) }, Path.Op.DIFFERENCE)
        c.drawPath(moon, fill(hc("#FFF4D6")))
        mosque(c, w * 0.6f, h * 0.93f, s * 0.95f, hc("#01030A"), al(hc("#FFD166"), 0.9f))
        c.drawRect(0f, h * 0.93f, w, h, fill(hc("#01030A")))
    }

    // 2: pola bintang geometris di atas hijau zamrud
    private fun zamrud(c: Canvas, w: Float, h: Float, d: Float) {
        c.drawRect(0f, 0f, w, h, vgrad(h, intArrayOf(hc("#031F1D"), hc("#0A4D43"), hc("#0F6B58")), floatArrayOf(0f, 0.55f, 1f)))
        val cell = (min(w, h * 1.6f) / 4.2f).coerceAtLeast(40f * d)
        val st = line(al(hc("#F2D27A"), 0.22f), 1.2f * d)
        val sq = line(al(hc("#F2D27A"), 0.14f), 1f * d)
        var y = 0f
        var row = 0
        while (y < h + cell) {
            var x = if (row % 2 == 0) 0f else cell / 2f
            while (x < w + cell) {
                c.drawPath(star8(x, y, cell * 0.46f, 0f), st)
                x += cell
            }
            y += cell / 2f
            row++
        }
        // Belah ketupat kecil di antara bintang
        y = cell / 4f
        while (y < h + cell) {
            var x = cell / 4f
            while (x < w + cell) {
                val p = Path().apply {
                    moveTo(x, y - cell * 0.12f)
                    lineTo(x + cell * 0.12f, y)
                    lineTo(x, y + cell * 0.12f)
                    lineTo(x - cell * 0.12f, y)
                    close()
                }
                c.drawPath(p, sq)
                x += cell
            }
            y += cell
        }
        c.drawRect(0f, 0f, w, h, Paint().apply {
            shader = RadialGradient(w / 2f, h / 2f, maxOf(w, h) * 0.75f,
                intArrayOf(Color.TRANSPARENT, Color.argb(120, 0, 0, 0)), null, Shader.TileMode.CLAMP)
        })
    }

    // 3: lengkung mihrab emas di atas marun
    private fun marun(c: Canvas, w: Float, h: Float, d: Float) {
        c.drawRect(0f, 0f, w, h, vgrad(h, intArrayOf(hc("#2A0912"), hc("#5C1427"), hc("#7E2236")), floatArrayOf(0f, 0.6f, 1f)))
        val gold = hc("#E8C170")
        val aw = (h * 0.62f).coerceAtLeast(60f * d)
        var x = -aw * 0.25f
        while (x < w) {
            for (inset in floatArrayOf(0f, aw * 0.1f)) {
                val l = x + inset
                val rgt = x + aw - inset
                val mid = (l + rgt) / 2f
                val top = h * (0.06f + inset / h)
                val p = Path().apply {
                    moveTo(l, h)
                    lineTo(l, h * 0.62f)
                    cubicTo(l, h * 0.36f, l + (rgt - l) * 0.3f, h * 0.2f, mid, top)
                    cubicTo(rgt - (rgt - l) * 0.3f, h * 0.2f, rgt, h * 0.36f, rgt, h * 0.62f)
                    lineTo(rgt, h)
                }
                if (inset == 0f) {
                    c.drawPath(Path(p).apply { close() }, fill(al(gold, 0.07f)))
                    c.drawPath(p, line(al(gold, 0.45f), 1.6f * d))
                } else {
                    c.drawPath(p, line(al(gold, 0.25f), 1.1f * d))
                }
            }
            x += aw
        }
        // Lampu gantung
        for (fx in floatArrayOf(0.12f, 0.5f, 0.88f)) {
            val lx = w * fx
            val ly = h * 0.16f
            c.drawLine(lx, 0f, lx, ly - 7f * d, line(al(gold, 0.6f), 1f * d))
            c.drawRect(0f, 0f, w, h, glow(lx, ly, 34f * d, hc("#FFC060"), 0.35f))
            val body = Path().apply {
                moveTo(lx - 4f * d, ly - 7f * d)
                lineTo(lx + 4f * d, ly - 7f * d)
                lineTo(lx + 6f * d, ly + 3f * d)
                lineTo(lx, ly + 9f * d)
                lineTo(lx - 6f * d, ly + 3f * d)
                close()
            }
            c.drawPath(body, fill(al(hc("#FFD27F"), 0.9f)))
        }
    }

    // 4: gurun saat fajar dengan matahari, bukit pasir, dan pohon kurma
    private fun gurun(c: Canvas, w: Float, h: Float, d: Float) {
        c.drawRect(0f, 0f, w, h, vgrad(h, intArrayOf(hc("#0F3A52"), hc("#3D8CA6"), hc("#F7D9A1")), floatArrayOf(0f, 0.5f, 0.85f)))
        val s = scale(w, h)
        val sx = w * 0.68f
        val sy = h * 0.66f
        c.drawRect(0f, 0f, w, h, glow(sx, sy, h * 0.8f, hc("#FFE9B0"), 0.75f))
        c.drawCircle(sx, sy, 34f * s, fill(hc("#FFF3CF")))
        val cols = intArrayOf(hc("#D39A5A"), hc("#B27541"), hc("#7A4A28"))
        for (k in 0..2) {
            val base = h * (0.7f + 0.1f * k)
            val amp = h * (0.06f - 0.012f * k)
            val wl = w * (1.1f - 0.2f * k)
            val path = Path()
            path.moveTo(0f, h)
            var x = 0f
            while (x <= w + 8f) {
                path.lineTo(x, base + amp * sin((2.0 * PI * x / wl + k * 1.9).toFloat()))
                x += 8f
            }
            path.lineTo(w, h)
            path.close()
            c.drawPath(path, fill(cols[k]))
        }
        palm(c, w * 0.1f, h * 0.9f, s, hc("#2A1708"))
        palm(c, w * 0.17f, h * 0.92f, s * 0.7f, hc("#2A1708"))
    }

    private fun palm(c: Canvas, x: Float, y: Float, s: Float, col: Int) {
        val tx = x + 4f * s
        val ty = y - 80f * s
        val trunk = Path().apply {
            moveTo(x, y)
            quadTo(x + 12f * s, y - 40f * s, tx, ty)
        }
        c.drawPath(trunk, line(col, 4f * s))
        val fr = line(col, 3f * s)
        for (a in floatArrayOf(-170f, -140f, -110f, -70f, -40f, -10f)) {
            val rad = Math.toRadians(a.toDouble())
            val ex = tx + (cos(rad) * 36f * s).toFloat()
            val ey = ty + (sin(rad) * 20f * s).toFloat() + 12f * s
            val cx = tx + (cos(rad) * 20f * s).toFloat()
            val cy = ty + (sin(rad) * 26f * s).toFloat() - 6f * s
            c.drawPath(Path().apply { moveTo(tx, ty); quadTo(cx, cy, ex, ey) }, fr)
        }
    }

    /** Pratinjau untuk pemilih tema: latar dengan contoh nama, jam, dan pil hitung mundur. */
    fun preview(idx: Int, w: Int, h: Int, density: Float): Bitmap {
        val bmp = draw(idx, w, h, density)
        val c = Canvas(bmp)
        val th = theme(idx)
        val t = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
            setShadowLayer(6f, 0f, 2f, 0xAA000000.toInt())
        }
        t.textSize = h * 0.32f
        c.drawText("17:10", w * 0.06f, h * 0.55f, t)
        t.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        t.textSize = h * 0.12f
        t.color = th.accent
        c.drawText("Masjid Ahmad Daromi", w * 0.06f, h * 0.22f, t)
        val pill = RectF(w * 0.06f, h * 0.66f, w * 0.06f + h * 0.8f, h * 0.66f + h * 0.2f)
        c.drawRoundRect(pill, h * 0.1f, h * 0.1f, fill(th.pillBg))
        t.textSize = h * 0.1f
        t.setShadowLayer(0f, 0f, 0f, 0)
        c.drawText("Maghrib 44:33", pill.left + h * 0.07f, pill.bottom - h * 0.06f, t)
        return bmp
    }
}
