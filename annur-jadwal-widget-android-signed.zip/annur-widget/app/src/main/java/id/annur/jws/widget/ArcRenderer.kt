package id.annur.jws.widget

import android.graphics.*

/**
 * Menggambar lengkung masjid dengan enam titik waktu sholat, sesuai tema.
 * Titik sholat berikutnya diberi cincin aksen, dan waktu yang sudah lewat dibuat redup.
 * Gambar kecil (560x290) supaya aman dikirim ke launcher lewat RemoteViews.
 */
object ArcRenderer {
    private const val W = 560
    private const val H = 290

    // Titik: Subuh, Terbit, Zuhur, Asar, Maghrib, Isya (urutan sama dengan ROW di PrayerWidgetProvider)
    private val POINTS = arrayOf(
        PointF(30f, 250f),
        PointF(57f, 138f),
        PointF(280f, 30f),
        PointF(396f, 57f),
        PointF(502f, 138f),
        PointF(530f, 250f)
    )

    fun render(nextIndex: Int, passed: BooleanArray, th: Theme): Bitmap {
        val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)

        val path = Path().apply {
            moveTo(30f, 250f)
            cubicTo(30f, 95f, 140f, 50f, 280f, 30f)
            cubicTo(420f, 50f, 530f, 95f, 530f, 250f)
        }

        // Garis dasar
        c.drawLine(
            30f, 250f, 530f, 250f,
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = (th.muted and 0x00FFFFFF) or 0x40000000
                strokeWidth = 2f
            }
        )

        val shader = LinearGradient(30f, 0f, 530f, 0f, th.arc, null, Shader.TileMode.CLAMP)

        // Cahaya di sekitar lengkung
        val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 14f
            strokeCap = Paint.Cap.ROUND
            this.shader = shader
            alpha = 80
            maskFilter = BlurMaskFilter(10f, BlurMaskFilter.Blur.NORMAL)
        }
        c.drawPath(path, glow)

        // Garis lengkung utama
        val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 5f
            strokeCap = Paint.Cap.ROUND
            this.shader = shader
        }
        c.drawPath(path, line)

        // Titik waktu sholat
        for (i in POINTS.indices) {
            val p = POINTS[i]
            when {
                i == nextIndex -> {
                    val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = th.accent
                        alpha = 70
                    }
                    val core = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = th.accent }
                    c.drawCircle(p.x, p.y, 18f, ring)
                    c.drawCircle(p.x, p.y, 9f, core)
                }
                passed[i] -> {
                    val dim = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = (th.muted and 0x00FFFFFF) or 0x66000000
                    }
                    c.drawCircle(p.x, p.y, 5f, dim)
                }
                else -> {
                    val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = th.arc[1] }
                    c.drawCircle(p.x, p.y, 6f, dot)
                }
            }
        }

        return bmp
    }
}
