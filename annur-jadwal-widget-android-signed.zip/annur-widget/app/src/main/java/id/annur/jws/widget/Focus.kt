package id.annur.jws.widget

import java.time.ZonedDateTime

/** Sholat yang waktunya baru tiba dan masih dalam jendela tampilan fokus. */
class FocusInfo(val idx: Int, val name: String, val startMs: Long, val endMs: Long)

object Focus {
    private val NAMES = listOf("Subuh", "Terbit", "Zuhur", "Asar", "Maghrib", "Isya")

    // Terbit (indeks 1) bukan waktu sholat, jadi tidak memicu tampilan fokus
    private val PRAYER_IDX = intArrayOf(0, 2, 3, 4, 5)

    /**
     * Mengembalikan sholat yang sedang dalam jendela fokus, atau null.
     * Jendelanya mulai dari waktu sholat tiba sampai [Settings.alertMin] menit sesudahnya.
     */
    fun current(s: Settings, now: ZonedDateTime): FocusInfo? {
        if (s.alertMin <= 0) return null
        val zone = s.zone()
        val date = now.toLocalDate()
        val t = PrayerCalc.compute(s.config(), date.year, date.monthValue, date.dayOfMonth)
        val times = longArrayOf(t.subuh, t.terbit, t.zuhur, t.asar, t.maghrib, t.isya)
        val nowMs = now.toInstant().toEpochMilli()
        for (i in PRAYER_IDX) {
            val start = PrayerCalc.epochMs(zone, date, times[i])
            val end = start + s.alertMin * 60_000L
            if (nowMs in start until end) return FocusInfo(i, NAMES[i], start, end)
        }
        return null
    }
}
