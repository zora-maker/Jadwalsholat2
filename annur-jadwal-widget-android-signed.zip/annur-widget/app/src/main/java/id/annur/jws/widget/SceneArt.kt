package id.annur.jws.widget

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import java.util.Random

/** Palet satu pemandangan: warna langit atas ke bawah, siluet, aksen, cahaya, dan benda langit. */
class ScenePal(
    val name: String,
    val sky: IntArray,
    val dark: Int,
    val accent: Int,
    val glow: Int,
    /** 0 tidak ada, 1 matahari di cakrawala, 2 bulan sabit. */
    val body: Int,
    val stars: Boolean
)

/** Menggambar latar widget bertema masjid dan cincin widget bulat. Semua dengan Canvas, tanpa gambar bawaan. */
object SceneArt {
    private fun c(h: String) = Color.parseColor(h)

    val pals = listOf(
        ScenePal("Senja", intArrayOf(c("#1B1530"), c("#5A2A55"), c("#E07A4F")), c("#0E0912"), c("#F6C453"), c("#FF9A5A"), 1, false),
        ScenePal("Malam", intArrayOf(c("#050B24"), c("#0E2150"), c("#1D4A7A")), c("#03050E"), c("#FFD166"), c("#4A7BD0"), 2, true),
        ScenePal("Fajar", intArrayOf(c("#0B3B3F"), c("#2F7F78"), c("#F2C58B")), c("#07201F"), c("#FFE08A"), c("#FFD9A0"), 1, false),
        ScenePal("Emas", intArrayOf(c("#2A1A0B"), c("#7A4A1C"), c("#E8B25A")), c("#1A0F05"), c("#FFD27F"), c("#FFC060"), 1, false)
    )

    private fun al(color: Int, f: Float): Int =
        Color.argb((f * 255f).toInt().coerceIn(0, 255), Color.red(color), Color.green(color), Color.blue(color))

    private fun fill(color: Int) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = color
        style = Paint.Style.FILL
    }

    private fun halfDome(cx: Float, baseY: Float, r: Float): Path {
        val p = Path()
        p.addArc(RectF(cx - r, baseY - r, cx + r, baseY + r), 180f, 180f)
        p.close()
        return p
    }

    /** Latar pemandangan berukuran [w] x [h] piksel dengan sudut membulat. [density] untuk radius sudut. */
    fun scene(idx: Int, w: Int, h: Int, density: Float): Bitmap {
        val p = pals[idx.coerceIn(0, pals.size - 1)]
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val wf = w.toFloat()
        val hf = h.toFloat()
        val s = hf / 360f

        val r = 20f * density
        val clip = Path().apply { addRoundRect(RectF(0f, 0f, wf, hf), r, r, Path.Direction.CW) }
        c.clipPath(clip)

        // Langit
        val sky = Paint().apply {
            shader = LinearGradient(0f, 0f, 0f, hf, p.sky, floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        }
        c.drawRect(0f, 0f, wf, hf, sky)

        // Cahaya di cakrawala
        val glow = Paint().apply {
            shader = RadialGradient(
                wf * 0.55f, hf * 0.88f, hf * 0.95f,
                intArrayOf(al(p.glow, 0.55f), Color.TRANSPARENT), null, Shader.TileMode.CLAMP
            )
        }
        c.drawRect(0f, 0f, wf, hf, glow)

        // Bintang
        if (p.stars) {
            val rnd = Random(7)
            val sp = fill(Color.WHITE)
            for (i in 0 until 55) {
                val x = rnd.nextFloat() * wf
                val y = rnd.nextFloat() * hf * 0.62f
                sp.alpha = 90 + rnd.nextInt(150)
                c.drawCircle(x, y, (0.6f + rnd.nextFloat() * 1.3f) * (density / 2f).coerceAtLeast(1f), sp)
            }
        }

        // Matahari atau bulan sabit
        if (p.body == 1) {
            c.drawCircle(wf * 0.55f, hf * 0.86f, 46f * s, fill(al(p.glow, 0.85f)))
        } else if (p.body == 2) {
            val moon = Path().apply { addCircle(wf * 0.5f, hf * 0.2f, 16f * s, Path.Direction.CW) }
            val cut = Path().apply { addCircle(wf * 0.5f + 8f * s, hf * 0.2f - 4f * s, 14f * s, Path.Direction.CW) }
            moon.op(cut, Path.Op.DIFFERENCE)
            c.drawPath(moon, fill(Color.parseColor("#FFF4D6")))
        }

        // Siluet masjid di kanan tengah, di belakang daftar waktu
        val dark = fill(p.dark)
        val ax = wf * 0.62f
        val gy = hf * 0.92f

        // Kubah kecil kiri dan kanan
        c.drawRect(ax - 169f * s, gy - 30f * s, ax - 101f * s, gy, dark)
        c.drawPath(halfDome(ax - 135f * s, gy - 30f * s, 34f * s), dark)
        c.drawRect(ax + 101f * s, gy - 26f * s, ax + 161f * s, gy, dark)
        c.drawPath(halfDome(ax + 131f * s, gy - 26f * s, 30f * s), dark)

        // Badan dan kubah utama
        c.drawRect(ax - 70f * s, gy - 100f * s, ax + 70f * s, gy, dark)
        c.drawPath(halfDome(ax, gy - 100f * s, 70f * s), dark)
        c.drawRect(ax - 1.5f * s, gy - 205f * s, ax + 1.5f * s, gy - 168f * s, dark)
        c.drawCircle(ax, gy - 208f * s, 4f * s, dark)

        // Dua menara
        for ((mx, top) in listOf((ax - 95f * s) to 220f, (ax + 100f * s) to 190f)) {
            c.drawRect(mx - 8f * s, gy - top * s, mx + 8f * s, gy, dark)
            c.drawRect(mx - 12f * s, gy - (top - 60f) * s, mx + 12f * s, gy - (top - 68f) * s, dark)
            val cap = Path().apply {
                moveTo(mx - 10f * s, gy - top * s)
                lineTo(mx, gy - (top + 30f) * s)
                lineTo(mx + 10f * s, gy - top * s)
                close()
            }
            c.drawPath(cap, dark)
        }

        // Jendela menyala
        val win = fill(al(p.accent, 0.75f))
        for (wx in floatArrayOf(-30f, -4f, 22f)) {
            c.drawRoundRect(
                RectF(ax + wx * s, gy - 70f * s, ax + (wx + 12f) * s, gy - 46f * s),
                6f * s, 6f * s, win
            )
        }

        // Tanah berbukit
        val ground = Path().apply {
            moveTo(0f, hf * 0.9f)
            quadTo(wf * 0.25f, hf * 0.85f, wf * 0.5f, hf * 0.915f)
            quadTo(wf * 0.8f, hf * 0.97f, wf, hf * 0.9f)
            lineTo(wf, hf)
            lineTo(0f, hf)
            close()
        }
        c.drawPath(ground, dark)
        return bmp
    }

    private fun darken(color: Int, f: Float): Int =
        Color.rgb((Color.red(color) * f).toInt(), (Color.green(color) * f).toInt(), (Color.blue(color) * f).toInt())

    /**
     * Cincin 24 jam untuk widget bulat. Tiap titik berada pada jam sholatnya (00:00 di atas, searah jarum jam).
     * [times] detik dalam sehari untuk enam waktu. Titik berikutnya diberi cahaya aksen.
     */
    fun ring(th: Theme, times: LongArray, markIdx: Int, passed: BooleanArray, size: Int): Bitmap {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val sz = size.toFloat()
        val cx = sz / 2f
        val cy = sz / 2f

        // Piringan
        c.drawCircle(cx, cy, sz / 2f - 1f, fill(al(darken(th.arc[0], 0.22f), 0.93f)))
        val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = sz * 0.012f
            color = al(th.arc[1], 0.55f)
        }
        c.drawCircle(cx, cy, sz / 2f - 1f - edge.strokeWidth / 2f, edge)

        // Jalur dan penanda jam
        val rr = sz * 0.40f
        val track = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = sz * 0.018f
            color = al(th.muted, 0.25f)
        }
        c.drawCircle(cx, cy, rr, track)
        val tick = fill(al(th.muted, 0.5f))
        for (h in 0 until 24) {
            val a = Math.toRadians(h * 15.0 - 90.0)
            val big = h % 6 == 0
            c.drawCircle(
                cx + (rr - sz * 0.055f) * Math.cos(a).toFloat(),
                cy + (rr - sz * 0.055f) * Math.sin(a).toFloat(),
                if (big) sz * 0.011f else sz * 0.006f, tick
            )
        }

        // Titik waktu sholat
        for (i in 0..5) {
            val a = Math.toRadians(times[i] / 86400.0 * 360.0 - 90.0)
            val x = cx + rr * Math.cos(a).toFloat()
            val y = cy + rr * Math.sin(a).toFloat()
            when {
                i == markIdx -> {
                    c.drawCircle(x, y, sz * 0.055f, fill(al(th.accent, 0.3f)))
                    c.drawCircle(x, y, sz * 0.03f, fill(th.accent))
                }
                passed[i] -> c.drawCircle(x, y, sz * 0.02f, fill(al(th.muted, 0.5f)))
                else -> c.drawCircle(x, y, sz * 0.026f, fill(th.arc[1]))
            }
        }
        return bmp
    }
}
