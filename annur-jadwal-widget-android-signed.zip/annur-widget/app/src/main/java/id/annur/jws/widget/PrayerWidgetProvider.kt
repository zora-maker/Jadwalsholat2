package id.annur.jws.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.view.View
import android.widget.RemoteViews
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * Widget jadwal sholat untuk layar utama, dengan lengkung masjid dan tema warna.
 *
 * Jam dan detik memakai TextClock, hitung mundur memakai Chronometer. Keduanya berjalan
 * sendiri di sisi launcher, jadi tetap hidup tanpa aplikasi terbuka.
 *
 * Saat waktu sholat tiba, widget masuk tampilan fokus: nama sholat besar, tulisan
 * "Waktu sholat telah tiba", dan hitung maju sejak waktu tiba, selama [Settings.alertMin] menit.
 * Setelah Isya, widget menampilkan jadwal besok. Pembaruan dan alarm diatur oleh [Scheduler].
 */
class PrayerWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        Scheduler.refresh(ctx)
    }

    override fun onDeleted(ctx: Context, ids: IntArray) {
        Scheduler.refresh(ctx)
    }

    override fun onDisabled(ctx: Context) {
        Scheduler.refresh(ctx)
    }

    companion object {
        private val DATE_FMT = DateTimeFormatter.ofPattern("EEE, d MMM", Locale.forLanguageTag("id-ID"))
        private val ROW = listOf("Subuh", "Terbit", "Zuhur", "Asar", "Maghrib", "Isya")
        private val NAME_IDS = intArrayOf(R.id.n0, R.id.n1, R.id.n2, R.id.n3, R.id.n4, R.id.n5)
        private val TIME_IDS = intArrayOf(R.id.t0, R.id.t1, R.id.t2, R.id.t3, R.id.t4, R.id.t5)
        private val HL_IDS = intArrayOf(R.id.hl0, R.id.hl1, R.id.hl2, R.id.hl3, R.id.hl4, R.id.hl5)

        /** Menggambar ulang semua widget. Mengembalikan true bila ada widget terpasang. */
        fun renderAll(ctx: Context, s: Settings): Boolean {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, PrayerWidgetProvider::class.java))
            if (ids.isEmpty()) return false

            val zone = s.zone()
            val now = ZonedDateTime.now(zone)
            val cfg = s.config()
            val th = Themes.get(s.theme)
            val focus = Focus.current(s, now)

            // Waktu hari ini, dan mana yang sudah lewat (hanya untuk meredupkan warna)
            val today = PrayerCalc.compute(cfg, now.year, now.monthValue, now.dayOfMonth)
            val todayTimes = longArrayOf(today.subuh, today.terbit, today.zuhur, today.asar, today.maghrib, today.isya)
            val nowSec = now.toLocalTime().toSecondOfDay().toLong()
            val passedToday = BooleanArray(6) { todayTimes[it] <= nowSec }

            // Semua sudah lewat (setelah Isya) dan bukan sedang fokus: tampilkan jadwal besok
            val times: LongArray
            val passed: BooleanArray
            if (focus == null && passedToday.all { it }) {
                val tom = now.toLocalDate().plusDays(1)
                val tt = PrayerCalc.compute(cfg, tom.year, tom.monthValue, tom.dayOfMonth)
                times = longArrayOf(tt.subuh, tt.terbit, tt.zuhur, tt.asar, tt.maghrib, tt.isya)
                passed = BooleanArray(6)
            } else {
                times = todayTimes
                passed = passedToday
            }

            val next = PrayerCalc.nextPrayer(cfg, zone, now)
            val markIdx = focus?.idx ?: ROW.indexOf(next.name)
            val remainMs = next.epochMs - System.currentTimeMillis()
            val arc = ArcRenderer.render(markIdx, passed, th)
            val hijri = Hijri.today(s, now).toString()
            val marqText = Marquee.build(ctx, s, now)

            val openApp = PendingIntent.getActivity(
                ctx, 0, Intent(ctx, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE
            )

            for (id in ids) {
                val rv = RemoteViews(ctx.packageName, R.layout.widget_prayer)

                if (th.bgRes == 0) {
                    rv.setInt(R.id.wRoot, "setBackgroundColor", 0)
                } else {
                    rv.setInt(R.id.wRoot, "setBackgroundResource", th.bgRes)
                }

                rv.setTextViewText(R.id.wName, s.name)
                rv.setTextColor(R.id.wName, th.text)
                rv.setTextViewText(R.id.wDate, DATE_FMT.format(now))
                rv.setTextColor(R.id.wDate, th.muted)
                rv.setTextViewText(R.id.wHijri, hijri)
                rv.setTextColor(R.id.wHijri, th.accent)
                if (marqText.isEmpty()) {
                    rv.setViewVisibility(R.id.wMarq, View.GONE)
                } else {
                    rv.setViewVisibility(R.id.wMarq, View.VISIBLE)
                    rv.setTextViewText(R.id.wMarq, marqText)
                    rv.setTextColor(R.id.wMarq, th.text)
                }
                rv.setTextColor(R.id.wNext, th.muted)
                rv.setTextColor(R.id.wHm, th.clock)
                rv.setTextColor(R.id.wSs, th.accent)
                rv.setTextColor(R.id.wCount, th.accent)
                rv.setImageViewBitmap(R.id.wArc, arc)

                if (focus != null) {
                    // Tampilan fokus: waktu sholat telah tiba
                    rv.setViewVisibility(R.id.wClockRow, View.GONE)
                    rv.setViewVisibility(R.id.wFocus, View.VISIBLE)
                    rv.setTextViewText(R.id.wFocus, focus.name.uppercase())
                    rv.setTextColor(R.id.wFocus, th.accent)
                    rv.setTextViewText(R.id.wNext, "Waktu sholat telah tiba")
                    val elapsed = System.currentTimeMillis() - focus.startMs
                    rv.setChronometerCountDown(R.id.wCount, false)
                    rv.setChronometer(R.id.wCount, SystemClock.elapsedRealtime() - elapsed, null, true)
                } else {
                    rv.setViewVisibility(R.id.wClockRow, View.VISIBLE)
                    rv.setViewVisibility(R.id.wFocus, View.GONE)
                    rv.setTextViewText(R.id.wNext, "Menuju ${next.name}")
                    rv.setChronometerCountDown(R.id.wCount, true)
                    rv.setChronometer(R.id.wCount, SystemClock.elapsedRealtime() + remainMs, null, true)
                }

                for (i in ROW.indices) {
                    val isMark = i == markIdx
                    rv.setTextViewText(NAME_IDS[i], ROW[i])
                    rv.setTextColor(NAME_IDS[i], if (isMark) th.accent else th.muted)
                    rv.setTextViewText(TIME_IDS[i], fmtHm(times[i]))
                    rv.setTextColor(TIME_IDS[i], if (isMark) th.accent else if (passed[i]) th.muted else th.text)
                    rv.setViewVisibility(HL_IDS[i], if (isMark) View.VISIBLE else View.GONE)
                    rv.setInt(HL_IDS[i], "setBackgroundColor", (th.accent and 0x00FFFFFF) or 0x33000000)
                }

                rv.setOnClickPendingIntent(R.id.wRoot, openApp)
                mgr.updateAppWidget(id, rv)
            }
            return true
        }
    }
}
