package id.annur.jws.widget

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.ZonedDateTime
import java.time.chrono.HijrahDate
import java.time.temporal.ChronoField

/** Satu tanggal Hijriyah. */
class HDate(val y: Int, val m: Int, val d: Int) {
    val monthName: String get() = Hijri.MONTHS[m - 1]
    override fun toString(): String = "$d $monthName $y H"
}

/** Hari penting atau amalan pada suatu tanggal Hijriyah. [major] true berarti hari besar. */
class Special(val label: String, val major: Boolean)

/**
 * Penanggalan Hijriyah offline memakai kalender Umm al-Qura bawaan Android (java.time, API 26 ke atas).
 * Hasilnya bisa berbeda satu hari dari ketetapan Kemenag, karena itu ada koreksi hari di pengaturan.
 */
object Hijri {
    val MONTHS = listOf(
        "Muharram", "Safar", "Rabiul Awal", "Rabiul Akhir", "Jumadil Awal", "Jumadil Akhir",
        "Rajab", "Syaban", "Ramadan", "Syawal", "Zulkaidah", "Zulhijah"
    )
    val MONTHS_ID = listOf(
        "Januari", "Februari", "Maret", "April", "Mei", "Juni",
        "Juli", "Agustus", "September", "Oktober", "November", "Desember"
    )
    val MON_SHORT = listOf("Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des")

    fun of(date: LocalDate, offset: Int): HDate {
        val h = HijrahDate.from(date.plusDays(offset.toLong()))
        return HDate(h.get(ChronoField.YEAR), h.get(ChronoField.MONTH_OF_YEAR), h.get(ChronoField.DAY_OF_MONTH))
    }

    /** Tanggal Hijriyah hari ini. Bila diatur, tanggal berganti saat Maghrib tiba. */
    fun today(s: Settings, now: ZonedDateTime): HDate {
        var off = s.hijriOffset
        if (s.hijriMaghrib) {
            val t = PrayerCalc.compute(s.config(), now.year, now.monthValue, now.dayOfMonth)
            if (now.toLocalTime().toSecondOfDay().toLong() >= t.maghrib) off += 1
        }
        return runCatching { of(now.toLocalDate(), off) }.getOrElse { HDate(1448, 1, 1) }
    }

    /** Tanggal Masehi untuk tanggal 1 bulan Hijriyah tertentu. */
    fun firstOfMonth(y: Int, m: Int, offset: Int): LocalDate =
        LocalDate.from(HijrahDate.of(y, m, 1)).minusDays(offset.toLong())

    fun lengthOfMonth(y: Int, m: Int): Int = HijrahDate.of(y, m, 1).lengthOfMonth()

    /** Contoh: "27 November 2026 • 16 Jumadil Awal 1448 H". */
    fun both(date: LocalDate, offset: Int): String {
        val h = runCatching { of(date, offset).toString() }.getOrElse { "-" }
        return "${date.dayOfMonth} ${MONTHS_ID[date.monthValue - 1]} ${date.year} • $h"
    }

    fun special(h: HDate, dow: DayOfWeek): List<Special> {
        val out = mutableListOf<Special>()
        when (h.m * 100 + h.d) {
            101 -> out += Special("Tahun Baru Hijriyah", true)
            109 -> out += Special("Tasua (puasa sunnah)", false)
            110 -> out += Special("Hari Asyura (puasa sunnah)", true)
            312 -> out += Special("Maulid Nabi Muhammad SAW", true)
            727 -> out += Special("Isra Mikraj", true)
            815 -> out += Special("Nisfu Syaban", true)
            901 -> out += Special("Awal Ramadan", true)
            917 -> out += Special("Nuzulul Quran", true)
            1001 -> out += Special("Idul Fitri", true)
            1209 -> out += Special("Hari Arafah (puasa sunnah)", true)
            1210 -> out += Special("Idul Adha", true)
            1211, 1212, 1213 -> out += Special("Hari Tasyrik", true)
        }
        val noFast = (h.m == 10 && h.d == 1) || (h.m == 12 && h.d in 10..13)
        if (h.m == 9) {
            out += Special("Puasa Ramadan", false)
        } else if (!noFast) {
            if (h.d in 13..15) out += Special("Puasa Ayyamul Bidh", false)
            if (dow == DayOfWeek.MONDAY) out += Special("Puasa sunnah Senin", false)
            if (dow == DayOfWeek.THURSDAY) out += Special("Puasa sunnah Kamis", false)
        }
        return out
    }
}
