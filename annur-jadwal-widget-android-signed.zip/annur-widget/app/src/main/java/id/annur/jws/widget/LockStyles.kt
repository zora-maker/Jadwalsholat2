package id.annur.jws.widget

import android.graphics.Color

/**
 * Satu palet warna untuk wallpaper layar kunci.
 * [bg] tiga warna latar dari atas ke bawah. [accent] dan [accent2] dipakai untuk sorotan dan hiasan.
 */
class LockPalette(
    val name: String,
    val bg: IntArray,
    val text: Int,
    val muted: Int,
    val accent: Int,
    val accent2: Int
)

/** Daftar 20 palet warna dan 8 gaya tata letak wallpaper layar kunci. */
object LockStyles {
    val styleNames = listOf(
        "Klasik Daftar",
        "Lengkung Masjid",
        "Kartu Grid",
        "Cincin",
        "Timeline",
        "Kubah dan Menara",
        "Gelombang",
        "Bintang Islami"
    )

    private fun c(hex: String): Int = Color.parseColor(hex)

    private fun pal(
        name: String, b1: String, b2: String, b3: String,
        text: String, muted: String, accent: String, accent2: String
    ) = LockPalette(
        name, intArrayOf(c(b1), c(b2), c(b3)),
        c(text), c(muted), c(accent), c(accent2)
    )

    val palettes: List<LockPalette> by lazy {
        listOf(
            pal("Gelap Emas", "#1D4A5F", "#0B1F2D", "#06121D", "#FFFFFF", "#9FB8C8", "#F2B84B", "#3FD6C6"),
            pal("Biru Laut", "#1B5C9E", "#0E2F5C", "#071A36", "#FFFFFF", "#A9CBE6", "#7FE0FF", "#2B7BE0"),
            pal("Hijau Zamrud", "#0F5A47", "#0A3328", "#051A14", "#FFFFFF", "#B6E3D1", "#F5D76E", "#3FD6A6"),
            pal("Ungu Malam", "#4A2C8A", "#24144F", "#0F0826", "#FFFFFF", "#CDB8F0", "#FFD166", "#8E6BFF"),
            pal("Marun", "#7A1F3A", "#40101F", "#1A060D", "#FFFFFF", "#F3C4CF", "#FFB3C1", "#F25C7A"),
            pal("Abu Arang", "#3A4047", "#1E2227", "#0D0F12", "#F2F4F6", "#AEB6BF", "#9BE7FF", "#6FD0E6"),
            pal("Coklat Kayu", "#6B4423", "#3A2411", "#1A0F07", "#FFF8EC", "#E6CFA8", "#FFC857", "#FF8C42"),
            pal("Teal Laut", "#0F6B73", "#0A3B42", "#051E24", "#FFFFFF", "#B5E8E6", "#7CF5E0", "#3FD6C6"),
            pal("Terang", "#F7FBFC", "#E3F1F4", "#CFE6EB", "#1B2B38", "#4A5B68", "#0F7A8C", "#F2A33A"),
            pal("Senja Jingga", "#7A3416", "#3E1A0C", "#1A0A05", "#FFFFFF", "#F5D0B5", "#FFB066", "#FF7A45"),
            pal("Merah Delima", "#8A1230", "#4A0A1A", "#1E040A", "#FFFFFF", "#F5C0CB", "#FF6B81", "#FFB3C1"),
            pal("Hijau Hutan", "#2A6B3A", "#143B20", "#08190D", "#FFFFFF", "#BFE0C6", "#C5E86C", "#6FD08C"),
            pal("Biru Tengah Malam", "#18287A", "#0C1448", "#050824", "#FFFFFF", "#B5C4F0", "#8AB4FF", "#5C7CFF"),
            pal("Sakura", "#8C3A66", "#4A1B38", "#1E0A17", "#FFFFFF", "#F2C6DC", "#FFB7D5", "#FF7FB0"),
            pal("Pasir Gurun", "#F8ECD2", "#ECD6A8", "#D9B97F", "#3B2A12", "#6B5530", "#9C5B12", "#C77D1A"),
            pal("Mint Segar", "#EAFAF4", "#CBF1E3", "#A8E3CE", "#12372B", "#3F6B5A", "#0E8A6A", "#17B38A"),
            pal("Lavender", "#F3EEFC", "#DED3F6", "#C5B5EC", "#2E2150", "#5C4F85", "#6B3FD1", "#9B6BFF"),
            pal("Biru Langit", "#E8F4FF", "#C4E2FB", "#98CDF6", "#0F2F4C", "#3F6384", "#1566C0", "#2E94F0"),
            pal("Hitam AMOLED", "#101010", "#050505", "#000000", "#FFFFFF", "#9A9A9A", "#FFD54F", "#8AE6FF"),
            pal("Fajar Magenta", "#4A2278", "#9B3F7E", "#E0804F", "#FFFFFF", "#FFE6D5", "#FFE08A", "#FFFFFF")
        )
    }

    fun palette(i: Int): LockPalette = palettes[i.coerceIn(0, palettes.size - 1)]
}
