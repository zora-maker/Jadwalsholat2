package id.annur.jws.widget

import android.graphics.Color

/**
 * Satu tema warna widget.
 * [bgRes] adalah drawable latar (bg_t0..bg_t8). 0 berarti transparan.
 * [arc] adalah tiga warna gradien untuk lengkung masjid.
 */
class Theme(
    val name: String,
    val bgRes: Int,
    val text: Int,
    val muted: Int,
    val accent: Int,
    val clock: Int,
    val arc: IntArray
)

object Themes {
    private fun c(hex: String): Int = Color.parseColor(hex)

    val list: List<Theme> by lazy {
        listOf(
            Theme("Gelap Emas", R.drawable.bg_t0, c("#FFFFFF"), c("#9FB8C8"), c("#F2B84B"), c("#F0FAFB"),
                intArrayOf(c("#2BB3E0"), c("#3FD6C6"), c("#F2B84B"))),
            Theme("Biru Laut", R.drawable.bg_t1, c("#FFFFFF"), c("#A9CBE6"), c("#7FE0FF"), c("#FFFFFF"),
                intArrayOf(c("#7FE0FF"), c("#4AB8F0"), c("#2B7BE0"))),
            Theme("Hijau Zamrud", R.drawable.bg_t2, c("#FFFFFF"), c("#B6E3D1"), c("#F5D76E"), c("#FFFFFF"),
                intArrayOf(c("#7CE3B0"), c("#3FD6A6"), c("#F5D76E"))),
            Theme("Ungu Malam", R.drawable.bg_t3, c("#FFFFFF"), c("#CDB8F0"), c("#FFD166"), c("#FFFFFF"),
                intArrayOf(c("#C9A7FF"), c("#8E6BFF"), c("#FFD166"))),
            Theme("Marun", R.drawable.bg_t4, c("#FFFFFF"), c("#F3C4CF"), c("#FFB3C1"), c("#FFFFFF"),
                intArrayOf(c("#FF8FA3"), c("#F25C7A"), c("#FFD27F"))),
            Theme("Abu Arang", R.drawable.bg_t5, c("#F2F4F6"), c("#AEB6BF"), c("#9BE7FF"), c("#FFFFFF"),
                intArrayOf(c("#9BE7FF"), c("#6FD0E6"), c("#C5D6E0"))),
            Theme("Coklat Kayu", R.drawable.bg_t6, c("#FFF8EC"), c("#E6CFA8"), c("#FFC857"), c("#FFF8EC"),
                intArrayOf(c("#FFC857"), c("#E8A33D"), c("#FF8C42"))),
            Theme("Teal Laut", R.drawable.bg_t7, c("#FFFFFF"), c("#B5E8E6"), c("#7CF5E0"), c("#FFFFFF"),
                intArrayOf(c("#7CF5E0"), c("#3FD6C6"), c("#A8F0FF"))),
            Theme("Terang", R.drawable.bg_t8, c("#1B2B38"), c("#4A5B68"), c("#0F7A8C"), c("#1B2B38"),
                intArrayOf(c("#0F7A8C"), c("#2AA8A0"), c("#F2A33A"))),
            Theme("Transparan", 0, c("#FFFFFF"), c("#E0E8EE"), c("#FFC857"), c("#FFFFFF"),
                intArrayOf(c("#7FE0FF"), c("#3FD6C6"), c("#FFC857")))
        )
    }

    fun get(i: Int): Theme = list[i.coerceIn(0, list.size - 1)]
}
