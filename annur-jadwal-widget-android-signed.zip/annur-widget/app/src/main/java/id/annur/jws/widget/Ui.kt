package id.annur.jws.widget

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

/** Warna dan bentuk dasar tampilan aplikasi. Semua layar dibangun dari kode supaya konsisten. */
object C {
    val BG = Color.parseColor("#06121D")
    val CARD = Color.parseColor("#0E2536")
    val CARD2 = Color.parseColor("#143247")
    val LINE = Color.parseColor("#1F3F58")
    val TEXT = Color.parseColor("#E8F5F6")
    val MUTED = Color.parseColor("#8DA9B9")
    val GOLD = Color.parseColor("#F2B84B")
    val TEAL = Color.parseColor("#3FD6C6")
    val DANGER = Color.parseColor("#FF7B7B")

    fun alpha(color: Int, f: Float): Int =
        Color.argb((f * 255f).toInt().coerceIn(0, 255), Color.red(color), Color.green(color), Color.blue(color))
}

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun Context.roundBg(color: Int, radiusDp: Int, stroke: Int = 0, strokeDp: Int = 1): GradientDrawable =
    GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
        if (stroke != 0) setStroke(dp(strokeDp), stroke)
    }

fun Context.label(str: String, sp: Float = 14f, color: Int = C.TEXT, bold: Boolean = false): TextView =
    TextView(this).apply {
        text = str
        textSize = sp
        setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }

fun Context.vbox(padDp: Int = 0): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    setPadding(dp(padDp), dp(padDp), dp(padDp), dp(padDp))
}

fun Context.hbox(): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.HORIZONTAL
    gravity = Gravity.CENTER_VERTICAL
}

fun Context.card(): LinearLayout = vbox(16).apply { background = roundBg(C.CARD, 20, C.LINE) }

/** Menambah [v] ke LinearLayout dengan margin atas dan ukuran tertentu. */
fun LinearLayout.put(v: View, topDp: Int = 0, w: Int = MATCH, h: Int = WRAP, weight: Float = 0f): View {
    addView(v, LinearLayout.LayoutParams(w, h, weight).apply { topMargin = v.context.dp(topDp) })
    return v
}

/** Tombol bentuk pil. Terpilih berwarna emas. */
fun Context.pill(text: String, selected: Boolean, sp: Float = 13f): TextView =
    TextView(this).apply {
        this.text = text
        textSize = sp
        gravity = Gravity.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        setPadding(dp(14), dp(8), dp(14), dp(8))
        isClickable = true
        styleAsPill(selected)
    }

fun TextView.styleAsPill(selected: Boolean) {
    background = context.roundBg(if (selected) C.GOLD else C.CARD2, 20)
    setTextColor(if (selected) Color.parseColor("#1A1405") else C.MUTED)
}

fun Context.field(hint: String, value: String = ""): EditText = EditText(this).apply {
    this.hint = hint
    setText(value)
    setTextColor(C.TEXT)
    setHintTextColor(C.MUTED)
    textSize = 15f
    inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
    background = roundBg(C.CARD2, 12)
    setPadding(dp(12), dp(10), dp(12), dp(10))
}

fun Context.topBar(title: String, onBack: (() -> Unit)?): LinearLayout {
    val bar = hbox().apply { setPadding(dp(8), dp(10), dp(16), dp(6)) }
    if (onBack != null) {
        bar.addView(label("‹", 32f, C.TEXT).apply {
            setPadding(dp(12), 0, dp(14), dp(4))
            setOnClickListener { onBack() }
        })
    } else {
        bar.addView(View(this), LinearLayout.LayoutParams(dp(12), 1))
    }
    bar.addView(label(title, 20f, C.TEXT, true), LinearLayout.LayoutParams(0, WRAP, 1f))
    return bar
}
