package id.annur.jws.widget

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZonedDateTime

/** Satu catatan kegiatan. [remindMin] -1 berarti tanpa pengingat. */
class Ev(
    val id: Long,
    val date: LocalDate,
    val time: LocalTime?,
    val title: String,
    val note: String,
    val remindMin: Int
) {
    fun timeLabel(): String = time?.let { "%02d:%02d".format(it.hour, it.minute) } ?: "Seharian"
}

/** Penyimpanan kegiatan di SharedPreferences dalam bentuk JSON. Berjalan offline. */
object EventStore {
    private const val FILE = "annur_events"
    private const val KEY = "list"

    /** Salinan di memori supaya widget dan kalender tidak membaca ulang JSON tiap kali. */
    @Volatile
    private var cache: List<Ev>? = null

    fun all(ctx: Context): MutableList<Ev> {
        cache?.let { return it.toMutableList() }
        val list = parse(ctx)
        cache = list
        return list.toMutableList()
    }

    private fun parse(ctx: Context): MutableList<Ev> {
        val raw = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString(KEY, null)
            ?: return mutableListOf()
        val out = mutableListOf<Ev>()
        runCatching {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val tm = o.optString("time", "")
                out += Ev(
                    id = o.getLong("id"),
                    date = LocalDate.parse(o.getString("date")),
                    time = if (tm.isEmpty()) null else LocalTime.parse(tm),
                    title = o.optString("title", ""),
                    note = o.optString("note", ""),
                    remindMin = o.optInt("remind", -1)
                )
            }
        }
        return out
    }

    private fun save(ctx: Context, list: List<Ev>) {
        cache = list.toList()
        val arr = JSONArray()
        for (e in list) {
            arr.put(
                JSONObject()
                    .put("id", e.id)
                    .put("date", e.date.toString())
                    .put("time", e.time?.toString() ?: "")
                    .put("title", e.title)
                    .put("note", e.note)
                    .put("remind", e.remindMin)
            )
        }
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }

    fun upsert(ctx: Context, ev: Ev) {
        val list = all(ctx)
        val i = list.indexOfFirst { it.id == ev.id }
        if (i >= 0) list[i] = ev else list.add(ev)
        save(ctx, list)
    }

    fun delete(ctx: Context, id: Long) {
        save(ctx, all(ctx).filter { it.id != id })
    }

    fun forDate(ctx: Context, d: LocalDate): List<Ev> =
        all(ctx).filter { it.date == d }
            .sortedWith(compareBy<Ev> { it.time == null }.thenBy { it.time })

    fun countByDate(ctx: Context): Map<LocalDate, Int> =
        all(ctx).groupingBy { it.date }.eachCount()
}

/** Teks berjalan di widget: teks bebas, kegiatan hari ini, dan hari besar Hijriyah. */
object Marquee {
    fun build(ctx: Context, s: Settings, now: ZonedDateTime): String {
        if (!s.marquee) return ""
        val parts = mutableListOf<String>()
        val free = s.marqueeText.trim()
        if (free.isNotEmpty()) parts += free
        if (s.marqueeEvents) {
            val hj = Hijri.today(s, now)
            val big = Hijri.special(hj, now.dayOfWeek).filter { it.major }.map { it.label }
            if (big.isNotEmpty()) parts += "Hari ini: " + big.joinToString(", ")
            val evs = EventStore.forDate(ctx, now.toLocalDate())
            if (evs.isNotEmpty()) {
                parts += "Kegiatan hari ini: " + evs.joinToString("; ") {
                    (if (it.time != null) it.timeLabel() + " " else "") + it.title
                }
            }
        }
        return if (parts.isEmpty()) "" else parts.joinToString("     •     ") + "          "
    }
}

/** Penjadwal pengingat kegiatan. Saat waktunya tiba, alarm dijalankan lewat [EventAlarm]. */
object EventReminder {
    const val ACTION = "id.annur.jws.widget.EVENT"
    private const val STATE = "annur_event_state"

    private fun triggerMs(e: Ev, zone: java.time.ZoneId): Long? {
        val t = e.time ?: return null
        if (e.remindMin < 0) return null
        return e.date.atTime(t).atZone(zone).toInstant().toEpochMilli() - e.remindMin * 60_000L
    }

    private fun pending(ctx: Context): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, 1,
            Intent(ctx, EventReceiver::class.java).setAction(ACTION),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    fun cancel(ctx: Context) {
        ctx.getSystemService(AlarmManager::class.java).cancel(pending(ctx))
    }

    /**
     * Memasang alarm untuk pengingat terdekat. Memakai alarm jam (setAlarmClock) yang paling andal
     * saat HP tidur dan tidak butuh izin alarm tepat waktu. Dipanggil tiap kegiatan berubah dan setelah boot.
     */
    fun scheduleNext(ctx: Context) {
        val s = AppPrefs.load(ctx)
        if (!s.enabled) {
            cancel(ctx)
            return
        }
        val zone = s.zone()
        val nowMs = System.currentTimeMillis()
        val sp = ctx.getSharedPreferences(STATE, Context.MODE_PRIVATE)
        if (!sp.contains("last")) sp.edit().putLong("last", nowMs).apply()

        var best = Long.MAX_VALUE
        for (e in EventStore.all(ctx)) {
            val at = triggerMs(e, zone) ?: continue
            if (at > nowMs && at < best) best = at
        }
        val am = ctx.getSystemService(AlarmManager::class.java)
        if (best == Long.MAX_VALUE) {
            am.cancel(pending(ctx))
            return
        }
        val show = PendingIntent.getActivity(
            ctx, 3, Intent(ctx, CalendarActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        try {
            am.setAlarmClock(AlarmManager.AlarmClockInfo(best, show), pending(ctx))
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, best, pending(ctx))
        }
    }

    /** Menjalankan alarm untuk pengingat yang waktunya sudah lewat sejak pemeriksaan terakhir. */
    fun fire(ctx: Context) {
        val s = AppPrefs.load(ctx)
        val zone = s.zone()
        val nowMs = System.currentTimeMillis()
        val sp = ctx.getSharedPreferences(STATE, Context.MODE_PRIVATE)
        val last = maxOf(sp.getLong("last", nowMs - 60_000L), nowMs - 6 * 3_600_000L)
        sp.edit().putLong("last", nowMs).apply()
        if (!s.enabled) return

        for (e in EventStore.all(ctx)) {
            val at = triggerMs(e, zone) ?: continue
            if (at <= last || at > nowMs + 1000L) continue
            EventAlarm.ring(ctx, e)
        }
    }
}

class EventReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        when (intent.action) {
            EventReminder.ACTION -> EventReminder.fire(ctx)
            EventAlarm.ACTION_RING -> {
                if (AppPrefs.load(ctx).enabled) {
                    EventAlarm.ring(
                        ctx,
                        intent.getLongExtra("id", 0L),
                        intent.getStringExtra("title") ?: "Kegiatan",
                        intent.getStringExtra("note") ?: "",
                        intent.getStringExtra("when") ?: ""
                    )
                }
            }
        }
        EventReminder.scheduleNext(ctx)
    }
}
