package id.annur.jws.widget

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import java.util.Locale
import java.util.TimeZone

/**
 * Lokasi otomatis. Titik koordinat dari GPS atau jaringan (tidak butuh internet untuk GPS).
 * Nama tempat dari Geocoder Google bila ada internet, atau kota terdekat dari daftar bawaan bila offline.
 * Hasilnya disimpan di pengaturan, sehingga jadwal tetap jalan tanpa internet.
 */
object LocationSync {
    val PERMS = arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)

    /** Pindah lebih dari jarak ini dianggap tempat baru. */
    private const val MOVE_METERS = 1500f
    private const val TIMEOUT_MS = 25_000L
    private const val FRESH_MS = 3 * 60_000L

    class SyncResult(val changed: Boolean, val place: String, val error: String?)

    fun hasPermission(ctx: Context): Boolean =
        PERMS.any { ctx.checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

    private fun hasFine(ctx: Context): Boolean =
        ctx.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    /**
     * Mencari lokasi lalu memperbarui pengaturan bila pindah ke tempat baru (atau [force]).
     * [onDone] dipanggil di thread utama.
     */
    @SuppressLint("MissingPermission")
    fun sync(ctx: Context, force: Boolean, onDone: (SyncResult) -> Unit) {
        val app = ctx.applicationContext
        val main = Handler(Looper.getMainLooper())
        if (!hasPermission(app)) {
            onDone(SyncResult(false, "", "Izin lokasi belum diberikan"))
            return
        }
        val lm = app.getSystemService(LocationManager::class.java)
        if (lm == null) {
            onDone(SyncResult(false, "", "Layanan lokasi tidak tersedia"))
            return
        }

        // Lokasi terakhir yang diketahui sistem
        var last: Location? = null
        for (p in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)) {
            val l = runCatching { lm.getLastKnownLocation(p) }.getOrNull() ?: continue
            if (last == null || l.time > last.time) last = l
        }
        val lastFix = last
        if (!force && lastFix != null && System.currentTimeMillis() - lastFix.time < FRESH_MS) {
            process(app, lastFix, false, onDone)
            return
        }

        val providers = mutableListOf<String>()
        if (hasFine(app) && runCatching { lm.isProviderEnabled(LocationManager.GPS_PROVIDER) }.getOrDefault(false)) {
            providers += LocationManager.GPS_PROVIDER
        }
        if (runCatching { lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) }.getOrDefault(false)) {
            providers += LocationManager.NETWORK_PROVIDER
        }
        if (providers.isEmpty()) {
            if (lastFix != null) process(app, lastFix, force, onDone)
            else onDone(SyncResult(false, "", "Aktifkan layanan lokasi (GPS) di pengaturan HP"))
            return
        }

        var done = false
        val listeners = mutableListOf<LocationListener>()
        fun finishWith(loc: Location?) {
            if (done) return
            done = true
            for (l in listeners) runCatching { lm.removeUpdates(l) }
            if (loc == null) {
                onDone(SyncResult(false, "", "Lokasi belum didapat. Aktifkan GPS dan coba di tempat terbuka"))
            } else {
                process(app, loc, force, onDone)
            }
        }
        for (p in providers) {
            val l = object : LocationListener {
                override fun onLocationChanged(location: Location) = finishWith(location)
                override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
                override fun onProviderEnabled(provider: String) {}
                override fun onProviderDisabled(provider: String) {}
            }
            listeners += l
            runCatching { lm.requestSingleUpdate(p, l, Looper.getMainLooper()) }
        }
        main.postDelayed({ finishWith(lastFix) }, TIMEOUT_MS)
    }

    private fun process(ctx: Context, loc: Location, force: Boolean, onDone: (SyncResult) -> Unit) {
        val main = Handler(Looper.getMainLooper())
        Thread {
            val cur = AppPrefs.load(ctx)
            val moved = FloatArray(1)
            Location.distanceBetween(cur.lat, cur.lon, loc.latitude, loc.longitude, moved)
            val isNew = force || cur.placeName.isEmpty() || moved[0] >= MOVE_METERS
            if (!isNew) {
                main.post { onDone(SyncResult(false, cur.placeName, null)) }
                return@Thread
            }
            val name = placeName(ctx, loc.latitude, loc.longitude)
            val tz = TimeZone.getDefault().getOffset(System.currentTimeMillis()) / 3_600_000.0
            AppPrefs.save(
                ctx,
                cur.copy(
                    lat = Math.round(loc.latitude * 100000.0) / 100000.0,
                    lon = Math.round(loc.longitude * 100000.0) / 100000.0,
                    tz = tz,
                    placeName = name,
                    locUpdated = System.currentTimeMillis()
                )
            )
            main.post {
                Scheduler.refresh(ctx, withWallpaper = true)
                onDone(SyncResult(true, name, null))
            }
        }.start()
    }

    /** Nama tempat dari Geocoder (online), atau kota terdekat dari daftar bawaan, atau koordinat. */
    private fun placeName(ctx: Context, lat: Double, lon: Double): String {
        runCatching {
            if (Geocoder.isPresent()) {
                @Suppress("DEPRECATION")
                val a = Geocoder(ctx, Locale.forLanguageTag("id-ID")).getFromLocation(lat, lon, 1)?.firstOrNull()
                if (a != null) {
                    val parts = listOfNotNull(a.subLocality, a.locality ?: a.subAdminArea)
                        .filter { it.isNotBlank() }.distinct()
                    if (parts.isNotEmpty()) return parts.joinToString(", ")
                    a.adminArea?.let { if (it.isNotBlank()) return it }
                }
            }
        }
        var bestName: String? = null
        var bestDist = Float.MAX_VALUE
        val r = FloatArray(1)
        for (c in Cities.all) {
            Location.distanceBetween(lat, lon, c.lat, c.lon, r)
            if (r[0] < bestDist) {
                bestDist = r[0]
                bestName = c.name.substringBefore(" (")
            }
        }
        if (bestName != null && bestDist < 40_000f) return "Dekat $bestName"
        return String.format(Locale.US, "%.4f, %.4f", lat, lon)
    }
}
