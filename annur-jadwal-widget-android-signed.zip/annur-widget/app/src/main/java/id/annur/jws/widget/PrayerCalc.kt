package id.annur.jws.widget

import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan
import kotlin.math.atan2
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin
import kotlin.math.tan

/** Metode perhitungan: sudut Subuh dan Isya serta ihtiyat (menit). Sama dengan versi web. */
class Method(val fajr: Double, val isha: Double, val ihtiyat: Int)

val METHODS: Map<String, Method> = linkedMapOf(
    "kemenag" to Method(20.0, 18.0, 2),
    "muhammadiyah" to Method(18.0, 18.0, 2),
    "mwl" to Method(18.0, 17.0, 0),
    "isna" to Method(15.0, 15.0, 0)
)

class PrayerConfig(
    val lat: Double,
    val lon: Double,
    val tz: Double,
    val method: Method,
    val asrFactor: Double
)

/** Waktu dalam detik sejak tengah malam, di zona waktu yang dipilih pengguna. */
class DayTimes(
    val subuh: Long,
    val terbit: Long,
    val dhuha: Long,
    val zuhur: Long,
    val asar: Long,
    val maghrib: Long,
    val isya: Long
)

class NextPrayer(val name: String, val epochMs: Long)

/**
 * Algoritma matahari standar (Jean Meeus), offline, sama dengan versi web
 * "An-Nur JWS Digital". Tidak butuh internet.
 */
object PrayerCalc {
    private const val RAD = Math.PI / 180.0

    private fun sn(d: Double) = sin(d * RAD)
    private fun cs(d: Double) = cos(d * RAD)
    private fun tanD(d: Double) = tan(d * RAD)
    private fun asinD(x: Double) = asin(x) / RAD
    private fun acosD(x: Double) = acos(x) / RAD
    private fun atan2D(y: Double, x: Double) = atan2(y, x) / RAD
    private fun acotD(x: Double) = atan(1.0 / x) / RAD
    private fun fixA(a: Double) = a - 360.0 * floor(a / 360.0)
    private fun fixH(a: Double) = a - 24.0 * floor(a / 24.0)

    private fun julian(y0: Int, m0: Int, d: Int): Double {
        var y = y0
        var m = m0
        if (m <= 2) {
            y -= 1
            m += 12
        }
        val a = floor(y / 100.0)
        val b = 2 - a + floor(a / 4.0)
        return floor(365.25 * (y + 4716)) + floor(30.6001 * (m + 1)) + d + b - 1524.5
    }

    private class Sun(val decl: Double, val eqt: Double)

    private fun sunPos(jd: Double): Sun {
        val d = jd - 2451545.0
        val g = fixA(357.529 + 0.98560028 * d)
        val q = fixA(280.459 + 0.98564736 * d)
        val l = fixA(q + 1.915 * sn(g) + 0.02 * sn(2 * g))
        val e = 23.439 - 3.6e-7 * d
        val ra = fixH(atan2D(cs(e) * sn(l), cs(l)) / 15.0)
        return Sun(asinD(sn(e) * sn(l)), q / 15.0 - ra)
    }

    fun compute(cfg: PrayerConfig, y: Int, m: Int, d: Int): DayTimes {
        val lat = cfg.lat
        val lon = cfg.lon
        val jd = julian(y, m, d) - lon / (15.0 * 24.0)

        fun mid(t: Double) = fixH(12.0 - sunPos(jd + t).eqt)

        fun ang(a: Double, t: Double, ccw: Boolean): Double {
            val dc = sunPos(jd + t).decl
            val x = (-sn(a) - sn(dc) * sn(lat)) / (cs(dc) * cs(lat))
            if (x < -1.0 || x > 1.0) return Double.NaN
            return mid(t) + (if (ccw) -1.0 else 1.0) * acosD(x) / 15.0
        }

        fun asr(f: Double, t: Double): Double {
            val dc = sunPos(jd + t).decl
            return ang(-acotD(f + tanD(abs(lat - dc))), t, false)
        }

        // Tebakan awal dalam pecahan hari: subuh, terbit, dhuha, zuhur, asar, maghrib, isya
        val tf = doubleArrayOf(5.0, 6.0, 7.0, 12.0, 13.0, 18.0, 18.0).map { it / 24.0 }.toDoubleArray()
        var h = DoubleArray(7)
        repeat(2) {
            h = doubleArrayOf(
                ang(cfg.method.fajr, tf[0], true),
                ang(0.833, tf[1], true),
                ang(-4.5, tf[2], true),
                mid(tf[3]),
                asr(cfg.asrFactor, tf[4]),
                ang(0.833, tf[5], false),
                ang(cfg.method.isha, tf[6], false)
            )
            for (i in 0..6) if (!h[i].isNaN()) tf[i] = h[i] / 24.0
        }

        val off = cfg.tz - lon / 15.0
        val ih = cfg.method.ihtiyat.toDouble()

        fun mins(hh: Double, add: Double): Double =
            if (hh.isNaN()) Double.NaN else ceil((hh + off) * 60.0 - 1e-7) + add

        val subuh0 = mins(h[0], ih)
        val terbit = mins(h[1], -ih)
        val dhuha = mins(h[2], 0.0)
        val zuhur = mins(h[3], ih)
        val asar = mins(h[4], ih)
        val maghrib = mins(h[5], ih)
        val isya0 = mins(h[6], ih)

        // Lintang tinggi: Subuh/Isya tidak terdefinisi, pakai perkiraan seperti versi web
        val subuh = if (subuh0.isNaN()) terbit - 90 else subuh0
        val isya = if (isya0.isNaN()) maghrib + 90 else isya0

        return DayTimes(
            subuh = (subuh * 60).toLong(),
            terbit = (terbit * 60).toLong(),
            dhuha = (dhuha * 60).toLong(),
            zuhur = (zuhur * 60).toLong(),
            asar = (asar * 60).toLong(),
            maghrib = (maghrib * 60).toLong(),
            isya = (isya * 60).toLong()
        )
    }

    fun epochMs(zone: ZoneId, date: LocalDate, secs: Long): Long =
        date.atStartOfDay(zone).toInstant().toEpochMilli() + secs * 1000L

    /** Waktu berikutnya dari sekarang, termasuk Terbit. Setelah Isya, yang dipakai Subuh besok. */
    fun nextPrayer(cfg: PrayerConfig, zone: ZoneId, now: ZonedDateTime): NextPrayer {
        val today = now.toLocalDate()
        val t = compute(cfg, today.year, today.monthValue, today.dayOfMonth)
        val nowSec = now.toLocalTime().toSecondOfDay().toLong()
        val list = listOf(
            "Subuh" to t.subuh,
            "Terbit" to t.terbit,
            "Zuhur" to t.zuhur,
            "Asar" to t.asar,
            "Maghrib" to t.maghrib,
            "Isya" to t.isya
        )
        for ((name, s) in list) {
            if (s > nowSec) return NextPrayer(name, epochMs(zone, today, s))
        }
        val tom = today.plusDays(1)
        val tt = compute(cfg, tom.year, tom.monthValue, tom.dayOfMonth)
        return NextPrayer("Subuh", epochMs(zone, tom, tt.subuh))
    }
}
