package id.annur.jws.widget

import java.time.ZonedDateTime

/** Ringkasan jadwal hari ini untuk halaman utama. Setelah Isya, yang dipakai jadwal besok. */
class TodayInfo(
    val times: List<String>,
    val passed: BooleanArray,
    val nextIdx: Int,
    val nextName: String,
    val nextMs: Long,
    val tomorrow: Boolean
)

object TodayCalc {
    val NAMES = listOf("Subuh", "Terbit", "Zuhur", "Asar", "Maghrib", "Isya")

    fun load(s: Settings, now: ZonedDateTime): TodayInfo {
        val zone = s.zone()
        val cfg = s.config()
        val next = PrayerCalc.nextPrayer(cfg, zone, now)
        val d = PrayerCalc.compute(cfg, now.year, now.monthValue, now.dayOfMonth)
        var secs = longArrayOf(d.subuh, d.terbit, d.zuhur, d.asar, d.maghrib, d.isya)
        val nowSec = now.toLocalTime().toSecondOfDay().toLong()
        var passed = BooleanArray(6) { secs[it] <= nowSec }
        var tomorrow = false
        if (passed.all { it }) {
            val tom = now.toLocalDate().plusDays(1)
            val tt = PrayerCalc.compute(cfg, tom.year, tom.monthValue, tom.dayOfMonth)
            secs = longArrayOf(tt.subuh, tt.terbit, tt.zuhur, tt.asar, tt.maghrib, tt.isya)
            passed = BooleanArray(6)
            tomorrow = true
        }
        return TodayInfo(
            secs.map { fmtHm(it) }, passed,
            NAMES.indexOf(next.name).coerceAtLeast(0), next.name, next.epochMs, tomorrow
        )
    }
}
