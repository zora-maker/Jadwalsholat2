package id.annur.jws.widget

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import java.time.ZonedDateTime

/** Format detik sejak tengah malam menjadi "HH:mm". */
fun fmtHm(sec: Long): String {
    val m = ((sec / 60) % 1440 + 1440) % 1440
    return "%02d:%02d".format(m / 60, m % 60)
}

/**
 * Satu pintu untuk memperbarui widget, notifikasi, dan wallpaper layar kunci,
 * lalu menjadwalkan alarm berikutnya.
 *
 * Alarm berikutnya dipasang pada yang paling dekat dari: waktu sholat berikutnya,
 * akhir tampilan fokus, atau tengah malam. Alarm memakai RTC_WAKEUP dan, bila diizinkan,
 * alarm tepat waktu, supaya HP yang tidur tetap tepat membangunkan aplikasi.
 *
 * [withWallpaper] hanya true saat alarm, boot, atau pengaturan disimpan, supaya wallpaper
 * tidak ikut diganti setiap 30 menit saat widget diperbarui.
 * [fromAlarm] true hanya untuk alarm, dan satu-satunya yang boleh memicu getar.
 */
object Scheduler {
    const val ACTION_TICK = "id.annur.jws.widget.TICK"
    private const val STATE = "annur_state"
    private const val VIBRATE_MS = 5000L

    fun refresh(ctx: Context, withWallpaper: Boolean = false, fromAlarm: Boolean = false) {
        val s = AppPrefs.load(ctx)
        val now = ZonedDateTime.now(s.zone())

        if (fromAlarm && s.vibrate && s.enabled) {
            Focus.current(s, now)?.let { vibrateOnce(ctx, it) }
        }

        val mainWidget = PrayerWidgetProvider.renderAll(ctx, s)
        val artWidget = ArtWidgets.renderAll(ctx, s)
        val hasWidget = mainWidget || artWidget
        val notifOn = s.enabled && s.notif
        val wallOn = s.enabled && s.lockWp
        if (notifOn) NotificationHelper.show(ctx, s) else NotificationHelper.hide(ctx)
        if (withWallpaper && wallOn) runCatching { LockWallpaper.apply(ctx, s) }
        if (hasWidget || notifOn || wallOn) scheduleNext(ctx, s) else cancel(ctx)
        runCatching { EventReminder.scheduleNext(ctx) }
        runCatching { GlassLock.ensure(ctx, s) }
    }

    /** Getar 5 detik, satu kali untuk tiap waktu sholat, sekalipun alarm terlambat atau terpanggil dua kali. */
    private fun vibrateOnce(ctx: Context, f: FocusInfo) {
        val sp = ctx.getSharedPreferences(STATE, Context.MODE_PRIVATE)
        val key = f.startMs.toString()
        if (sp.getString("last_alert", null) == key) return
        sp.edit().putString("last_alert", key).apply()

        val vib = ctx.getSystemService(Vibrator::class.java) ?: return
        runCatching {
            vib.vibrate(VibrationEffect.createOneShot(VIBRATE_MS, VibrationEffect.DEFAULT_AMPLITUDE))
        }
    }

    private fun pending(ctx: Context): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, 0,
            Intent(ctx, RefreshReceiver::class.java).setAction(ACTION_TICK),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    private fun scheduleNext(ctx: Context, s: Settings) {
        val zone = s.zone()
        val now = ZonedDateTime.now(zone)
        val next = PrayerCalc.nextPrayer(s.config(), zone, now)
        val midnight = now.toLocalDate().plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli()

        var at = minOf(next.epochMs, midnight)
        Focus.current(s, now)?.let { at = minOf(at, it.endMs) }
        at += 1000L

        val am = ctx.getSystemService(AlarmManager::class.java)
        val canExact = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am.canScheduleExactAlarms()
        try {
            if (canExact) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending(ctx))
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending(ctx))
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending(ctx))
        }
    }

    private fun cancel(ctx: Context) {
        ctx.getSystemService(AlarmManager::class.java).cancel(pending(ctx))
    }
}

/** Menerima alarm, boot selesai, aplikasi diperbarui, dan perubahan jam atau zona waktu. */
class RefreshReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        Scheduler.refresh(
            ctx,
            withWallpaper = true,
            fromAlarm = intent.action == Scheduler.ACTION_TICK
        )
    }
}
