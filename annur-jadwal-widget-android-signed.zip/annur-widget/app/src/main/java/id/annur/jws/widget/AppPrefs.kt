package id.annur.jws.widget

import android.content.Context
import java.time.ZoneId
import java.time.ZoneOffset

data class Settings(
    val name: String = "Masjid An-Nur",
    val lat: Double = -6.2088,
    val lon: Double = 106.8456,
    val tz: Double = 7.0,
    val method: String = "kemenag",
    val asr: Int = 1,
    val notif: Boolean = true,
    val lockWp: Boolean = false,
    val theme: Int = 0,
    /** Lama tampilan fokus saat waktu sholat tiba, dalam menit. 0 = nonaktif. */
    val alertMin: Int = 2,
    /** Getar 5 detik saat waktu sholat tiba. */
    val vibrate: Boolean = true
) {
    fun config(): PrayerConfig = PrayerConfig(
        lat = lat,
        lon = lon,
        tz = tz,
        method = METHODS[method] ?: METHODS.getValue("kemenag"),
        asrFactor = if (asr == 2) 2.0 else 1.0
    )

    fun zone(): ZoneId = ZoneOffset.ofTotalSeconds(Math.round(tz * 3600).toInt())
}

object AppPrefs {
    private const val FILE = "annur_prefs"

    fun load(ctx: Context): Settings {
        val p = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        val d = Settings()
        fun dbl(k: String, def: Double) = p.getString(k, null)?.toDoubleOrNull() ?: def
        return Settings(
            name = p.getString("name", null) ?: d.name,
            lat = dbl("lat", d.lat),
            lon = dbl("lon", d.lon),
            tz = dbl("tz", d.tz),
            method = p.getString("method", null) ?: d.method,
            asr = p.getString("asr", null)?.toIntOrNull() ?: d.asr,
            notif = p.getBoolean("notif", d.notif),
            lockWp = p.getBoolean("lockWp", d.lockWp),
            theme = p.getInt("theme", d.theme),
            alertMin = p.getInt("alertMin", d.alertMin),
            vibrate = p.getBoolean("vibrate", d.vibrate)
        )
    }

    fun save(ctx: Context, s: Settings) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putString("name", s.name)
            .putString("lat", s.lat.toString())
            .putString("lon", s.lon.toString())
            .putString("tz", s.tz.toString())
            .putString("method", s.method)
            .putString("asr", s.asr.toString())
            .putBoolean("notif", s.notif)
            .putBoolean("lockWp", s.lockWp)
            .putInt("theme", s.theme)
            .putInt("alertMin", s.alertMin)
            .putBoolean("vibrate", s.vibrate)
            .apply()
    }
}
