package id.annur.jws.widget

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator

/**
 * Alarm kegiatan: bunyi di jalur alarm, getar berulang, notifikasi di layar kunci,
 * dan pop up catatan. Dijalankan lewat layanan latar depan agar tidak mati saat layar terkunci.
 */
object EventAlarm {
    const val ACTION_RING = "id.annur.jws.widget.EVENT_RING"
    const val ACTION_STOP = "id.annur.jws.widget.EVENT_STOP"
    const val ACTION_SNOOZE = "id.annur.jws.widget.EVENT_SNOOZE"
    const val ACTION_CLOSED = "id.annur.jws.widget.EVENT_CLOSED"
    const val CH_ALARM = "kegiatan_alarm"
    const val CH_NOTIF = "kegiatan_notif"
    const val SNOOZE_MIN = 10

    /** True selama alarm kegiatan berbunyi. Lapisan kaca tidak tampil agar pop up tidak tertutup. */
    @Volatile
    var active = false

    fun nid(id: Long): Int = 3000 + (Math.abs(id) % 10000L).toInt()

    fun put(i: Intent, id: Long, title: String, note: String, whenText: String): Intent =
        i.putExtra("id", id).putExtra("title", title).putExtra("note", note).putExtra("when", whenText)

    fun copy(from: Intent, to: Intent): Intent {
        from.extras?.let { to.putExtras(it) }
        return to
    }

    fun whenText(e: Ev, s: Settings): String {
        val lead = if (e.remindMin > 0) "${e.remindMin} menit lagi • " else ""
        val at = if (e.time != null) e.timeLabel() + " • " else ""
        return lead + at + Hijri.both(e.date, s.hijriOffset)
    }

    /** Dua saluran: alarm (senyap, bunyi diatur sendiri) dan cadangan (bunyi bawaan sistem). */
    fun ensureChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_ALARM, "Alarm kegiatan", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Pengingat kegiatan dengan bunyi alarm dan pop up"
                setSound(null, null)
                enableVibration(false)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_NOTIF, "Pengingat kegiatan (notifikasi)", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Cadangan bila alarm tidak dapat dijalankan"
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
        )
    }

    fun buildNotif(
        ctx: Context, channel: String, id: Long, title: String, note: String, whenText: String,
        ongoing: Boolean, fullScreen: Boolean
    ): Notification {
        val s = AppPrefs.load(ctx)
        val rc = nid(id) * 4
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE

        fun carrier(cls: Class<*>) = put(Intent(ctx, cls), id, title, note, whenText)

        val target = if (s.evPopup) EventPopupActivity::class.java else CalendarActivity::class.java
        val open = PendingIntent.getActivity(
            ctx, rc, carrier(target).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP), flags
        )
        val snooze = PendingIntent.getService(
            ctx, rc + 1, carrier(EventAlarmService::class.java).setAction(ACTION_SNOOZE), flags
        )
        val stop = PendingIntent.getService(
            ctx, rc + 2, carrier(EventAlarmService::class.java).setAction(ACTION_STOP), flags
        )
        val icon = Icon.createWithResource(ctx, R.drawable.ic_notif)

        val b = Notification.Builder(ctx, channel)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(title)
            .setContentText(whenText)
            .setStyle(Notification.BigTextStyle().bigText(if (note.isBlank()) whenText else "$whenText\n$note"))
            .setCategory(Notification.CATEGORY_ALARM)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setOngoing(ongoing)
            .setAutoCancel(!ongoing)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(icon, "Tunda $SNOOZE_MIN mnt", snooze).build())
            .addAction(Notification.Action.Builder(icon, "Selesai", stop).build())
        if (fullScreen) {
            val full = PendingIntent.getActivity(ctx, rc + 3, carrier(EventPopupActivity::class.java), flags)
            b.setFullScreenIntent(full, true)
        }
        return b.build()
    }

    /** Menjalankan alarm kegiatan. Bila layanan tidak boleh dimulai, jatuh ke notifikasi biasa. */
    fun ring(ctx: Context, id: Long, title: String, note: String, whenText: String) {
        val i = put(Intent(ctx, EventAlarmService::class.java).setAction(ACTION_RING), id, title, note, whenText)
        try {
            ctx.startForegroundService(i)
        } catch (e: Exception) {
            ensureChannels(ctx)
            val n = buildNotif(ctx, CH_NOTIF, id, title, note, whenText, ongoing = false,
                fullScreen = AppPrefs.load(ctx).evPopup)
            runCatching { ctx.getSystemService(NotificationManager::class.java).notify(nid(id), n) }
        }
    }

    fun ring(ctx: Context, e: Ev) {
        val s = AppPrefs.load(ctx)
        ring(ctx, e.id, e.title, e.note, whenText(e, s))
    }

    /** Memasang alarm tunda 10 menit dengan isi kegiatan yang sama. */
    fun scheduleSnooze(ctx: Context, src: Intent) {
        val id = src.getLongExtra("id", 0L)
        val i = copy(src, Intent(ctx, EventReceiver::class.java)).setAction(ACTION_RING)
        val pi = PendingIntent.getBroadcast(
            ctx, 5000 + (Math.abs(id) % 10000L).toInt(), i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val show = PendingIntent.getActivity(ctx, 3, Intent(ctx, CalendarActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val at = System.currentTimeMillis() + SNOOZE_MIN * 60_000L
        ctx.getSystemService(AlarmManager::class.java).setAlarmClock(AlarmManager.AlarmClockInfo(at, show), pi)
    }

    /** Menghentikan bunyi dan getar yang sedang berjalan. */
    fun stopAll(ctx: Context) {
        ctx.stopService(Intent(ctx, EventAlarmService::class.java))
    }
}

class EventAlarmService : Service() {
    private var player: MediaPlayer? = null
    private var wake: PowerManager.WakeLock? = null
    private val handler = Handler(Looper.getMainLooper())
    private var curNid = 0
    private var cur: Intent? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            EventAlarm.ACTION_STOP -> finish(intent, removeNotif = true)
            EventAlarm.ACTION_SNOOZE -> {
                EventAlarm.scheduleSnooze(this, intent)
                finish(intent, removeNotif = true)
            }
            else -> if (intent != null) start(intent) else stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun start(intent: Intent) {
        val id = intent.getLongExtra("id", 0L)
        val title = intent.getStringExtra("title") ?: "Kegiatan"
        val note = intent.getStringExtra("note") ?: ""
        val whenText = intent.getStringExtra("when") ?: ""
        val s = AppPrefs.load(this)
        val test = intent.hasExtra("t_sec")

        curNid = EventAlarm.nid(id)
        cur = intent
        EventAlarm.active = true
        GlassOverlay.hide()
        EventAlarm.ensureChannels(this)
        val n = EventAlarm.buildNotif(
            this, EventAlarm.CH_ALARM, id, title, note, whenText,
            ongoing = true, fullScreen = s.evPopup || test
        )
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(curNid, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(curNid, n)
        }
        if (!s.enabled && !test) {
            finish(intent, removeNotif = true)
            return
        }

        val sound = intent.getBooleanExtra("t_sound", s.evAlarm)
        val vib = intent.getBooleanExtra("t_vib", s.evVibrate)
        val sec = intent.getIntExtra("t_sec", s.alarmSec).coerceIn(5, 300)

        stopEffects()
        if (sound) startSound()
        if (vib) startVibrate()
        runCatching {
            wake?.takeIf { it.isHeld }?.release()
            wake = getSystemService(PowerManager::class.java)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "jws:evalarm")
                .apply { acquire(sec * 1000L + 5000L) }
        }
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({ timeout() }, sec * 1000L)
    }

    private fun startSound() {
        runCatching {
            val uri = RingtoneManager.getActualDefaultRingtoneUri(this, RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            mp.setDataSource(this, uri)
            mp.isLooping = true
            mp.prepare()
            mp.start()
            player = mp
        }
    }

    private fun startVibrate() {
        runCatching {
            val v = getSystemService(Vibrator::class.java) ?: return
            val pattern = longArrayOf(0, 800, 500, 800, 500, 1200, 1000)
            v.vibrate(VibrationEffect.createWaveform(pattern, 0))
        }
    }

    private fun stopEffects() {
        runCatching { player?.stop() }
        runCatching { player?.release() }
        player = null
        runCatching { getSystemService(Vibrator::class.java)?.cancel() }
        runCatching { wake?.takeIf { it.isHeld }?.release() }
    }

    /** Waktu bunyi habis: diamkan, tapi biarkan notifikasi tetap ada di panel. */
    private fun timeout() {
        EventAlarm.active = false
        stopEffects()
        val i = cur
        stopForeground(STOP_FOREGROUND_DETACH)
        if (i != null) {
            val n = EventAlarm.buildNotif(
                this, EventAlarm.CH_ALARM, i.getLongExtra("id", 0L),
                i.getStringExtra("title") ?: "Kegiatan", i.getStringExtra("note") ?: "",
                i.getStringExtra("when") ?: "", ongoing = false, fullScreen = false
            )
            runCatching { getSystemService(NotificationManager::class.java).notify(curNid, n) }
        }
        stopSelf()
    }

    private fun finish(intent: Intent, removeNotif: Boolean) {
        EventAlarm.active = false
        handler.removeCallbacksAndMessages(null)
        stopEffects()
        val nid = EventAlarm.nid(intent.getLongExtra("id", 0L))
        if (removeNotif) {
            runCatching { getSystemService(NotificationManager::class.java).cancel(nid) }
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        sendBroadcast(Intent(EventAlarm.ACTION_CLOSED).setPackage(packageName))
        stopSelf()
    }

    override fun onDestroy() {
        EventAlarm.active = false
        handler.removeCallbacksAndMessages(null)
        stopEffects()
        super.onDestroy()
    }
}
