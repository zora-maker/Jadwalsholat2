package id.annur.jws.widget

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View

/** Satu kotak tanggal di kalender: angka utama, angka kalender lain, dan titik penanda. */
class DayCellView(ctx: Context) : View(ctx) {
    var main = ""
    var sub = ""
    var inMonth = true
    var isToday = false
    var isSelected2 = false
    var eventCount = 0
    var major = false
    var friday = false

    private val d = ctx.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val fade = if (inMonth) 1f else 0.3f

        if (isSelected2) {
            p.style = Paint.Style.FILL
            p.color = C.alpha(C.GOLD, 0.18f)
            c.drawRoundRect(RectF(3 * d, 2 * d, w - 3 * d, h - 2 * d), 14 * d, 14 * d, p)
            p.style = Paint.Style.STROKE
            p.strokeWidth = 1.5f * d
            p.color = C.alpha(C.GOLD, 0.9f)
            c.drawRoundRect(RectF(3 * d, 2 * d, w - 3 * d, h - 2 * d), 14 * d, 14 * d, p)
        }

        val cy = h * 0.38f
        if (isToday) {
            p.style = Paint.Style.FILL
            p.color = C.GOLD
            c.drawCircle(w / 2f, cy, 15 * d, p)
        }

        p.style = Paint.Style.FILL
        p.textAlign = Paint.Align.CENTER
        p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        p.textSize = 16 * d
        p.color = when {
            isToday -> Color.parseColor("#1A1405")
            friday -> C.alpha(C.GOLD, fade)
            else -> C.alpha(C.TEXT, fade)
        }
        c.drawText(main, w / 2f, cy + 5.5f * d, p)

        p.typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        p.textSize = 10 * d
        p.color = C.alpha(C.MUTED, fade)
        c.drawText(sub, w / 2f, h * 0.74f, p)

        // Titik penanda: hijau untuk kegiatan, emas untuk hari besar
        val n = eventCount.coerceAtMost(3)
        val total = n + (if (major) 1 else 0)
        var x = w / 2f - (total - 1) * 4 * d
        val y = h - 6 * d
        p.color = C.alpha(C.TEAL, fade)
        for (i in 0 until n) {
            c.drawCircle(x, y, 2.4f * d, p)
            x += 8 * d
        }
        if (major) {
            p.color = C.alpha(C.GOLD, fade)
            c.drawCircle(x, y, 2.4f * d, p)
        }
    }
}
