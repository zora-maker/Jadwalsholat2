package id.annur.jws.widget

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.SystemClock
import android.text.Spannable
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RemoteViews
import android.widget.ScrollView
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Tema yang dipilih untuk tiap widget (per id widget). */
object WidgetThemes {
    private const val FILE = "annur_widget_theme"

    fun get(ctx: Context, id: Int): Int =
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getInt("w$id", 0)
            .coerceIn(0, ThemeArt.themes.size - 1)

    fun set(ctx: Context, id: Int, idx: Int) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putInt("w$id", idx).apply()
    }

    fun remove(ctx: Context, ids: IntArray) {
        val e = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
        for (i in ids) e.remove("w$i")
        e.apply()
    }
}

/**
 * Tiga ukuran widget bertema: Persegi (2x2), Lebar (4x2), dan Tipis (4x1).
 * Lima tema latar dipilih saat widget ditambahkan, dan bisa diganti lewat konfigurasi ulang widget.
 */
object ThemeWidgets {
    private val ID = Locale.forLanguageTag("id-ID")
    private val DATE_SHORT = DateTimeFormatter.ofPattern("EEEE, d MMM", ID)
    private val DATE_LONG = DateTimeFormatter.ofPattern("EEEE, d MMM yyyy", ID)

    private val Q_N = intArrayOf(R.id.qn0, R.id.qn1)
    private val Q_T = intArrayOf(R.id.qt0, R.id.qt1)
    private val L_H = intArrayOf(R.id.lh0, R.id.lh1, R.id.lh2, R.id.lh3, R.id.lh4)
    private val L_N = intArrayOf(R.id.ln0, R.id.ln1, R.id.ln2, R.id.ln3, R.id.ln4)
    private val L_T = intArrayOf(R.id.lt0, R.id.lt1, R.id.lt2, R.id.lt3, R.id.lt4)
    private val T_H = intArrayOf(R.id.th0, R.id.th1, R.id.th2, R.id.th3, R.id.th4)
    private val T_N = intArrayOf(R.id.tn0, R.id.tn1, R.id.tn2, R.id.tn3, R.id.tn4)
    private val T_T = intArrayOf(R.id.tt0, R.id.tt1, R.id.tt2, R.id.tt3, R.id.tt4)

    private val WHITE = 0xFFFFFFFF.toInt()
    private val SOFT = 0xCCFFFFFF.toInt()
    private val DIM = 0x99FFFFFF.toInt()

    /** Nama masjid: kata pertama dan terakhir berwarna aksen, kata tengah putih. */
    private fun styledName(name: String, accent: Int): CharSequence {
        val sp = SpannableString(name)
        val words = Regex("\\S+").findAll(name).toList()
        for ((i, m) in words.withIndex()) {
            if (i == 0 || i == words.size - 1) {
                sp.setSpan(
                    ForegroundColorSpan(accent), m.range.first, m.range.last + 1,
                    Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
                )
            }
        }
        return sp
    }

    /** Mewarnai gambar putih dengan [color] termasuk transparansinya. */
    private fun tint(rv: RemoteViews, id: Int, color: Int) {
        rv.setInt(id, "setColorFilter", color or 0xFF000000.toInt())
        rv.setInt(id, "setImageAlpha", Color.alpha(color))
    }

    private fun showPlace(rv: RemoteViews, pin: Int, text: Int, name: String, accent: Int) {
        if (name.isEmpty()) {
            rv.setViewVisibility(pin, View.GONE)
            rv.setViewVisibility(text, View.GONE)
        } else {
            rv.setViewVisibility(pin, View.VISIBLE)
            rv.setInt(pin, "setColorFilter", accent)
            if (text != 0) {
                rv.setViewVisibility(text, View.VISIBLE)
                rv.setTextViewText(text, name)
            }
        }
    }

    fun render(
        ctx: Context, mgr: AppWidgetManager, id: Int, kind: Int, s: Settings,
        now: ZonedDateTime, d: ArtWidgets.Data, place: String
    ): RemoteViews {
        val idx = WidgetThemes.get(ctx, id)
        val th = ThemeArt.theme(idx)
        val hj = Hijri.today(s, now)
        val dens = ctx.resources.displayMetrics.density
        return when (kind) {
            0 -> square(ctx, mgr, id, idx, th, s, now, d, place, hj, dens)
            1 -> wide(ctx, mgr, id, idx, th, s, now, d, place, hj, dens)
            else -> slim(ctx, mgr, id, idx, th, s, d, dens)
        }
    }

    private fun square(
        ctx: Context, mgr: AppWidgetManager, id: Int, idx: Int, th: WTheme, s: Settings,
        now: ZonedDateTime, d: ArtWidgets.Data, place: String, hj: HDate, dens: Float
    ): RemoteViews {
        val rv = RemoteViews(ctx.packageName, R.layout.widget_tq)
        val sz = ArtWidgets.sizePx(ctx, mgr, id, 150, 160)
        rv.setImageViewBitmap(R.id.qBg, ThemeArt.draw(idx, sz[0], sz[1], dens))
        rv.setTextViewText(R.id.qName, styledName(s.name, th.accent))
        // Persegi hanya menampilkan ikon lokasi bila ada, nama tempat dipendekkan
        showPlace(rv, R.id.qPin, R.id.qPlace, place, th.accent)
        tint(rv, R.id.qPillBg, th.pillBg)
        rv.setTextColor(R.id.qCount, th.accent)
        ArtWidgets.countdown(rv, R.id.qCount, d)

        val pos = ArtWidgets.SHOWN.indexOf(d.markIdx).let { if (it < 0) 1 else it }
        for (r in 0..1) {
            val i = ArtWidgets.SHOWN[(pos + r) % 5]
            rv.setTextViewText(Q_N[r], ArtWidgets.NAMES[i])
            rv.setTextViewText(Q_T[r], fmtHm(d.times[i]))
            rv.setTextColor(Q_N[r], if (r == 0) th.accent else SOFT)
            rv.setTextColor(Q_T[r], if (r == 0) th.accent else WHITE)
        }
        rv.setTextViewText(R.id.qDate, DATE_SHORT.format(now) + " • " + hj.d + " " + hj.monthName)
        return rv
    }

    private fun wide(
        ctx: Context, mgr: AppWidgetManager, id: Int, idx: Int, th: WTheme, s: Settings,
        now: ZonedDateTime, d: ArtWidgets.Data, place: String, hj: HDate, dens: Float
    ): RemoteViews {
        val rv = RemoteViews(ctx.packageName, R.layout.widget_tw)
        val sz = ArtWidgets.sizePx(ctx, mgr, id, 320, 160)
        rv.setImageViewBitmap(R.id.lBg, ThemeArt.draw(idx, sz[0], sz[1], dens))
        rv.setTextViewText(R.id.lName, styledName(s.name, th.accent))
        showPlace(rv, R.id.lPin, R.id.lPlace, place, th.accent)
        tint(rv, R.id.lPillBg, th.pillBg)
        rv.setTextColor(R.id.lCount, th.accent)
        ArtWidgets.countdown(rv, R.id.lCount, d)
        rv.setTextViewText(R.id.lDate, DATE_LONG.format(now) + " • " + hj.toString())

        for (i in 0..4) {
            val p = ArtWidgets.SHOWN[i]
            val mark = p == d.markIdx
            val dim = d.passed[p] && !mark
            rv.setTextViewText(L_N[i], ArtWidgets.NAMES[p])
            rv.setTextViewText(L_T[i], fmtHm(d.times[p]))
            tint(rv, L_H[i], if (mark) th.accent else th.rowBg)
            rv.setTextColor(L_N[i], if (mark) th.onAccent else if (dim) DIM else SOFT)
            rv.setTextColor(L_T[i], if (mark) th.onAccent else if (dim) DIM else WHITE)
        }
        return rv
    }

    private fun slim(
        ctx: Context, mgr: AppWidgetManager, id: Int, idx: Int, th: WTheme, s: Settings,
        d: ArtWidgets.Data, dens: Float
    ): RemoteViews {
        val rv = RemoteViews(ctx.packageName, R.layout.widget_ts)
        val sz = ArtWidgets.sizePx(ctx, mgr, id, 320, 70)
        rv.setImageViewBitmap(R.id.tBg, ThemeArt.draw(idx, sz[0], sz[1], dens))
        rv.setTextViewText(R.id.tName, styledName(s.name, th.accent))
        rv.setInt(R.id.tIcon, "setColorFilter", th.accent)

        val f = d.focus
        rv.setTextColor(R.id.tCount, th.accent)
        if (f != null) {
            rv.setTextViewText(R.id.tNext, "${f.name} tiba")
            val elapsed = System.currentTimeMillis() - f.startMs
            rv.setChronometerCountDown(R.id.tCount, false)
            rv.setChronometer(R.id.tCount, SystemClock.elapsedRealtime() - elapsed, "+%s", true)
        } else {
            rv.setTextViewText(R.id.tNext, "Menuju ${d.nextName}")
            rv.setChronometerCountDown(R.id.tCount, true)
            rv.setChronometer(R.id.tCount, SystemClock.elapsedRealtime() + d.remainMs, "%s", true)
        }

        for (i in 0..4) {
            val p = ArtWidgets.SHOWN[i]
            val mark = p == d.markIdx
            val dim = d.passed[p] && !mark
            rv.setTextViewText(T_N[i], ArtWidgets.NAMES[p])
            rv.setTextViewText(T_T[i], fmtHm(d.times[p]))
            rv.setViewVisibility(T_H[i], if (mark) View.VISIBLE else View.GONE)
            rv.setInt(T_H[i], "setColorFilter", th.accent)
            rv.setTextColor(T_N[i], if (mark) th.onAccent else if (dim) DIM else SOFT)
            rv.setTextColor(T_T[i], if (mark) th.onAccent else if (dim) DIM else WHITE)
        }
        return rv
    }
}

/** Layar pilih tema. Dipanggil saat widget ditambahkan atau dikonfigurasi ulang. */
class WidgetThemeActivity : Activity() {
    private var wid = AppWidgetManager.INVALID_APPWIDGET_ID

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        wid = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
        setResult(RESULT_CANCELED, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, wid))
        if (wid == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish()
            return
        }
        val cur = WidgetThemes.get(this, wid)
        val dens = resources.displayMetrics.density

        val root = vbox()
        root.setBackgroundColor(C.BG)
        root.addView(topBar("Pilih tema widget") { finish() })
        val scroll = ScrollView(this)
        val col = vbox(16)
        for (i in ThemeArt.themes.indices) {
            val th = ThemeArt.themes[i]
            val card = vbox(10).apply {
                background = roundBg(C.CARD, 20, if (i == cur) C.GOLD else C.LINE, if (i == cur) 2 else 1)
                isClickable = true
                setOnClickListener { pick(i) }
            }
            val iv = ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setImageBitmap(ThemeArt.preview(i, 560, 240, dens.coerceAtLeast(2f)))
            }
            card.addView(iv, LinearLayout.LayoutParams(MATCH, dp(130)))
            val row = hbox()
            row.addView(label("${i + 1}. ${th.name}", 15f, C.TEXT, true), LinearLayout.LayoutParams(0, WRAP, 1f))
            if (i == cur) row.addView(label("Dipakai", 12f, C.GOLD, true))
            card.put(row, 8)
            col.put(card, if (i == 0) 0 else 12)
        }
        scroll.addView(col)
        root.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))
        setContentView(root)
    }

    private fun pick(i: Int) {
        WidgetThemes.set(this, wid, i)
        setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, wid))
        Scheduler.refresh(this)
        finish()
    }
}
