package id.annur.jws.widget

import android.animation.ObjectAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings as AndroidSettings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Chronometer
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * Lapisan "kaca" di atas layar utama. Ini BUKAN layar kunci sistem dan tidak mengamankan HP.
 * Layar kunci sistem tidak bisa dibuat tembus oleh aplikasi mana pun, jadi lapisan ini digambar sendiri
 * dengan izin "Tampil di atas aplikasi lain". Paling pas dipakai bila kunci layar sistem diatur ke "Tidak ada".
 */
object GlassOverlay {
    private var view: View? = null
    private var wm: WindowManager? = null
    private val handler = Handler(Looper.getMainLooper())
    private var autoHide: Runnable? = null
    private val DATE = DateTimeFormatter.ofPattern("EEEE, d MMMM", Locale.forLanguageTag("id-ID"))
    private val SHOWN = intArrayOf(0, 2, 3, 4, 5)

    fun canDraw(ctx: Context): Boolean = AndroidSettings.canDrawOverlays(ctx)

    fun isShowing(): Boolean = view != null

    /** Menampilkan lapisan. [previewSec] > 0 memaksa hilang sendiri, dipakai untuk tombol Coba. */
    fun show(ctx: Context, s: Settings, previewSec: Int = 0) {
        val app = ctx.applicationContext
        if (!canDraw(app)) return
        hide()
        val manager = app.getSystemService(WindowManager::class.java) ?: return
        val touchable = s.glassMode == 0
        val root = build(app, s, touchable)

        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!touchable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP
        if (s.glassBlur && Build.VERSION.SDK_INT >= 31) {
            lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
            lp.blurBehindRadius = 40
        }
        val ok = runCatching { manager.addView(root, lp) }.isSuccess
        if (!ok) return
        wm = manager
        view = root
        root.alpha = 0f
        root.animate().alpha(1f).setDuration(240L).start()

        val sec = if (previewSec > 0) previewSec else if (s.glassMode == 1) s.glassSec else 0
        if (sec > 0) {
            val r = Runnable { closeAnimated() }
            autoHide = r
            handler.postDelayed(r, sec * 1000L)
        }
    }

    fun hide() {
        autoHide?.let { handler.removeCallbacks(it) }
        autoHide = null
        val v = view ?: return
        view = null
        runCatching { wm?.removeView(v) }
    }

    private fun closeAnimated() {
        val v = view ?: return
        v.animate().translationY(-v.height.toFloat() * 0.4f).alpha(0f).setDuration(220L)
            .withEndAction { hide() }.start()
    }

    private fun shadow(t: TextView): TextView {
        t.setShadowLayer(8f, 0f, 2f, 0xAA000000.toInt())
        return t
    }

    private fun build(ctx: Context, s: Settings, touchable: Boolean): View {
        val th = Themes.get(s.theme)
        val now = ZonedDateTime.now(s.zone())
        val t = TodayCalc.load(s, now)
        val hj = Hijri.today(s, now)

        val root = FrameLayout(ctx)
        root.setBackgroundColor(Color.argb(s.glassDim.coerceIn(0, 90) * 255 / 100, 0, 0, 0))

        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(ctx.dp(20), ctx.dp(52), ctx.dp(20), 0)
        }

        col.addView(TextClock(ctx).apply {
            format24Hour = "HH:mm"
            format12Hour = "hh:mm"
            textSize = 70f
            typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL)
            setTextColor(Color.WHITE)
            setShadowLayer(10f, 0f, 2f, 0xAA000000.toInt())
        })
        col.addView(shadow(ctx.label(DATE.format(now), 16f, Color.WHITE)))
        col.addView(shadow(ctx.label(hj.toString(), 14f, th.accent, true)))
        if (s.autoLoc && s.placeName.isNotEmpty()) {
            col.addView(shadow(ctx.label(s.placeName, 12f, 0xCCFFFFFF.toInt())))
        }

        val chrono = Chronometer(ctx).apply {
            setCountDown(true)
            base = SystemClock.elapsedRealtime() + (t.nextMs - System.currentTimeMillis())
            format = "Menuju ${t.nextName}  %s"
            setTextColor(th.accent)
            textSize = 13f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            background = ctx.roundBg(0x66000000, 16)
            setPadding(ctx.dp(14), ctx.dp(6), ctx.dp(14), ctx.dp(6))
            start()
        }
        col.addView(chrono, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = ctx.dp(10) })

        val row = ctx.hbox().apply {
            background = ctx.roundBg(0x66000000, 18)
            setPadding(ctx.dp(8), ctx.dp(8), ctx.dp(8), ctx.dp(8))
        }
        for (idx in SHOWN) {
            val mark = idx == t.nextIdx
            val c = ctx.vbox().apply { gravity = Gravity.CENTER_HORIZONTAL }
            c.addView(ctx.label(TodayCalc.NAMES[idx], 10f, if (mark) th.accent else 0xBBFFFFFF.toInt()))
            c.addView(ctx.label(t.times[idx], 14f, if (mark) th.accent else Color.WHITE, true))
            row.addView(c, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        col.addView(row, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = ctx.dp(12) })
        root.addView(col, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP))

        val mq = Marquee.build(ctx, s, now)
        if (mq.isNotEmpty()) {
            val mv = shadow(ctx.label(mq, 13f, Color.WHITE)).apply {
                setSingleLine(true)
                ellipsize = android.text.TextUtils.TruncateAt.MARQUEE
                marqueeRepeatLimit = -1
                isSelected = true
                gravity = Gravity.CENTER
            }
            root.addView(mv, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM).apply {
                setMargins(ctx.dp(20), 0, ctx.dp(20), ctx.dp(84))
            })
        }

        if (touchable) {
            val hint = shadow(ctx.label("⌃  Geser ke atas untuk membuka", 13f, 0xDDFFFFFF.toInt()))
            hint.gravity = Gravity.CENTER
            root.addView(hint, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM).apply {
                bottomMargin = ctx.dp(40)
            })
            ObjectAnimator.ofFloat(hint, View.ALPHA, 0.35f, 1f).apply {
                duration = 1100L
                repeatCount = ObjectAnimator.INFINITE
                repeatMode = ObjectAnimator.REVERSE
                start()
            }

            var downY = 0f
            root.setOnTouchListener { v, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        downY = e.rawY
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dy = minOf(0f, e.rawY - downY)
                        v.translationY = dy
                        v.alpha = 1f - minOf(1f, -dy / (v.height * 0.7f).coerceAtLeast(1f))
                        true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        val dy = e.rawY - downY
                        if (-dy > v.height * 0.18f) closeAnimated()
                        else v.animate().translationY(0f).alpha(1f).setDuration(180L).start()
                        true
                    }
                    else -> false
                }
            }
        }
        return root
    }
}

/** Layanan latar depan yang mendengarkan layar menyala dan mati, lalu menampilkan atau menyembunyikan lapisan kaca. */
class GlassLockService : Service() {
    private val rx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                Intent.ACTION_SCREEN_ON -> {
                    val s = AppPrefs.load(c)
                    if (s.enabled && s.glassLock && !EventAlarm.active) GlassOverlay.show(c, s)
                }
                Intent.ACTION_SCREEN_OFF -> GlassOverlay.hide()
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("glass", "Layar kunci transparan", NotificationManager.IMPORTANCE_LOW).apply {
                setShowBadge(false)
                lockscreenVisibility = Notification.VISIBILITY_SECRET
            }
        )
        val open = PendingIntent.getActivity(
            this, 6, Intent(this, ConfigActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "glass")
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Layar kunci transparan aktif")
            .setContentText("Ketuk untuk mengatur atau mematikan")
            .setOngoing(true)
            .setVisibility(Notification.VISIBILITY_SECRET)
            .setContentIntent(open)
            .build()
        startForeground(77, n)

        val f = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(rx, f, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(rx, f)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        running = false
        runCatching { unregisterReceiver(rx) }
        GlassOverlay.hide()
        super.onDestroy()
    }

    companion object {
        @Volatile
        var running = false
    }
}

object GlassLock {
    /** Menjalankan atau menghentikan layanan sesuai pengaturan dan izin. */
    fun ensure(ctx: Context, s: Settings) {
        val want = s.enabled && s.glassLock && GlassOverlay.canDraw(ctx)
        val i = Intent(ctx, GlassLockService::class.java)
        if (want) {
            if (!GlassLockService.running) runCatching { ctx.startForegroundService(i) }
        } else {
            ctx.stopService(i)
            GlassOverlay.hide()
        }
    }
}
