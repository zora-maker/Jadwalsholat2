package id.annur.jws.widget

import android.Manifest
import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings as AndroidSettings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

private val METHOD_LABELS = listOf(
    "Kemenag RI (Subuh 20°, Isya 18°)",
    "Muhammadiyah (Subuh 18°, Isya 18°)",
    "Liga Muslim Dunia (Subuh 18°, Isya 17°)",
    "ISNA (Subuh 15°, Isya 15°)"
)

// Lama tampilan fokus saat waktu sholat tiba, dalam menit. 0 = nonaktif.
private val ALERT_MINUTES = listOf(0, 1, 2, 3, 5, 10)
private val ALERT_LABELS = listOf("Nonaktif", "1 menit", "2 menit", "3 menit", "5 menit", "10 menit")
private val HIJRI_LABELS = listOf("Mundur 2 hari", "Mundur 1 hari", "Sesuai kalender", "Maju 1 hari", "Maju 2 hari")

private const val REQ_NOTIF = 77
private const val REQ_LOC = 80
private val ALARM_SEC = listOf(15, 30, 60, 120)
private val ALARM_SEC_LABELS = listOf("15 detik", "30 detik", "1 menit", "2 menit")

/**
 * Pengaturan. Dibuka dari halaman utama, dari ketuk widget, atau saat widget ditambahkan.
 * Dibagi per bagian: masjid, perhitungan, Hijriyah, widget, notifikasi, layar kunci.
 */
class ConfigActivity : Activity() {

    private lateinit var base: Settings
    private var widgetTheme = 0
    private var lockTheme = 0
    private var lockStyle = 0
    private var popupStyle = 0
    private var popupAnim = 0

    private lateinit var etName: android.widget.EditText
    private lateinit var etLat: android.widget.EditText
    private lateinit var etLon: android.widget.EditText
    private lateinit var etTz: android.widget.EditText
    private lateinit var spCity: Spinner
    private lateinit var spMethod: Spinner
    private lateinit var spAsr: Spinner
    private lateinit var spHijri: Spinner
    private lateinit var spAlert: Spinner
    private lateinit var swMaghrib: Switch
    private lateinit var swAuto: Switch
    private lateinit var swEnabled: Switch
    private lateinit var swEvAlarm: Switch
    private lateinit var swEvVib: Switch
    private lateinit var swEvPopup: Switch
    private lateinit var spAlarmSec: Spinner
    private lateinit var swMarq: Switch
    private lateinit var swMarqEv: Switch
    private lateinit var etMarq: android.widget.EditText
    private lateinit var swVibrate: Switch
    private lateinit var swNotif: Switch
    private lateinit var swLock: Switch
    private lateinit var ivPreview: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val s = AppPrefs.load(this)
        base = s
        widgetTheme = s.theme.coerceIn(0, Themes.list.size - 1)
        lockTheme = s.lockTheme.coerceIn(0, LockStyles.palettes.size - 1)
        lockStyle = s.lockStyle.coerceIn(0, LockStyles.styleNames.size - 1)
        popupStyle = s.popupStyle.coerceIn(0, PopupFx.styleNames.size - 1)
        popupAnim = s.popupAnim.coerceIn(0, PopupFx.animNames.size - 1)

        val root = vbox()
        root.setBackgroundColor(C.BG)
        root.addView(topBar("Pengaturan") { finish() })

        val scroll = ScrollView(this)
        val col = vbox(16)

        // ---- Status aplikasi
        val sPower = section(col, "Status aplikasi", "Matikan untuk menghentikan alarm, getar, notifikasi, dan pembaruan otomatis. Widget tetap tampil.")
        swEnabled = sw("Aplikasi aktif", s.enabled)
        sPower.put(swEnabled, 10)

        // ---- Masjid dan lokasi
        val sMasjid = section(col, "Masjid dan lokasi", "Nama tampil di widget, notifikasi, dan layar kunci")
        etName = field("Nama masjid", s.name)
        sMasjid.put(etName, 10)
        swAuto = sw("Lokasi otomatis (GPS dan internet)", s.autoLoc)
        sMasjid.put(swAuto, 12)
        sMasjid.put(label("Koordinat dan nama tempat diperbarui saat aplikasi dibuka bila Anda pindah lebih dari 1,5 km. Hasilnya tersimpan, jadi jadwal tetap jalan tanpa internet.", 11f, C.MUTED), 4)
        caption(sMasjid, "Kota (untuk lokasi manual)")
        spCity = Spinner(this)
        val cityNames = Cities.all.map { it.name } + "Kustom"
        spCity.adapter = adapterOf(cityNames)
        sMasjid.put(spCity, 2)
        val coord = hbox()
        etLat = numField("Lintang", s.lat.toString())
        etLon = numField("Bujur", s.lon.toString())
        etTz = numField("UTC", s.tz.toString())
        coord.addView(etLat, LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = dp(6) })
        coord.addView(etLon, LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = dp(6) })
        coord.addView(etTz, LinearLayout.LayoutParams(0, WRAP, 0.7f))
        sMasjid.put(coord, 8)
        val idx = Cities.all.indexOfFirst { sameSpot(it, s.lat, s.lon) }
        spCity.setSelection(if (idx >= 0) idx else cityNames.lastIndex)
        spCity.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (pos >= Cities.all.size) return // "Kustom": biarkan isian apa adanya
                val c = Cities.all[pos]
                etLat.setText(c.lat.toString())
                etLon.setText(c.lon.toString())
                etTz.setText(c.tz.toString())
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        // ---- Perhitungan
        val sCalc = section(col, "Perhitungan waktu sholat")
        caption(sCalc, "Metode", 10)
        spMethod = Spinner(this)
        spMethod.adapter = adapterOf(METHOD_LABELS)
        spMethod.setSelection(METHODS.keys.toList().indexOf(s.method).coerceAtLeast(0))
        sCalc.put(spMethod, 2)
        caption(sCalc, "Mazhab untuk Asar")
        spAsr = Spinner(this)
        spAsr.adapter = adapterOf(listOf("Syafi'i, Maliki, Hanbali", "Hanafi"))
        spAsr.setSelection(if (s.asr == 2) 1 else 0)
        sCalc.put(spAsr, 2)

        // ---- Hijriyah
        val sHijri = section(col, "Tanggal Hijriyah", "Memakai kalender Umm al-Qura, bisa berbeda sehari dari Kemenag")
        caption(sHijri, "Koreksi tanggal", 10)
        spHijri = Spinner(this)
        spHijri.adapter = adapterOf(HIJRI_LABELS)
        spHijri.setSelection((s.hijriOffset + 2).coerceIn(0, 4))
        sHijri.put(spHijri, 2)
        swMaghrib = sw("Ganti tanggal saat Maghrib", s.hijriMaghrib)
        sHijri.put(swMaghrib, 10)

        // ---- Widget
        val sWidget = section(col, "Widget layar utama")
        caption(sWidget, "Tema warna", 10)
        val wName = label("", 13f, C.TEXT, true)
        sWidget.put(swatches(
            Themes.list.map { intArrayOf(it.arc[0], it.arc[1], it.arc[2]) },
            widgetTheme, wName, Themes.list.map { it.name }
        ) { widgetTheme = it }, 4)
        sWidget.put(wName, 0)
        swMarq = sw("Teks berjalan", s.marquee)
        sWidget.put(swMarq, 14)
        etMarq = field("Tulis teks yang ingin berjalan di widget", s.marqueeText).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            minLines = 2
        }
        sWidget.put(etMarq, 8)
        swMarqEv = sw("Sertakan kegiatan hari ini dan hari besar", s.marqueeEvents)
        sWidget.put(swMarqEv, 8)
        sWidget.put(label("Teks berjalan tampil di baris bawah widget. Beberapa peluncur (launcher) tidak menjalankan animasinya, dan teks hanya tampil diam.", 11f, C.MUTED), 6)

        // ---- Notifikasi dan alarm
        val sNotif = section(col, "Notifikasi dan alarm")
        swNotif = sw("Notifikasi tetap dengan hitung mundur", s.notif)
        sNotif.put(swNotif, 10)
        caption(sNotif, "Tampilan fokus saat waktu sholat tiba")
        spAlert = Spinner(this)
        spAlert.adapter = adapterOf(ALERT_LABELS)
        spAlert.setSelection(ALERT_MINUTES.indexOf(s.alertMin).coerceAtLeast(0))
        sNotif.put(spAlert, 2)
        swVibrate = sw("Getar 5 detik saat waktu sholat tiba", s.vibrate)
        sNotif.put(swVibrate, 10)
        val bat = pill("Izinkan berjalan di latar belakang", false, 13f).apply {
            setOnClickListener {
                startActivity(
                    Intent(AndroidSettings.ACTION_APPLICATION_DETAILS_SETTINGS)
                        .setData(Uri.fromParts("package", packageName, null))
                )
            }
        }
        sNotif.put(bat, 12, WRAP)
        sNotif.put(label("Di HP Xiaomi atau Redmi, atur Hemat Baterai ke Tanpa batasan agar alarm tidak dimatikan sistem.", 11f, C.MUTED), 6)

        // ---- Kegiatan, alarm, dan pop up
        val sEv = section(col, "Kegiatan, alarm, dan pop up", "Berlaku untuk pengingat kegiatan di kalender")
        swEvAlarm = sw("Bunyi alarm saat pengingat tiba", s.evAlarm)
        sEv.put(swEvAlarm, 10)
        swEvVib = sw("Getar berulang", s.evVibrate)
        sEv.put(swEvVib, 8)
        caption(sEv, "Lama bunyi dan getar", 12)
        spAlarmSec = Spinner(this)
        spAlarmSec.adapter = adapterOf(ALARM_SEC_LABELS)
        spAlarmSec.setSelection(ALARM_SEC.indexOf(s.alarmSec).let { if (it < 0) 1 else it })
        sEv.put(spAlarmSec, 2)
        swEvPopup = sw("Tampilkan pop up catatan kegiatan", s.evPopup)
        sEv.put(swEvPopup, 12)
        caption(sEv, "Bentuk pop up (3 pilihan)", 12)
        sEv.put(chips(PopupFx.styleNames, popupStyle) { popupStyle = it }, 6)
        caption(sEv, "Animasi pop up (6 pilihan)", 12)
        sEv.put(chips(PopupFx.animNames, popupAnim) { popupAnim = it }, 6)
        val tests = hbox()
        tests.addView(pill("Coba pop up", true).apply { setOnClickListener { testPopup() } })
        tests.addView(pill("Coba alarm", false).apply { setOnClickListener { testAlarm() } },
            LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = dp(8) })
        sEv.put(tests, 14)
        sEv.put(label("Saat layar mati atau terkunci, pop up muncul sendiri di atas layar kunci. Saat HP sedang dipakai, muncul spanduk notifikasi dengan tombol Tunda dan Selesai.", 11f, C.MUTED), 8)

        // ---- Layar kunci
        val sLock = section(col, "Layar kunci", "Wallpaper berisi jadwal hari ini, cocok untuk Android 12")
        swLock = sw("Pasang jadwal sebagai wallpaper layar kunci", s.lockWp)
        sLock.put(swLock, 10)
        caption(sLock, "Gaya tata letak (8 pilihan)", 14)
        ivPreview = ImageView(this).apply {
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "Pratinjau wallpaper layar kunci"
        }
        sLock.put(chips(LockStyles.styleNames, lockStyle) {
            lockStyle = it
            updatePreview()
        }, 6)
        caption(sLock, "Warna (20 pilihan)", 14)
        val lName = label("", 13f, C.TEXT, true)
        sLock.put(swatches(
            LockStyles.palettes.map { intArrayOf(it.bg[0], it.bg[1], it.accent) },
            lockTheme, lName, LockStyles.palettes.map { it.name }
        ) {
            lockTheme = it
            updatePreview()
        }, 4)
        sLock.put(lName, 0)
        caption(sLock, "Pratinjau", 14)
        sLock.put(ivPreview, 8, WRAP, dp(380)).also {
            (it.layoutParams as LinearLayout.LayoutParams).gravity = Gravity.CENTER_HORIZONTAL
        }

        col.put(View(this), 0, MATCH, dp(12))
        scroll.addView(col)
        root.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))

        // Tombol simpan selalu terlihat di bawah
        val bar = hbox().apply {
            setBackgroundColor(C.CARD)
            setPadding(dp(16), dp(10), dp(16), dp(10))
        }
        bar.addView(label("Simpan pengaturan", 15f, Color.parseColor("#1A1405"), true).apply {
            gravity = Gravity.CENTER
            background = roundBg(C.GOLD, 26)
            setPadding(dp(16), dp(14), dp(16), dp(14))
            isClickable = true
            setOnClickListener { save() }
        }, LinearLayout.LayoutParams(MATCH, WRAP))
        root.addView(bar)

        setContentView(root)
        updatePreview()
    }

    // ------------------------------------------------------------ komponen tampilan

    private fun section(parent: LinearLayout, title: String, sub: String? = null): LinearLayout {
        val c = card()
        c.addView(label(title, 16f, C.GOLD, true))
        if (sub != null) c.put(label(sub, 12f, C.MUTED), 2)
        parent.put(c, 14)
        return c
    }

    private fun caption(parent: LinearLayout, text: String, top: Int = 12) {
        parent.put(label(text, 12f, C.MUTED), top)
    }

    private fun sw(text: String, on: Boolean): Switch = Switch(this).apply {
        this.text = text
        setTextColor(C.TEXT)
        textSize = 14f
        isChecked = on
    }

    private fun numField(hint: String, value: String): android.widget.EditText = field(hint, value).apply {
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or
            InputType.TYPE_NUMBER_FLAG_SIGNED
    }

    private fun adapterOf(items: List<String>) =
        ArrayAdapter(this, android.R.layout.simple_spinner_item, items).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }

    private fun circle(cols: IntArray, sel: Boolean) =
        GradientDrawable(GradientDrawable.Orientation.TL_BR, cols).apply {
            shape = GradientDrawable.OVAL
            setStroke(dp(if (sel) 3 else 1), if (sel) C.GOLD else 0x55FFFFFF)
        }

    /** Deretan lingkaran warna yang bisa digeser. Nama pilihan tampil di [label]. */
    private fun swatches(
        items: List<IntArray>, initial: Int, label: TextView, names: List<String>, onPick: (Int) -> Unit
    ): View {
        val hs = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(2), dp(8), dp(2), dp(6))
        }
        val views = mutableListOf<View>()
        fun paint(sel: Int) {
            for ((i, v) in views.withIndex()) v.background = circle(items[i], i == sel)
            label.text = names[sel]
        }
        for (i in items.indices) {
            val v = View(this)
            v.setOnClickListener {
                paint(i)
                onPick(i)
            }
            row.addView(v, LinearLayout.LayoutParams(dp(44), dp(44)).apply { rightMargin = dp(10) })
            views += v
        }
        paint(initial)
        hs.addView(row)
        return hs
    }

    /** Deretan pil pilihan tunggal yang bisa digeser. */
    private fun chips(names: List<String>, initial: Int, onPick: (Int) -> Unit): View {
        val hs = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val views = mutableListOf<TextView>()
        for ((i, n) in names.withIndex()) {
            val p = pill(n, i == initial)
            p.setOnClickListener {
                for ((j, v) in views.withIndex()) v.styleAsPill(j == i)
                onPick(i)
            }
            row.addView(p, LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = dp(8) })
            views += p
        }
        hs.addView(row)
        return hs
    }

    /** Pratinjau wallpaper layar kunci sesuai pilihan gaya dan warna saat ini. */
    private fun updatePreview() {
        val st = base.copy(
            name = etName.text.toString().trim().ifEmpty { "Masjid An-Nur" }.take(40),
            lockStyle = lockStyle,
            lockTheme = lockTheme,
            hijriOffset = spHijri.selectedItemPosition - 2,
            hijriMaghrib = swMaghrib.isChecked
        )
        runCatching { ivPreview.setImageBitmap(LockWallpaper.render(st, 360, 800)) }
    }

    private val demoTitle = "Kajian rutin Ahad pagi"
    private val demoNote = "Contoh catatan kegiatan: bawa buku catatan, kajian ba'da Subuh bersama Ustadz Ahmad di masjid."

    private fun demoWhen(): String =
        "08:00 • " + Hijri.both(java.time.LocalDate.now(), spHijri.selectedItemPosition - 2)

    private fun testPopup() {
        startActivity(
            Intent(this, EventPopupActivity::class.java)
                .putExtra("demo", true).putExtra("style", popupStyle).putExtra("anim", popupAnim)
                .putExtra("title", demoTitle).putExtra("note", demoNote).putExtra("when", demoWhen())
                .putExtra("id", -1L)
        )
    }

    private fun testAlarm() {
        val i = EventAlarm.put(
            Intent(this, EventAlarmService::class.java).setAction(EventAlarm.ACTION_RING),
            -1L, demoTitle, demoNote, demoWhen()
        )
            .putExtra("t_sound", swEvAlarm.isChecked)
            .putExtra("t_vib", swEvVib.isChecked)
            .putExtra("t_sec", 8)
        runCatching { startForegroundService(i) }
        Toast.makeText(this, "Alarm uji 8 detik", Toast.LENGTH_SHORT).show()
    }

    private fun sameSpot(c: City, lat: Double, lon: Double) =
        abs(c.lat - lat) < 1e-4 && abs(c.lon - lon) < 1e-4

    // ------------------------------------------------------------ simpan

    private fun save() {
        val lat = etLat.text.toString().toDoubleOrNull()
        val lon = etLon.text.toString().toDoubleOrNull()
        val tz = etTz.text.toString().toDoubleOrNull()
        if (lat == null || lon == null || tz == null ||
            lat !in -90.0..90.0 || lon !in -180.0..180.0 || tz !in -12.0..14.0
        ) {
            Toast.makeText(this, "Periksa lintang, bujur, dan UTC", Toast.LENGTH_LONG).show()
            return
        }

        val method = METHODS.keys.toList()[spMethod.selectedItemPosition]
        AppPrefs.save(
            this,
            Settings(
                name = etName.text.toString().trim().ifEmpty { "Masjid An-Nur" }.take(40),
                lat = lat,
                lon = lon,
                tz = tz,
                method = method,
                asr = if (spAsr.selectedItemPosition == 1) 2 else 1,
                notif = swNotif.isChecked,
                lockWp = swLock.isChecked,
                theme = widgetTheme,
                alertMin = ALERT_MINUTES[spAlert.selectedItemPosition],
                vibrate = swVibrate.isChecked,
                lockTheme = lockTheme,
                lockStyle = lockStyle,
                marquee = swMarq.isChecked,
                marqueeText = etMarq.text.toString().trim().take(250),
                marqueeEvents = swMarqEv.isChecked,
                hijriOffset = spHijri.selectedItemPosition - 2,
                hijriMaghrib = swMaghrib.isChecked,
                autoLoc = swAuto.isChecked,
                placeName = if (swAuto.isChecked) AppPrefs.load(this).placeName else "",
                locUpdated = AppPrefs.load(this).locUpdated,
                enabled = swEnabled.isChecked,
                evAlarm = swEvAlarm.isChecked,
                evVibrate = swEvVib.isChecked,
                evPopup = swEvPopup.isChecked,
                alarmSec = ALARM_SEC[spAlarmSec.selectedItemPosition.coerceIn(0, ALARM_SEC.size - 1)],
                popupStyle = popupStyle,
                popupAnim = popupAnim
            )
        )
        if (!swEnabled.isChecked) EventAlarm.stopAll(this)
        LockWallpaper.invalidate(this)
        if (swEnabled.isChecked && swAuto.isChecked && LocationSync.hasPermission(this)) LocationSync.sync(this, true) {}

        // Jika dibuka sebagai layar konfigurasi widget, kembalikan id-nya agar widget ditambahkan
        val wid = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
        if (wid != AppWidgetManager.INVALID_APPWIDGET_ID) {
            setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, wid))
        }

        Scheduler.refresh(this, withWallpaper = true)
        afterSave()
    }

    private fun afterSave() {
        if (swAuto.isChecked && !LocationSync.hasPermission(this)) {
            requestPermissions(LocationSync.PERMS, REQ_LOC)
            return
        }
        // Android 13 ke atas: notifikasi butuh izin dari pengguna
        if (swNotif.isChecked && Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
            return
        }

        Toast.makeText(this, "Pengaturan disimpan", Toast.LENGTH_SHORT).show()
        finish()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (code == REQ_LOC) {
            if (results.any { it == PackageManager.PERMISSION_GRANTED }) {
                LocationSync.sync(this, true) {}
            } else {
                Toast.makeText(this, "Izin lokasi ditolak, memakai lokasi manual", Toast.LENGTH_LONG).show()
            }
            afterSave()
            return
        }
        if (code != REQ_NOTIF) return
        val ok = results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED
        if (ok) Scheduler.refresh(this)
        Toast.makeText(
            this,
            if (ok) "Pengaturan disimpan" else "Izin notifikasi ditolak, notifikasi tidak akan tampil",
            Toast.LENGTH_LONG
        ).show()
        finish()
    }
}
