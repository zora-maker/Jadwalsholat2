package id.annur.jws.widget

import android.Manifest
import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings as AndroidSettings
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

private val METHOD_LABELS = listOf(
    "Kemenag RI (Subuh 20°, Isya 18°)",
    "Muhammadiyah (Subuh 18°, Isya 18°)",
    "Liga Muslim Dunia (Subuh 18°, Isya 17°)",
    "ISNA (Subuh 15°, Isya 15°)"
)

// Lama tampilan fokus saat waktu sholat tiba, dalam menit. 0 = nonaktif.
private val ALERT_MINUTES = listOf(0, 1, 2, 3, 5, 10)
private val ALERT_LABELS = listOf("Nonaktif", "1 menit", "2 menit", "3 menit", "5 menit", "10 menit")

private const val REQ_NOTIF = 77

/** Pengaturan masjid. Dibuka dari ikon aplikasi, dari ketuk widget atau notifikasi, atau saat widget ditambahkan. */
class ConfigActivity : Activity() {

    private lateinit var etName: EditText
    private lateinit var etLat: EditText
    private lateinit var etLon: EditText
    private lateinit var etTz: EditText
    private lateinit var spCity: Spinner
    private lateinit var spMethod: Spinner
    private lateinit var spAsr: Spinner
    private lateinit var spTheme: Spinner
    private lateinit var spAlert: Spinner
    private lateinit var cbVibrate: CheckBox
    private lateinit var cbNotif: CheckBox
    private lateinit var cbLock: CheckBox
    private lateinit var spLockStyle: Spinner
    private lateinit var spLockColor: Spinner
    private lateinit var ivPreview: ImageView
    private lateinit var loaded: Settings

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_config)

        etName = findViewById(R.id.etName)
        etLat = findViewById(R.id.etLat)
        etLon = findViewById(R.id.etLon)
        etTz = findViewById(R.id.etTz)
        spCity = findViewById(R.id.spCity)
        spMethod = findViewById(R.id.spMethod)
        spAsr = findViewById(R.id.spAsr)
        spTheme = findViewById(R.id.spTheme)
        spAlert = findViewById(R.id.spAlert)
        cbVibrate = findViewById(R.id.cbVibrate)
        cbNotif = findViewById(R.id.cbNotif)
        cbLock = findViewById(R.id.cbLock)
        spLockStyle = findViewById(R.id.spLockStyle)
        spLockColor = findViewById(R.id.spLockColor)
        ivPreview = findViewById(R.id.ivPreview)

        val s = AppPrefs.load(this)
        loaded = s
        etName.setText(s.name)
        etLat.setText(s.lat.toString())
        etLon.setText(s.lon.toString())
        etTz.setText(s.tz.toString())
        cbNotif.isChecked = s.notif
        cbLock.isChecked = s.lockWp
        cbVibrate.isChecked = s.vibrate

        val methodKeys = METHODS.keys.toList()
        spMethod.adapter = adapterOf(METHOD_LABELS)
        spMethod.setSelection(methodKeys.indexOf(s.method).coerceAtLeast(0))

        spAsr.adapter = adapterOf(listOf("Syafi'i, Maliki, Hanbali", "Hanafi"))
        spAsr.setSelection(if (s.asr == 2) 1 else 0)

        spTheme.adapter = adapterOf(Themes.list.map { it.name })
        spTheme.setSelection(s.theme.coerceIn(0, Themes.list.size - 1))

        spAlert.adapter = adapterOf(ALERT_LABELS)
        spAlert.setSelection(ALERT_MINUTES.indexOf(s.alertMin).coerceAtLeast(0))

        spLockStyle.adapter = adapterOf(LockStyles.styleNames)
        spLockStyle.setSelection(s.lockStyle.coerceIn(0, LockStyles.styleNames.size - 1))
        spLockColor.adapter = PaletteAdapter()
        spLockColor.setSelection(s.lockTheme.coerceIn(0, LockStyles.palettes.size - 1))
        val previewListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) = updatePreview()
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        spLockStyle.onItemSelectedListener = previewListener
        spLockColor.onItemSelectedListener = previewListener
        updatePreview()

        val cityNames = Cities.all.map { it.name } + "Kustom"
        spCity.adapter = adapterOf(cityNames)
        val idx = Cities.all.indexOfFirst { sameSpot(it, s.lat, s.lon) }
        spCity.setSelection(if (idx >= 0) idx else cityNames.lastIndex)
        spCity.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (pos >= Cities.all.size) return // "Kustom": biarkan isian apa adanya
                val c = Cities.all[pos]
                etLat.setText(c.lat.toString())
                etLon.setText(c.lon.toString())
                etTz.setText(c.tz.toString())
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        findViewById<Button>(R.id.btnSave).setOnClickListener { save() }

        // Di HP Xiaomi/Redmi dan sejenisnya, sistem bisa mematikan aplikasi di latar belakang
        findViewById<Button>(R.id.btnBattery).setOnClickListener {
            startActivity(
                Intent(AndroidSettings.ACTION_APPLICATION_DETAILS_SETTINGS)
                    .setData(Uri.fromParts("package", packageName, null))
            )
        }
    }

    /** Pratinjau wallpaper layar kunci sesuai pilihan gaya dan warna saat ini. */
    private fun updatePreview() {
        val st = loaded.copy(
            name = etName.text.toString().trim().ifEmpty { "Masjid An-Nur" }.take(40),
            lockStyle = spLockStyle.selectedItemPosition.coerceAtLeast(0),
            lockTheme = spLockColor.selectedItemPosition.coerceAtLeast(0)
        )
        runCatching { ivPreview.setImageBitmap(LockWallpaper.render(st, 360, 800)) }
    }

    /** Daftar warna dengan kotak contoh di sebelah nama. */
    private inner class PaletteAdapter : BaseAdapter() {
        override fun getCount() = LockStyles.palettes.size
        override fun getItem(position: Int): Any = LockStyles.palettes[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View = row(position)
        override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup?): View = row(position)

        private fun row(i: Int): View {
            val pal = LockStyles.palettes[i]
            val d = resources.displayMetrics.density
            val box = LinearLayout(this@ConfigActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding((12 * d).toInt(), (10 * d).toInt(), (12 * d).toInt(), (10 * d).toInt())
            }
            val sw = View(this@ConfigActivity).apply {
                background = GradientDrawable(
                    GradientDrawable.Orientation.TL_BR,
                    intArrayOf(pal.bg[0], pal.bg[1], pal.accent)
                ).apply {
                    cornerRadius = 8 * d
                    setStroke(maxOf(1, d.toInt()), 0x66FFFFFF)
                }
            }
            box.addView(sw, LinearLayout.LayoutParams((44 * d).toInt(), (28 * d).toInt()))
            val tv = TextView(this@ConfigActivity).apply {
                text = "${i + 1}. ${pal.name}"
                textSize = 16f
                setTextColor(Color.WHITE)
                setPadding((14 * d).toInt(), 0, 0, 0)
            }
            box.addView(tv)
            return box
        }
    }

    private fun adapterOf(items: List<String>) =
        ArrayAdapter(this, android.R.layout.simple_spinner_item, items).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }

    private fun sameSpot(c: City, lat: Double, lon: Double) =
        abs(c.lat - lat) < 1e-4 && abs(c.lon - lon) < 1e-4

    private fun save() {
        val lat = etLat.text.toString().toDoubleOrNull()
        val lon = etLon.text.toString().toDoubleOrNull()
        val tz = etTz.text.toString().toDoubleOrNull()
        if (lat == null || lon == null || tz == null ||
            lat !in -90.0..90.0 || lon !in -180.0..180.0 || tz !in -12.0..14.0
        ) {
            Toast.makeText(this, "Periksa lintang, bujur, dan UTC", Toast.LENGTH_LONG).show()
            return
        }

        val method = METHODS.keys.toList()[spMethod.selectedItemPosition]
        AppPrefs.save(
            this,
            Settings(
                name = etName.text.toString().trim().ifEmpty { "Masjid An-Nur" }.take(40),
                lat = lat,
                lon = lon,
                tz = tz,
                method = method,
                asr = if (spAsr.selectedItemPosition == 1) 2 else 1,
                notif = cbNotif.isChecked,
                lockWp = cbLock.isChecked,
                theme = spTheme.selectedItemPosition,
                alertMin = ALERT_MINUTES[spAlert.selectedItemPosition],
                vibrate = cbVibrate.isChecked,
                lockTheme = spLockColor.selectedItemPosition.coerceAtLeast(0),
                lockStyle = spLockStyle.selectedItemPosition.coerceAtLeast(0)
            )
        )

        // Jika dibuka sebagai layar konfigurasi widget, kembalikan id-nya agar widget ditambahkan
        val wid = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
        if (wid != AppWidgetManager.INVALID_APPWIDGET_ID) {
            setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, wid))
        }

        Scheduler.refresh(this, withWallpaper = true)

        // Android 13 ke atas: notifikasi butuh izin dari pengguna
        if (cbNotif.isChecked && Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
            return
        }

        Toast.makeText(this, "Pengaturan disimpan", Toast.LENGTH_SHORT).show()
        finish()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (code != REQ_NOTIF) return
        val ok = results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED
        if (ok) Scheduler.refresh(this)
        Toast.makeText(
            this,
            if (ok) "Pengaturan disimpan" else "Izin notifikasi ditolak, notifikasi tidak akan tampil",
            Toast.LENGTH_LONG
        ).show()
        finish()
    }
}
