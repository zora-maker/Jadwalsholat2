package id.annur.jws.widget

import android.animation.ValueAnimator
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView

/** Pilihan bentuk dan animasi pop up catatan kegiatan. */
object PopupFx {
    val styleNames = listOf("Kartu tengah", "Panel bawah", "Layar penuh")
    val animNames = listOf("Memudar", "Zoom", "Geser dari bawah", "Geser dari atas", "Pantul", "Putar")

    fun animateIn(v: View, anim: Int) {
        val parentH = ((v.parent as? View)?.height ?: v.height).toFloat()
        v.alpha = 0f
        val a = v.animate().alpha(1f).setDuration(380L).setInterpolator(DecelerateInterpolator())
        when (anim) {
            1 -> {
                v.scaleX = 0.7f
                v.scaleY = 0.7f
                a.scaleX(1f).scaleY(1f)
            }
            2 -> {
                v.translationY = parentH * 0.5f
                a.translationY(0f)
            }
            3 -> {
                v.translationY = -parentH * 0.5f
                a.translationY(0f)
            }
            4 -> {
                v.scaleX = 0.3f
                v.scaleY = 0.3f
                a.scaleX(1f).scaleY(1f).setDuration(600L).setInterpolator(OvershootInterpolator(1.8f))
            }
            5 -> {
                v.cameraDistance = 9000f * v.resources.displayMetrics.density
                v.rotationY = 90f
                a.rotationY(0f).setDuration(520L)
            }
        }
        a.start()
    }

    fun animateOut(v: View, anim: Int, end: () -> Unit) {
        val parentH = ((v.parent as? View)?.height ?: v.height).toFloat()
        val a = v.animate().alpha(0f).setDuration(220L).setInterpolator(DecelerateInterpolator())
        when (anim) {
            1, 4 -> a.scaleX(0.8f).scaleY(0.8f)
            2 -> a.translationY(parentH * 0.5f)
            3 -> a.translationY(-parentH * 0.5f)
            5 -> a.rotationY(-90f)
        }
        a.withEndAction { end() }.start()
    }
}

/**
 * Pop up catatan kegiatan. Tampil di atas layar kunci dan menyalakan layar.
 * Bentuk dan animasinya dipilih di Pengaturan.
 */
class EventPopupActivity : Activity() {
    private lateinit var card: View
    private var anim = 0
    private var demo = false
    private var closing = false

    private val closer = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) = close()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val s = AppPrefs.load(this)
        val style = intent.getIntExtra("style", s.popupStyle).coerceIn(0, PopupFx.styleNames.size - 1)
        anim = intent.getIntExtra("anim", s.popupAnim).coerceIn(0, PopupFx.animNames.size - 1)
        demo = intent.getBooleanExtra("demo", false)
        val title = intent.getStringExtra("title") ?: "Kegiatan"
        val note = intent.getStringExtra("note") ?: ""
        val whenText = intent.getStringExtra("when") ?: ""

        val root = FrameLayout(this)
        val content = content(title, whenText, note, style == 2)
        val dim = if (style == 2) {
            GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xFF1D4A5F.toInt(), 0xFF06121D.toInt()))
        } else {
            android.graphics.drawable.ColorDrawable(0xB3000000.toInt())
        }
        root.background = dim

        when (style) {
            0 -> {
                content.background = roundBg(C.CARD, 28, C.LINE)
                root.addView(content, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.CENTER).apply {
                    setMargins(dp(22), dp(22), dp(22), dp(22))
                })
            }
            1 -> {
                val r = dp(28).toFloat()
                content.background = GradientDrawable().apply {
                    setColor(C.CARD)
                    cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
                    setStroke(dp(1), C.LINE)
                }
                root.addView(content, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM))
            }
            else -> {
                root.addView(content, FrameLayout.LayoutParams(MATCH, MATCH))
            }
        }
        card = content
        setContentView(root)

        val filter = IntentFilter(EventAlarm.ACTION_CLOSED)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(closer, filter, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(closer, filter)

        root.post {
            PopupFx.animateIn(card, anim)
            ValueAnimator.ofInt(0, 255).apply {
                duration = 320L
                addUpdateListener { dim.alpha = it.animatedValue as Int }
                start()
            }
        }
    }

    private fun content(title: String, whenText: String, note: String, big: Boolean): LinearLayout {
        val box = vbox(if (big) 32 else 24)
        if (big) box.gravity = Gravity.CENTER_VERTICAL
        box.addView(label("PENGINGAT KEGIATAN", 11f, C.GOLD, true))
        box.put(label(title, if (big) 32f else 22f, C.TEXT, true), 8)
        if (whenText.isNotEmpty()) box.put(label(whenText, if (big) 15f else 13f, C.TEAL), 6)

        val noteText = if (note.isBlank()) "Tidak ada catatan." else note
        val noteView = label(noteText, if (big) 19f else 15f, if (note.isBlank()) C.MUTED else C.TEXT)
        noteView.setLineSpacing(0f, 1.15f)
        val sc = ScrollView(this)
        sc.addView(noteView)
        box.put(sc, 16, MATCH, WRAP)
        val lp = sc.layoutParams as LinearLayout.LayoutParams
        if (big) {
            lp.height = 0
            lp.weight = 1f
        } else if (note.length > 160) {
            lp.height = dp(200)
        }

        val row = hbox()
        row.addView(pill("Tunda ${EventAlarm.SNOOZE_MIN} menit", false, 15f).apply {
            setOnClickListener { act(true) }
        }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = dp(8) })
        row.addView(pill("Selesai", true, 15f).apply {
            setOnClickListener { act(false) }
        }, LinearLayout.LayoutParams(0, WRAP, 1f))
        box.put(row, 22)
        return box
    }

    private fun act(snooze: Boolean) {
        if (!demo) {
            val i = Intent(this, EventAlarmService::class.java)
                .setAction(if (snooze) EventAlarm.ACTION_SNOOZE else EventAlarm.ACTION_STOP)
            EventAlarm.copy(intent, i)
            runCatching { startService(i) }
        }
        close()
    }

    private fun close() {
        if (closing) return
        closing = true
        PopupFx.animateOut(card, anim) {
            finish()
            overridePendingTransition(0, 0)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() = act(false)

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        recreate()
    }

    override fun onDestroy() {
        runCatching { unregisterReceiver(closer) }
        super.onDestroy()
    }
}
