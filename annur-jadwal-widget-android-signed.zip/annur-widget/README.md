# Jadwal Sholat An-Nur (Android)

Aplikasi jadwal sholat dengan widget lengkung masjid, notifikasi lock screen, dan wallpaper
layar kunci. Perhitungan waktu dilakukan di perangkat (algoritma yang sama dengan versi web),
tanpa internet.

Dikembangkan oleh Ahmad Mu'adz.

## Fitur

- **Widget lengkung masjid**: jam berdetik, hitung mundur ke sholat berikutnya, dan enam waktu sholat.
- **10 tema warna**, termasuk Terang dan Transparan (jam tetap jelas berkat bayangan teks).
- **Tampilan fokus saat waktu sholat tiba**: widget menampilkan nama sholat besar, "Waktu sholat telah tiba",
  dan hitung maju. Lama tampilannya bisa diatur (1, 2, 3, 5, 10 menit, atau nonaktif).
- **Getar 5 detik** saat waktu sholat tiba (bisa dimatikan).
- **Notifikasi tetap** dengan hitung mundur di lock screen (Android 8 ke atas).
- **Wallpaper layar kunci** berisi jadwal hari ini (cocok untuk Android 12), dengan **8 gaya tata letak**
  (Klasik Daftar, Lengkung Masjid, Kartu Grid, Cincin, Timeline, Kubah dan Menara, Gelombang, Bintang Islami)
  dan **20 pilihan warna**. Ada pratinjau langsung di halaman pengaturan.
- Daftar kota dan desa, termasuk Karangbahagia, Cikarang, Bekasi, dan Karawang. Pilih "Kustom" untuk koordinat sendiri.

## Cara membangun

Build otomatis lewat GitHub Actions (file `.github/workflows/build.yml`). Hasilnya APK debug
di bagian Artifacts pada run yang hijau.

Untuk build manual: buka folder `annur-widget` di Android Studio (Hedgehog 2023.1.1 atau
lebih baru), tunggu Gradle sync selesai, lalu Build > Build APK(s). Minimum Android 8.0 (API 26).

## Cara memakai

1. Buka aplikasi, pilih kota, tema, dan lama tampilan fokus, lalu Simpan.
2. Izinkan notifikasi saat diminta (Android 13 ke atas).
3. Tambahkan widget dari daftar Widget.
4. Ketuk widget atau notifikasi kapan saja untuk membuka pengaturan.

## Redmi / Xiaomi (HyperOS) dan HP lain yang agresif mematikan aplikasi

Tanpa langkah ini, sistem bisa menghentikan aplikasi sehingga getar, tampilan fokus, dan notifikasi tidak tepat waktu.
Tombol "Pengaturan aplikasi" di dalam aplikasi membuka halaman info aplikasi, lalu:
1. Aktifkan Mulai otomatis (Autostart).
2. Hemat baterai > pilih "Tanpa batasan".
3. Kunci aplikasi di daftar aplikasi terbaru.

## Catatan

- Alarm memakai alarm tepat waktu (exact alarm) dan membangunkan HP, supaya tampilan fokus dan getar tepat saat waktu sholat tiba.
- Jam di widget mengikuti zona waktu HP. Hitung mundur dan waktu sholat mengikuti zona yang dipilih di pengaturan.
- Setelah Isya, widget menampilkan jadwal besok.
- Wallpaper layar kunci bersifat statis: hitung mundur tidak berjalan di sana.
- Koordinat desa diambil dari Google Places dan berupa titik tengah desa, jadi perbedaan waktu beberapa detik wajar.
- Belum ada suara adzan.


## Versi 1.3

- **Tanggal Hijriyah** (kalender Umm al-Qura bawaan Android, tanpa internet) di widget, layar kunci, notifikasi, dan halaman utama.
  Bisa dikoreksi -2 sampai +2 hari, dan bisa berganti tanggal saat Maghrib.
- **Teks berjalan** di widget. Isi teks bebas diatur di Pengaturan, bisa ditambah kegiatan hari ini dan hari besar Hijriyah.
- **Kalender Masehi dan Hijriyah** untuk mencatat kegiatan (judul, catatan, jam, pengingat notifikasi).
  Tiap kotak menampilkan kedua tanggal, penanda kegiatan, dan hari besar.
- **Tampilan baru**: halaman utama dengan hitung mundur, kartu, pemilih warna berupa lingkaran, tombol simpan tetap di bawah.
