# Jadwal Sholat An-Nur (Android)

Aplikasi jadwal sholat dengan tiga jenis widget, notifikasi lock screen, dan wallpaper
layar kunci. Perhitungan waktu dilakukan di perangkat (algoritma yang sama dengan versi web),
tanpa internet.

Dikembangkan oleh Ahmad Mu'adz.

## Fitur

- **Widget Lengkung**: lengkung masjid dengan titik waktu sholat, jam berdetik, dan hitung mundur.
- **Widget Ringkas**: sholat berikutnya, jamnya besar, dan hitung mundur.
- **Widget Daftar**: enam waktu sholat ditumpuk ke bawah, dengan sorotan di waktu berikutnya.
- **Notifikasi tetap**: hitung mundur yang tampil di lock screen (Android 8 ke atas).
- **Wallpaper layar kunci**: gambar jadwal sholat hari ini, diperbarui tiap waktu sholat (cocok untuk Android 12).
- **Widget layar kunci**: hanya tampil di HP Android 16 ke atas yang mendukung fitur tersebut.

## Cara membangun

Build otomatis lewat GitHub Actions (file `.github/workflows/build.yml`). Hasilnya APK debug
di bagian Artifacts pada run yang hijau.

Untuk build manual: buka folder `annur-widget` di Android Studio (Hedgehog 2023.1.1 atau
lebih baru), tunggu Gradle sync selesai, lalu Build > Build APK(s). Minimum Android 8.0 (API 26).

## Cara memakai

1. Buka aplikasi, pilih kota (atau "Kustom" dan isi lintang, bujur, serta UTC+), lalu Simpan.
2. Izinkan notifikasi saat diminta (Android 13 ke atas).
3. Untuk wallpaper layar kunci, centang "Pasang jadwal sholat sebagai wallpaper layar kunci".
4. Tambahkan widget dari daftar Widget: Lengkung, Ringkas, atau Daftar.
5. Ketuk widget atau notifikasi kapan saja untuk membuka pengaturan.

## Redmi / Xiaomi (HyperOS) dan HP lain yang agresif mematikan aplikasi

Tanpa langkah ini, sistem bisa menghentikan aplikasi sehingga notifikasi dan wallpaper tidak diperbarui.
Tombol "Pengaturan aplikasi" di dalam aplikasi membuka halaman info aplikasi, lalu:
1. Aktifkan Mulai otomatis (Autostart).
2. Hemat baterai > pilih "Tanpa batasan".
3. Kunci aplikasi di daftar aplikasi terbaru.

## Catatan

- Jam di widget Lengkung dan Ringkas mengikuti zona waktu HP. Hitung mundur dan waktu sholat mengikuti zona yang dipilih di pengaturan.
- Koordinat kota Cikarang, Bekasi, dan Karawang adalah perkiraan. Gunakan "Kustom" untuk koordinat yang lebih tepat.
- Wallpaper layar kunci bersifat statis: hitung mundur tidak berjalan di sana. Mengganti wallpaper secara manual akan menimpanya, dan bisa diatur ulang dengan menekan Simpan.
- Setelah HP restart, widget bisa tertinggal hingga 30 menit sampai pembaruan berikutnya.
- Belum ada suara adzan.
